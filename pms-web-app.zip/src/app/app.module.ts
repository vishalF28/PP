import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './common/material/material.module';
import { CoreModule, FlexLayoutModule } from '@angular/flex-layout';
import { HeaderComponent } from './common/layout/header/header.component';
import { SidebarComponent } from './common/layout/sidebar/sidebar.component';
import { LoginComponent } from './features/authorization/pages/login/login.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpLoaderInterceptorService } from './core/interceptor/http-loader-interceptor';
import { ForgotPasswordComponent } from './shared/components/pages/forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './shared/components/pages/change-password/change-password.component';
import { DashboardComponent } from './shared/components/pages/dashboard/dashboard.component';
import { AdminModule } from './features/admin/admin.module';
import { PatientModule } from './features/patient/patient.module';
import { PhysicianModule } from './features/physician/physician.module';
import { AddNewAppointmentComponent } from './shared/components/pages/add-new-appointment/add-new-appointment.component';
import { PatientVisitComponent } from './shared/components/pages/patient-visit/patient-visit.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { AddProceduresComponent } from './shared/components/pages/add-procedures/add-procedures.component';
import { AuthGuard } from './core/guards/auth-guard-service.guard';
import { AddDiagnosisComponent } from './shared/components/pages/add-diagnosis/add-diagnosis.component';
import { ViewAppointmentsComponent } from './shared/components/pages/view-appointments/view-appointments.component';
import { AddDrugComponent } from './shared/components/pages/add-drug-data/add-drug-data.component';
import { NurseModule } from './features/nurse/nurse.module';
import { DeletePatientDiagnosisComponent } from './shared/components/pages/delete-patient-diagnosis/delete-patient-diagnosis.component';
import { DeletePatientProcedureComponent } from './shared/components/pages/delete-patient-procedure/delete-patient-procedure.component';
import { DeletePatientDrugComponent } from './shared/components/pages/delete-patient-drug/delete-patient-drug.component';
import { ViewNotesComponent } from './shared/components/pages/view-notes/view-notes.component';
import { ManageNotesComponent } from './shared/components/pages/manage-notes/manage-notes.component';
import { MyNotesComponent } from './shared/components/pages/my-notes/my-notes.component';
import { AddNewNoteComponent } from './shared/components/pages/add-new-note/add-new-note.component';
import { ReplyReceiverNotesComponent } from './shared/components/pages/reply-receiver-notes/reply-receiver-notes.component';
import { ReplyMyNotesComponent } from './shared/components/pages/reply-my-notes/reply-my-notes.component';
import { MyProfileComponent } from './shared/components/pages/my-profile/my-profile.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ViewPatientProfileByStaffComponent } from './shared/components/pages/view-patient-profile-by-staff/view-patient-profile-by-staff.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    LoginComponent,
    ForgotPasswordComponent,
    ChangePasswordComponent,
    DashboardComponent,
    AddNewAppointmentComponent,
    PatientVisitComponent,
    AddDiagnosisComponent,
    AddProceduresComponent,
    AddDrugComponent,
    ViewAppointmentsComponent,
    DeletePatientDiagnosisComponent,
    DeletePatientProcedureComponent,
    DeletePatientDrugComponent,
    ViewNotesComponent,
    ManageNotesComponent,
    MyNotesComponent,
    AddNewNoteComponent,
    ReplyReceiverNotesComponent,
    ReplyMyNotesComponent,
    MyProfileComponent,
    ViewPatientProfileByStaffComponent
  ],
  imports: [
    MatInputModule,
    MatFormFieldModule,
    MatExpansionModule,
    BrowserAnimationsModule,
    FormsModule,
    BrowserModule,
    HttpClientModule,
    CoreModule,
    AppRoutingModule,
    ReactiveFormsModule,
    MaterialModule,
    FlexLayoutModule,
    AdminModule,
    PatientModule,
    PhysicianModule,
    NurseModule,
    NgxChartsModule
  ],
  providers: [AuthGuard, { provide: HTTP_INTERCEPTORS, useClass: HttpLoaderInterceptorService, multi: true }],
  bootstrap: [AppComponent],
})
export class AppModule { }
