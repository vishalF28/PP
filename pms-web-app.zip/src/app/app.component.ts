import { MediaMatcher } from '@angular/cdk/layout';
import { OverlayContainer } from '@angular/cdk/overlay';
import { ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { HeaderComponent } from './common/layout/header/header.component';
import { StorageService } from './core/services/storage.service';
import { AuthorizationService } from './features/authorization/services/authorization.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CT General Hospital';

  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
  isDarkTheme: boolean = false;

  private authListner: Subscription;
  userIsAuthenticated = false;

  constructor(private authService: AuthorizationService, private changeDetectorRef: ChangeDetectorRef,
    private media: MediaMatcher, private storageService: StorageService, public overlayContainer: OverlayContainer) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnInit() {
    this.authService.autoAuthenticateUser();
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authListner = this.authService.getAuthStatusListener().subscribe(
      isAuthenticated => { this.userIsAuthenticated = isAuthenticated; }
    );
    this.storageService.detectLocalStorageValueChange();
    this.isDarkTheme = sessionStorage.getItem('theme') === "Dark" ? true : false;
  }

  themeChangeHandler($event) {
    this.isDarkTheme = $event;
  }

  ngDoCheck() {
    if (sessionStorage.getItem('theme') === "Dark" ? true : false) {
      this.overlayContainer.getContainerElement().classList.add('dark-theme-mode');
    } else {
      this.overlayContainer.getContainerElement().classList.remove('dark-theme-mode');
    }
  }

  ngOnDestroy() {
    this.authListner.unsubscribe();
  }
}
