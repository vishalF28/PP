import { PatientVisitComponent } from './shared/components/pages/patient-visit/patient-visit.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterHospitalStaffComponent } from './features/admin/pages/register-hospital-staff/register-hospital-staff.component';
import { ViewAllPatientComponent } from './features/admin/pages/view-all-patient/view-all-patient.component';
import { ViewAllStaffComponent } from './features/admin/pages/view-all-staff/view-all-staff.component';
import { LoginComponent } from './features/authorization/pages/login/login.component';
import { SignupComponent } from './features/patient/pages/signup/signup.component';
import { PatientProfileComponent } from './features/patient/pages/patient-profile/patient-profile.component';
import { ChangePasswordComponent } from './shared/components/pages/change-password/change-password.component';
import { DashboardComponent } from './shared/components/pages/dashboard/dashboard.component';
import { ForgotPasswordComponent } from './shared/components/pages/forgot-password/forgot-password.component';
import { AddMasterDataComponent } from './features/admin/pages/add-master-data/add-master-data.component';
import { AppointmentSchedulerComponent } from './features/physician/pages/appointment-scheduler/appointment-scheduler.component';
import { AddNewAppointmentComponent } from './shared/components/pages/add-new-appointment/add-new-appointment.component';
import { PatientAppointmentHistoryComponent } from './features/patient/pages/patient-appointment-history/patient-appointment-history.component';
import { ViewAppointmentsComponent } from './shared/components/pages/view-appointments/view-appointments.component';
import { PatientVisitManagementByNurseComponent } from './features/nurse/pages/patient-visit-management-by-nurse/patient-visit-management-by-nurse.component';
import { ManageNotesComponent } from './shared/components/pages/manage-notes/manage-notes.component';
import { MyProfileComponent } from './shared/components/pages/my-profile/my-profile.component';
import { ManageAppointmentByNurseComponent } from './features/nurse/pages/manage-appointment-by-nurse/manage-appointment-by-nurse.component';
import { AuthGuard } from './core/guards/auth-guard-service.guard';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'change-password', component: ChangePasswordComponent, canActivate: [AuthGuard] },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'my-profile', component: MyProfileComponent, canActivate: [AuthGuard] },
  { path: 'add-new-hospital-staff', component: RegisterHospitalStaffComponent, canActivate: [AuthGuard] },
  { path: 'view-all-patient', component: ViewAllPatientComponent, canActivate: [AuthGuard] },
  { path: 'view-hospital-staff', component: ViewAllStaffComponent, canActivate: [AuthGuard] },
  { path: 'patient/signup', component: SignupComponent },
  { path: 'patient/my-profile', component: PatientProfileComponent, canActivate: [AuthGuard] },
  { path: 'add-master-data', component: AddMasterDataComponent, canActivate: [AuthGuard] },
  { path: 'physician/manage-appointment', component: AppointmentSchedulerComponent, canActivate: [AuthGuard] },
  { path: 'add-new-appointment', component: AddNewAppointmentComponent, canActivate: [AuthGuard] },
  { path: 'physician/patient-visit', component: ViewAppointmentsComponent, canActivate: [AuthGuard] },
  { path: 'physician/patient-visit-details/:appointmentId', component: PatientVisitComponent, canActivate: [AuthGuard] },
  { path: 'view-appointment-history', component: PatientAppointmentHistoryComponent, canActivate: [AuthGuard] },
  { path: 'nurse/manage-appointment', component: ManageAppointmentByNurseComponent, canActivate: [AuthGuard] },
  { path: 'nurse/manage-patient-visit', component: PatientVisitManagementByNurseComponent, canActivate: [AuthGuard] },
  { path: 'physician/patient-visits', component: ViewAppointmentsComponent, canActivate: [AuthGuard] },
  { path: 'view-appointment-history', component: PatientAppointmentHistoryComponent, canActivate: [AuthGuard] },
  { path: 'nurse/manage-patient-visit', component: PatientVisitManagementByNurseComponent, canActivate: [AuthGuard] },
  { path: 'manage-notes', component: ManageNotesComponent, canActivate: [AuthGuard] },
  { path: 'patient-visit-details/:appointmentId', component: PatientVisitComponent, canActivate: [AuthGuard] },
  { path: '**', component: DashboardComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
