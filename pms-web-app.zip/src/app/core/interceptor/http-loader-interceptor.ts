import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators'
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { LoaderService } from '../services/loader.service';

@Injectable({
    providedIn: 'root'
})
export class HttpLoaderInterceptorService implements HttpInterceptor {

    constructor(public loader: LoaderService, private authService: AuthorizationService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.loader.isLoading.next(true);
        if (this.authService.getIsAuth()) {
            const authToken = localStorage.getItem('accessToken');
            const role = localStorage.getItem('role');
            req = req.clone({ headers: req.headers.set('Authorization', 'Bearer ' + authToken) });
        }
        console.log(req);
        return next.handle(req).pipe(
            finalize(
                () => {
                    setTimeout(() => { this.loader.isLoading.next(false) }, 500)
                }
            )
        )
    }
}
