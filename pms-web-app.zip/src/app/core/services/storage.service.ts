import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor(private authService: AuthorizationService, private snackBar: MatSnackBar) { }

  detectLocalStorageValueChange() {
    window.addEventListener('storage', (event) => {
      if (event.storageArea === localStorage && this.authService.getIsAuth()) {
        this.snackBar.open("You have been logged out. Please login again", null, { duration: 3000 });
        this.authService.logout();
      }
    });
  }
}
