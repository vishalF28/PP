import { Injectable } from '@angular/core';
import * as SockJs from 'sockjs-client';
import * as Stomp from 'stompjs';

@Injectable({
  providedIn: 'root'
})
export class NotificationSocketService {

  constructor() { }

  public connect() {
    let socket = new SockJs(`http://localhost:9097/socket`);
    let stompClient = Stomp.over(socket);
    return stompClient;
  }


}
