import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';
import { Appointment } from '../../components/interfaces/appointment.model';

@Injectable({
  providedIn: 'root'
})
export class SchedulingAppointmentService {

  constructor(private httpService: HttpService) { }

  getPhysicianData() {
    return this.httpService.get<any>(environment.adminbaseurl + '/admin/get-all-physicians');
  }

  getAvailableSlotsForPhysicianByDate(physicianEmailId: any, appointmentDate: Date): any {
    return this.httpService.get<any>(environment.appointmenturl + "/appointment/" + physicianEmailId + "/" + appointmentDate);
  }

  getPatientData() {
    return this.httpService.get<any>(environment.adminbaseurl + '/admin/get-all-patient');
  }

  addNewAppointment(meetingModel: any) {
    let meetingRequest: Appointment = meetingModel;
    return this.httpService.post<any>(environment.appointmenturl + '/appointment/add-new-appointment', meetingModel);
  }

}
