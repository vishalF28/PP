import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';
import { HospitalStaffProfile } from '../interfaces/hospital-staff-profile.model';

@Injectable({
  providedIn: 'root'
})
export class StaffService {

  constructor(private httpService: HttpService, private snackBar: MatSnackBar) { }

  getStaffProfileDetails(emailId: string): any {
    let staffProfile: HospitalStaffProfile = new HospitalStaffProfile();
    this.httpService.get<HospitalStaffProfile>(environment.adminbaseurl + '/admin/profile/' + emailId)
      .subscribe((response) => {
        staffProfile.userId = response.userId;
        staffProfile.emailId = response.emailId;
        staffProfile.firstName = response.firstName;
        staffProfile.lastName = response.lastName;
        staffProfile.birthDate = response.birthDate;
        staffProfile.contact = response.contact;
        staffProfile.title = response.title;
        staffProfile.role = response.role;
        staffProfile.isActive = response.isActive;
      });
    return staffProfile;
  }

  updateAdminProfileDetails(staffProfile: HospitalStaffProfile) {
    this.httpService.put(environment.adminbaseurl + '/admin/update-admin-profile', staffProfile)
      .subscribe(response => {
        this.snackBar.open("Profile updated successfully", undefined, { duration: 3000 });
      });
  }
}
