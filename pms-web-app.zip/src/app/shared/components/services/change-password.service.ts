import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HttpService } from 'src/app/core/services/http.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { environment } from 'src/environments/environment';
import { ChangePasswordReqeust } from '../interfaces/change-password-request.model';

@Injectable({
  providedIn: 'root'
})
export class ChangePasswordService {


  constructor(private httpService: HttpService, private snackBar: MatSnackBar,
    private authService: AuthorizationService) { }

    changePasswordService(changepasswordviewmodel: any) {
    let changePasswordReqeust: ChangePasswordReqeust = {
      emailId: changepasswordviewmodel.emailId,
      newPassword: changepasswordviewmodel.newPassword
    };
    this.httpService.put(environment.authbaseurl + "/authentication/change-password", changePasswordReqeust).subscribe(
      (response) => {
        this.snackBar.open(response.message, undefined, { duration: 3000 });
        this.authService.logout();
      }
    )
  }
}
