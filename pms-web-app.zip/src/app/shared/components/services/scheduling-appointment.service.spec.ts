import { TestBed } from '@angular/core/testing';

import { SchedulingAppointmentService } from './scheduling-appointment.service';

describe('SchedulingAppointmentService', () => {
  let service: SchedulingAppointmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SchedulingAppointmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
