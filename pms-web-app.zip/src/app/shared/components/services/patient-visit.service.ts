import { PatientDiagnosis } from './../interfaces/patient-diagnosis';
import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';
import { Diagnosis } from '../interfaces/diagnosis.model';
import { Drug } from '../interfaces/drug.model';
import { Procedure } from '../interfaces/procedure.model';
import { Appointment } from '../interfaces/appointment.model';
import { PatientProcedure } from '../interfaces/patient-procedure';
import { PatientDrug } from '../interfaces/patient-durg-data';
@Injectable({
  providedIn: 'root',
})
export class PatientVisitService {
  constructor(
    private httpService: HttpService,
    private snackBar: MatSnackBar,
    private route: Router
  ) { }

  getDiagnosisData() {
    return this.httpService.get<Diagnosis[]>(
      environment.appointmenturl + '/diagnosis/getall'
    );
  }

  getDrugData() {
    return this.httpService.get<Drug[]>(
      environment.appointmenturl + '/drug/getall'
    );
  }
  getProcedureData() {
    return this.httpService.get<Procedure[]>(
      environment.appointmenturl + '/procedure/getall'
    );
  }
  getPatientAppointmentDetails(appointmentId: number) {
    return this.httpService.get<Appointment>(
      environment.appointmenturl +
      '/appointment/physician/get-appointment-details/' +
      appointmentId
    );
  }

  savePatientVisitDetails(patientVitalSigns: any, appointmentId: number) {
    return this.httpService.put(
      environment.appointmenturl +
      '/appointment/physician/save-appointment-details/' +
      appointmentId,
      patientVitalSigns
    );
  }
  getUpcomingAppointments(physicianEmailId: string) {
    return this.httpService.get(
      environment.appointmenturl +
        '/appointment/get-upcoming-appointments/' +
        physicianEmailId
    );
  }
  savePatientDiagnosis(patientDiagnosis: any) {
    console.log('req');
    console.log(patientDiagnosis);
    return this.httpService.put(
      environment.appointmenturl +
      '/appointment/physician/add-patient-diagnosis/' +
      patientDiagnosis.data.appointmentId,
      patientDiagnosis.data.diagnosis
    );
  }

  savePatientProcedure(patientProcedure: PatientProcedure) {
    return this.httpService.put(
      environment.appointmenturl +
      '/appointment/physician/add-patient-procedure/' +
      patientProcedure.appointmentId,
      patientProcedure.procedure
    );
  }

  savePatientDrugData(patientDrugData: any) {
    console.log(patientDrugData);
    return this.httpService.put(
      environment.appointmenturl +
      '/appointment/physician/add-patient-drug/' +
      patientDrugData.data.appointmentId,
      patientDrugData.data
    );
  }

  deleteDiagnosisForPatient(diagnosis: any, appointmentId: number) {
    return this.httpService.delete(
      environment.appointmenturl +
      '/appointment/physician/delete-patient-diagnosis/' +
      appointmentId +
      '/' +
      diagnosis.diagnosisId
    );
  }
  deleteProcedureForPatient(procedureId: number, appointmentId: number) {
    return this.httpService.delete(
      environment.appointmenturl +
      '/appointment/physician/delete-patient-procedure/' +
      appointmentId +
      '/' +
      procedureId
    );
  }
  deleteDrugForPatient(appointmentId: number, drugId: number) {
    return this.httpService.delete(
      environment.appointmenturl +
      '/appointment/physician/delete-patient-drug/' + appointmentId + '/drug/' + drugId
    );
  }
}
