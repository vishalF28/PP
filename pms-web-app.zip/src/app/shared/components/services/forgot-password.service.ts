import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {

  constructor(private httpService: HttpService, private snackBar: MatSnackBar,
    private route: Router) { }

  forgotPassword(emailId: string) {
    console.log(emailId);
    this.httpService.put(environment.authbaseurl + "/authentication/forgot-password/" + emailId, {})
      .subscribe(
        (response) => {
          this.snackBar.open(response.message, undefined, { duration: 3000 });
          this.route.navigate(['/login']);
        }
      )
  }
}
