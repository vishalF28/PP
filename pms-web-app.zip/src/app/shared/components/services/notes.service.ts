import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';
import { NotesView } from '../interfaces/notes-view.model';

@Injectable({
  providedIn: 'root'
})
export class NotesService {

  constructor(private httpService: HttpService) { }

  public getNotesMessages(emailId: string) {
    return this.httpService.get(environment.notesmessagesurl + "/notes/get-receiver-notes/" + emailId);
  }

  public getPhysicianData() {
    return this.httpService.get<any>(environment.adminbaseurl + '/admin/get-all-physicians-and-nurses');
  }

  public sendNote(noteViewModel) {
    return this.httpService.post<any>(environment.notesmessagesurl + '/notes/add-new-note', noteViewModel);
  }

  public getMyNotesMessages(emailId: string) {
    return this.httpService.get(environment.notesmessagesurl + "/notes/get-my-notes/" + emailId);
  }

  public getReceiverNotesBasedOnChatId(chatId: number) {
    return this.httpService.get(environment.notesmessagesurl + "/notes/get-receiver-notes-based-on-chat-id/" + chatId);
  }

  public saveReceiverReplyMessage(currentNoteView: NotesView) {
    return this.httpService.post<any>(environment.notesmessagesurl + '/notes/save-receiver-reply-note', currentNoteView);
  }

  public getMyNotesBasedOnChatId(chatId: number) {
    return this.httpService.get(environment.notesmessagesurl + "/notes/get-my-notes-based-on-chat-id/" + chatId);
  }

  public saveMyReplyMessage(currentNoteView: NotesView) {
    return this.httpService.post<any>(environment.notesmessagesurl + '/notes/save-my-reply-note', currentNoteView);
  }

  public sendNotification() {
    return this.httpService.get<any>(environment.notesmessagesurl + '/notify');
  }

  deleteSenderNotesBasedOnChatId(chatId: number) {
    return this.httpService.post<any>(environment.notesmessagesurl + '/notes/delete-sender-notes', chatId);
  }

  deleteReceiverNotesBasedOnChatId(chatId: number) {
    return this.httpService.post<any>(environment.notesmessagesurl + '/notes/delete-receiver-notes', chatId);
  }
}
