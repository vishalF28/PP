export class NotesView {

    chatId: number;
    
    noteId: number;

    senderName: string;

    senderDesignation: string;

    message: string;

    isUrgent: boolean;

    receiverName: string;

    receiverDesignation: string;

    messageReceivedDate: Date;

    isDeleted: boolean;

    isViewed: boolean;
}