export interface Diagnosis {
  diagnosisId: number;
  diagnosisCode: string;
  diagnosisDescription: string;
  isDeprecated: boolean;
}
