export interface Drug {
  drugId: number;
  drugName: string;
  drugDescription: string;
  drugGenericName:string;
  drugManufacturerName:string;
  drugForm:string;
  drugStrength :string;

}
