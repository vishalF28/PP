export interface ChangePasswordReqeust {
    emailId: string;
    newPassword: string;
}