export interface VitalSign {
  vitalSignId: number;
  height: number;
  weight: number;
  temperature: number;
  respirationRate: number;
  bloodPressure: string;
  capturedByNurseName: string;
}
