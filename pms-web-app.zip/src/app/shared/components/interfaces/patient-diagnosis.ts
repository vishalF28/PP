import { Diagnosis } from './diagnosis.model';
export interface PatientDiagnosis{

  appointmentId:number,
  diagnosis:Diagnosis

}
