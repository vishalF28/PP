import { Drug } from './drug.model';
export interface PatientDrug {
  patientDrugMappingId:number;
  appointmentId: number;
  drug: Drug;
  drugDosage: string;
}
