export class HospitalStaffProfile {
    userId: number;
    title: string;
    firstName: string;
    lastName: string;
    birthDate: Date;
    contact: number;
    emailId: string;
    role: string;
    isActive: boolean;
}