import { Procedure } from './procedure.model';
export interface PatientProcedure {
  appointmentId: number;
  procedure: Procedure;
}
