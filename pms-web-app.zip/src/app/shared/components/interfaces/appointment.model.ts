import { Diagnosis } from './diagnosis.model';
import { Drug } from './drug.model';
import { Procedure } from './procedure.model';
import { TimingSlots } from './timing-slots.model';
import { VitalSign } from './vital-sign.model';

export interface Appointment {
  appointmentId: number;

  title: string;

  description: string;

  physicianId: number;

  physicianEmailId: string;

  patientEmailId: string;

  physicianName: string;

  patientId: number;

  timeOfAppointment: TimingSlots;

  patientName: string;

  dateOfAppointment: Date;

  vitalSign: VitalSign;

  procedure: Procedure[];

  medication: Drug[];

  diagnosis: Diagnosis[];
}
