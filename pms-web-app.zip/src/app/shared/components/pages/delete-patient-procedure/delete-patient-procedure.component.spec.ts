import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletePatientProcedureComponent } from './delete-patient-procedure.component';

describe('DeletePatientProcedureComponent', () => {
  let component: DeletePatientProcedureComponent;
  let fixture: ComponentFixture<DeletePatientProcedureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeletePatientProcedureComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletePatientProcedureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
