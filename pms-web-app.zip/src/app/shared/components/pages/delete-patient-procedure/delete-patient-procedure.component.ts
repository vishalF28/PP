import { Procedure } from './../../interfaces/procedure.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, OnInit, Inject } from '@angular/core';
import { PatientDiagnosis } from '../../interfaces/patient-diagnosis';
import { PatientProcedure } from '../../interfaces/patient-procedure';

@Component({
  selector: 'app-delete-patient-procedure',
  templateUrl: './delete-patient-procedure.component.html',
  styleUrls: ['./delete-patient-procedure.component.css'],
})
export class DeletePatientProcedureComponent implements OnInit {
  constructor(
    private dialog: MatDialogRef<DeletePatientProcedureComponent>,
    @Inject(MAT_DIALOG_DATA) public procedureData: Procedure
  ) {}

  ngOnInit(): void {}

  doAction() {
    this.dialog.close({ response: 'Yes' });
  }

  closeDialog() {
    this.dialog.close();
  }
}
