import { PatientVisitService } from './../../services/patient-visit.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatAccordion } from '@angular/material/expansion';
import { Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { AddDiagnosisComponent } from '../add-diagnosis/add-diagnosis.component';
import { AddProceduresComponent } from '../add-procedures/add-procedures.component';
import { Diagnosis } from '../../interfaces/diagnosis.model';
import { Procedure } from '../../interfaces/procedure.model';
import { AddDrugComponent } from '../add-drug-data/add-drug-data.component';
import { PatientDrug } from '../../interfaces/patient-durg-data';
import { DeletePatientDiagnosisComponent } from '../delete-patient-diagnosis/delete-patient-diagnosis.component';
import { DeletePatientProcedureComponent } from '../delete-patient-procedure/delete-patient-procedure.component';
import { DeletePatientDrugComponent } from '../delete-patient-drug/delete-patient-drug.component';
import { ActivatedRoute, Router } from '@angular/router';
import { VitalSign } from '../../interfaces/vital-sign.model';
import { PatientDiagnosis } from '../../interfaces/patient-diagnosis';
import { Drug } from '../../interfaces/drug.model';
import { TimingSlots } from '../../interfaces/timing-slots.model';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import jspdf from 'jspdf';
import html2canvas from 'html2canvas';
import { Location } from '@angular/common';
import { PatientProfileComponent } from 'src/app/features/patient/pages/patient-profile/patient-profile.component';
import { ViewPatientProfileByStaffComponent } from '../view-patient-profile-by-staff/view-patient-profile-by-staff.component';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-patient-visit',
  templateUrl: './patient-visit.component.html',
  styleUrls: ['./patient-visit.component.css'],
})
export class PatientVisitComponent implements OnInit {
  @ViewChild(MatAccordion) accordion: MatAccordion;
  @ViewChildren(MatPaginator) paginator = new QueryList<MatPaginator>();
  @ViewChildren(MatSort) sort = new QueryList<MatSort>();


  diagnosisDataSource: MatTableDataSource<Diagnosis> = new MatTableDataSource();
  drugDataSource: MatTableDataSource<PatientDrug> = new MatTableDataSource();
  procedureDataSource: MatTableDataSource<Procedure> = new MatTableDataSource();
  patientVisitSubscription: Subscription;

  patientAppointmentModel: any = {
    appointmentId: 0, title: '', patientEmailId: '', physicianName: '', patientId: 0,
    timeOfAppointment: '', patientName: '', dateOfAppointment: '', vitalSigns: null,
    procedure: [], medication: [], diagnosis: [],
  };

  patientVitalSignModel: VitalSign = {
    vitalSignId: 0, height: 0, weight: 0, temperature: 0, respirationRate: 0,
    bloodPressure: '', capturedByNurseName: '',
  };

  patientDiagnosisModel: Diagnosis[] = [{
    diagnosisId: 0, diagnosisCode: '',
    diagnosisDescription: '', isDeprecated: false
  }];

  patientProcedureModel: Procedure[] = [{ procedureId: 0, procedureCode: '', procedureDescription: '', }];

  patientDrugModel: PatientDrug[] = [{
    patientDrugMappingId: 0, appointmentId: 0,
    drug: {
      drugId: 0, drugName: '', drugDescription: '', drugGenericName: '', drugManufacturerName: '',
      drugForm: '', drugStrength: ''
    },
    drugDosage: '',
  }
  ];

  displayedProcedureColumns: string[] = ['procedureId', 'procedureCode', 'procedureDescription', 'action'];
  displayedDrugColumns: string[] = ['drugId', 'drugName', 'drugDescription', 'drugGenericName',
    'drugManufacturerName', 'drugForm', 'drugStrength', 'drugDosage', 'action'];

  displayedDiagnosisColumns: string[] = ['diagnosisId', 'diagnosisCode', 'diagnosisDescription', 'action'];

  resultLengthDiagnosis: number = 0;
  resultLengthDrug: number = 0;
  resultLengthProcedure: number = 0;
  patientVisitForm: any;
  patientProfileModel: any;
  patientAllergyModel: any;
  dataSource: any;
  emergencyContactModel: any;
  emergencyContactHomeAddressValue: any;
  patientEmailId: string;

  role: string;
  toBeDisabledBasedOnRole: boolean = false;

  constructor(
    private patientVisitService: PatientVisitService, private dialog: MatDialog,
    private snackBar: MatSnackBar, private route: ActivatedRoute, private router: Router,
    private authService: AuthorizationService, private location: Location) { }

  ngOnInit(): void {
    this.role = this.authService.getRole();
    if (this.role == 'PATIENT') {
      this.toBeDisabledBasedOnRole = true;
    }
    const appointmentId = this.route.snapshot.paramMap.get('appointmentId');
    this.patientVisitService.getPatientAppointmentDetails(parseInt(appointmentId))
      .subscribe((appointmentData) => {
        this.patientEmailId = appointmentData.patientEmailId;
        this.patientAppointmentModel = appointmentData;
        this.patientAppointmentModel.timeOfAppointment = TimingSlots[appointmentData.timeOfAppointment]
        this.diagnosisDataSource.data = this.patientAppointmentModel.diagnosis;
        this.procedureDataSource.data = this.patientAppointmentModel.procedure;
        this.drugDataSource.data = this.patientAppointmentModel.patientDrugData;
        this.diagnosisDataSource.sort = this.sort.toArray()[0];
        this.diagnosisDataSource.paginator = this.paginator.toArray()[0];
        this.procedureDataSource.sort = this.sort.toArray()[1];
        this.procedureDataSource.paginator = this.paginator.toArray()[1];
        this.drugDataSource.sort = this.sort.toArray()[2];
        this.drugDataSource.paginator = this.paginator.toArray()[2];
        if (appointmentData.vitalSigns != null) {
          this.patientVitalSignModel = appointmentData.vitalSigns;
        }
      });
    this.resultLengthDiagnosis = this.diagnosisDataSource.data.length;
    this.resultLengthDrug = this.drugDataSource.data.length;
    this.resultLengthProcedure = this.procedureDataSource.data.length;
  }

  savePatientVisit(patientVisitForm: NgForm) {
    this.patientVisitService
      .savePatientVisitDetails(
        this.patientVitalSignModel,
        this.patientAppointmentModel.appointmentId
      )
      .subscribe((response) => {
        if (response) {
          this.snackBar.open('Patient Visit details saved successfully.', undefined, { duration: 3000 });
          this.router.navigateByUrl("/physician/patient-visits");
        }
      });
  }

  openDeleteDiagnosisDialog(diagnosisData) {
    const dialogRef = this.dialog.open(DeletePatientDiagnosisComponent, {
      data: diagnosisData,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.response === 'Yes') {
        this.patientVisitService.deleteDiagnosisForPatient(diagnosisData, this.patientAppointmentModel.appointmentId)
          .subscribe(() => {
            this.diagnosisDataSource.data =
              this.diagnosisDataSource.data.filter((diagnosisElement) => {
                return (
                  diagnosisElement.diagnosisId != diagnosisData.diagnosisId
                );
              });
          });
      }
    });
  }

  openDeleteProcedureDialog(procedureData) {
    const dialogRef = this.dialog.open(DeletePatientProcedureComponent, {
      data: procedureData,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.response === 'Yes') {
        this.patientVisitService
          .deleteProcedureForPatient(
            procedureData.procedureId,
            this.patientAppointmentModel.appointmentId
          )
          .subscribe(() => {
            this.procedureDataSource.data =
              this.procedureDataSource.data.filter((procedureElement) => {
                return (
                  procedureElement.procedureId != procedureData.procedureId
                );
              });
          });
      }
    });
  }
  openDeleteDrugDialog(drugsData) {
    const dialogRef = this.dialog.open(DeletePatientDrugComponent, {
      data: drugsData,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.response === 'Yes') {
        this.patientVisitService.deleteDrugForPatient(drugsData.appointmentId, drugsData.drug.drugId)
          .subscribe(() => {
            this.drugDataSource.data = this.drugDataSource.data.filter(
              (drugElement) => {
                console.log(drugElement)
                return drugElement.drug.drugId != drugsData.drug.drugId;
              }
            );
          });
      }
    });
  }

  openAddDiagnosisDialog() {
    const dialogRef = this.dialog.open(AddDiagnosisComponent, {
      data: this.patientAppointmentModel.appointmentId,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const diagnosisExist = this.diagnosisDataSource.data.findIndex(
          (diagnosisElement) =>
            diagnosisElement.diagnosisId === result.data.diagnosis.diagnosisId
        );

        if (diagnosisExist == -1) {
          this.patientVisitService.savePatientDiagnosis(result).subscribe();
          this.diagnosisDataSource.data.push(result.data.diagnosis);
          this.diagnosisDataSource.filter = '';
        } else {
          this.snackBar.open('Diagnosis alredy exist', undefined, {
            duration: 3000,
          });
        }
      }
    });
  }

  openAddDrugDialog() {
    const dialogRef = this.dialog.open(AddDrugComponent, {
      data: this.patientAppointmentModel.appointmentId,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.data) {
        const drugExist = this.drugDataSource.data.findIndex((drugElement) => drugElement.drug.drugId === result.data.drug.drugId);
        console.log(drugExist);
        if (drugExist == -1) {
          this.patientVisitService.savePatientDrugData(result).subscribe();
          this.drugDataSource.data.push(result.data);
          this.drugDataSource.filter = '';
        } else {
          this.snackBar.open('Drug alredy exist', undefined, {
            duration: 3000,
          });
        }
      }
    });
  }
  openAddProcedureDialog() {
    const dialogRef = this.dialog.open(AddProceduresComponent, {
      data: this.patientAppointmentModel.appointmentId,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.data) {
        const procedureExist = this.procedureDataSource.data.findIndex(
          (procedureElement) =>
            procedureElement.procedureId === result.data.procedure.procedureId
        );
        if (procedureExist == -1) {
          this.patientVisitService
            .savePatientProcedure(result.data)
            .subscribe();
          this.procedureDataSource.data.push(result.data.procedure);
          this.procedureDataSource.filter = '';
        } else {
          this.snackBar.open('Procedure alredy exist', undefined, {
            duration: 3000,
          });
        }
      }
    });
  }

  ngOnDestroy() {
    //this.patientVisitSubscription.unsubscribe();
  }

  exportAsPDF(appintmentId) {
    window.open(environment.appointmenturl + "/appointment/get-appointment-report/" + appintmentId, '_blank');
  }

  goBackToPreviousPage() {
    this.location.back();
  }

  viewProfile() {
    const profileDialog = this.dialog.open(ViewPatientProfileByStaffComponent, { data: this.patientEmailId });
  }
}
