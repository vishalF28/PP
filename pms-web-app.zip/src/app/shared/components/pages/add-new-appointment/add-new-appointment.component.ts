import { Component, OnInit } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { SchedulingAppointmentService } from 'src/app/shared/components/services/scheduling-appointment.service';
import { TimingSlots } from '../../interfaces/timing-slots.model';

@Component({
  selector: 'app-add-new-appointment',
  templateUrl: './add-new-appointment.component.html',
  styleUrls: ['./add-new-appointment.component.css']
})
export class AddNewAppointmentComponent implements OnInit {

  minDate = new Date();
  maxDate = new Date();

  weekendFilter = (d: Date): boolean => {
    var day;
    if (d != null) {
      day = d.getDay();
    }
    return day !== 0;
  }

  filteredPhysicianDataSet: Observable<any[]>;
  physicianDataSet: any[] = [];
  physicianSearch = new FormControl();
  fieldDisabled: boolean = true;

  physicianModel: any = { emailId: '', fullName: '', physicianId: 0 }

  filteredPatientDataSet: Observable<any[]>;
  patientDataSet: any[] = [];
  patientSearch = new FormControl();

  patientModel: any = { emailId: '', fullName: '', patientId: 0 }

  timeSlotDataSet: any[];
  timeAvailableSlots: string[] = [];

  selectedTimeSlot: string = '';

  addAppointmentDescription: boolean = false;

  meetingModel: any = {
    appointmentId: 0, title: '', description: '', physicianId: 0, physicianEmailId: '', patientId: 0, patientEmailId: '',
    dateOfAppointment: Date, timeOfAppointment: TimingSlots, patientName: '', physicianName: ''
  };

  isPhysicianSelected: boolean = false;
  isTimeSlotSelected: boolean = false;
  isDateSelected: boolean = false;

  currentRole: string;
  constructor(private schedulingAppointmentService: SchedulingAppointmentService, private snackBar: MatSnackBar,
    public loader: LoaderService, private authService: AuthorizationService) {
    this.maxDate.setMonth(this.maxDate.getMonth() + 3);
  }

  ngOnInit(): void {
    this.currentRole = this.authService.getRole();
    this.schedulingAppointmentService.getPhysicianData().subscribe(response => {
      this.physicianDataSet = response;
    });
    this.filteredPhysicianDataSet = this.physicianSearch.valueChanges
      .pipe(
        startWith(''),
        map(physician => physician ? this.physicianFilter(physician) : this.physicianDataSet.slice())
      );
  }

  private physicianFilter(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.physicianDataSet.filter(physician =>
      physician.firstName.toLocaleLowerCase().includes(filterValue) ||
      physician.lastName.toLocaleLowerCase().includes(filterValue) ||
      physician.speciality.toLocaleLowerCase().includes(filterValue)
    );
  }


  setPhysicianName(physicianEmailId: any) {
    const physician = this.physicianDataSet.find(value => value.emailId === physicianEmailId);
    this.physicianModel.emailId = physicianEmailId;
    this.physicianModel.fullName = physician.title + ". " + physician.firstName + " " + physician.lastName;
    this.physicianModel.physicianId = physician.userId;
    this.schedulingAppointmentService.getAvailableSlotsForPhysicianByDate(physicianEmailId, this.meetingModel.dateOfAppointment)
      .subscribe((response) => {
        this.timeSlotDataSet = response;
        this.timeAvailableSlots = [];
        this.timeSlotDataSet.forEach((timeslot) => {
          this.timeAvailableSlots.push(TimingSlots[timeslot]);
        });
      });
    this.isPhysicianSelected = true;
  }

  setTimeSlot(timeslot: string) {
    this.selectedTimeSlot = timeslot;
    this.isTimeSlotSelected = true;
  }

  onDateSelect() {
    this.isDateSelected = true;
    this.timeAvailableSlots = [];
    this.physicianSearch.reset();
    this.selectedTimeSlot = '';
    this.isPhysicianSelected = false;
    this.isTimeSlotSelected = false;
    this.physicianModel.fullName = '';
    this.physicianModel.physicianId = 0;
    this.addAppointmentDescription = false;
  }

  addDetailsToAppointment() {
    this.addAppointmentDescription = true;
    this.schedulingAppointmentService.getPatientData().subscribe(response => {
      this.patientDataSet = response;
    });
    this.filteredPatientDataSet = this.patientSearch.valueChanges
      .pipe(
        startWith(''),
        map(patient => patient ? this.patientFilter(patient) : this.patientDataSet.slice())
      );
  }

  private patientFilter(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.patientDataSet.filter(patient =>
      patient.userId.toString().toLocaleLowerCase().includes(filterValue) ||
      patient.firstName.toLocaleLowerCase().includes(filterValue) ||
      patient.lastName.toLocaleLowerCase().includes(filterValue)
    );
  }

  setPatientName(patientEmailId: any) {
    const patient = this.patientDataSet.find(value => value.emailId === patientEmailId);
    this.patientModel.emailId = patientEmailId;
    this.patientModel.fullName = patient.title + ". " + patient.firstName + " " + patient.lastName;
    this.patientModel.patientId = patient.userId;
    this.meetingModel.title = "Appointment - " + this.physicianModel.fullName + " " + this.patientModel.fullName;
  }

  addNewAppointment(appointmentForm: NgForm) {
    this.meetingModel.physicianId = this.physicianModel.physicianId;
    this.meetingModel.patientId = this.patientModel.patientId;
    this.meetingModel.physicianEmailId = this.physicianModel.emailId;
    this.meetingModel.patientEmailId = this.patientModel.emailId;
    this.meetingModel.patientName = this.patientModel.fullName;
    this.meetingModel.physicianName = this.physicianModel.fullName;
    this.meetingModel.timeOfAppointment = TimingSlots[this.selectedTimeSlot];
    this.schedulingAppointmentService.addNewAppointment(this.meetingModel)
      .subscribe(
        (response) => {
          this.snackBar.open("Appointment added successfully. Appointment Id : " + response.appointmentId, undefined, { duration: 3000, })
          appointmentForm.resetForm();
          this.physicianSearch.reset();
          this.patientSearch.reset();
          this.isDateSelected = false;
          this.isTimeSlotSelected = false;
          this.isPhysicianSelected = false;
          this.addAppointmentDescription = false;
          this.timeAvailableSlots = [];
          this.selectedTimeSlot = '';
        }
      );
  }

  resetForm(appointmentForm: NgForm) {
    appointmentForm.resetForm();
    this.physicianSearch.reset();
    this.patientSearch.reset();
    this.isDateSelected = false;
    this.isTimeSlotSelected = false;
    this.isPhysicianSelected = false;
    this.addAppointmentDescription = false;
    this.timeAvailableSlots = [];
    this.selectedTimeSlot = '';
  }

  clearPhysicianSearch() {
    this.physicianSearch.reset();
    this.isPhysicianSelected = false;
    this.physicianModel.fullName = "";
    this.physicianModel.physicianId = 0;
  }

  clearPatientSearch() {
    this.patientSearch.reset();
    this.patientModel.fullName = "";
    this.patientModel.patientId = 0;
    this.meetingModel.title = "";
    this.meetingModel.description = "";
  }
}
