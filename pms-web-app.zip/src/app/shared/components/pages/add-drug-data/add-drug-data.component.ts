import { startWith, map } from 'rxjs/operators';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { Component, OnInit, Inject } from '@angular/core';

import { PatientVisitService } from '../../services/patient-visit.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Drug } from '../../interfaces/drug.model';
import { PatientDrug } from '../../interfaces/patient-durg-data';

@Component({
  selector: 'app-add-drug',
  templateUrl: './add-drug-data.component.html',
  styleUrls: ['./add-drug-data.component.css'],
})
export class AddDrugComponent implements OnInit {
  filteredDrugDataSet: Observable<Drug[]>;
  drugDataSet: Drug[] = [];
  drugSearch = new FormControl();
  fieldDisabled: boolean = true;

  patientDrugModel: PatientDrug = {
    patientDrugMappingId:0,
    appointmentId: 0,
    drug: {
      drugId: 0,
      drugName: '',
      drugDescription: '',
      drugGenericName: '',
      drugManufacturerName: '',
      drugForm: '',
      drugStrength: '',
    },
    drugDosage: '',
  };

  constructor(
    @Inject(MAT_DIALOG_DATA) public appointmentId: number,
    private patientVisitService: PatientVisitService,
    private dialog: MatDialogRef<AddDrugComponent>
  ) {}

  ngOnInit(): void {
    this.patientDrugModel.appointmentId = this.appointmentId;
    this.patientVisitService
      .getDrugData()
      .subscribe((response) => (this.drugDataSet = response));
    this.filteredDrugDataSet = this.drugSearch.valueChanges.pipe(
      startWith(''),
      map((drug) => (drug ? this._drugFilter(drug) : this.drugDataSet.slice()))
    );
  }

  private _drugFilter(value: string): Drug[] {
    const filterValue = value.toLowerCase();
    return this.drugDataSet.filter(
      (drug) =>
        drug.drugId.toString().includes(filterValue) ||
        drug.drugName.toLocaleLowerCase().includes(filterValue) ||
        drug.drugDescription.toLocaleLowerCase().includes(filterValue)
    );
  }

  setDrugValue(drugName) {
    const drug = this.drugDataSet.find((value) => value.drugName === drugName);
    if (drug.drugName === 'Other') {
      this.fieldDisabled = false;
    } else {
      this.fieldDisabled = true;
    }
    this.patientDrugModel.drug.drugId = drug.drugId;
    this.patientDrugModel.drug.drugName = drug.drugName;
    this.patientDrugModel.drug.drugDescription = drug.drugDescription;
    this.patientDrugModel.drug.drugManufacturerName = drug.drugManufacturerName;
    this.patientDrugModel.drug.drugForm = drug.drugForm;
    this.patientDrugModel.drug.drugStrength = drug.drugStrength;
    this.patientDrugModel.drug.drugGenericName = drug.drugGenericName;

  }

  addDrug() {
    this.dialog.close({ data: this.patientDrugModel });
  }

  closeDialog() {
    this.dialog.close();
  }
}
