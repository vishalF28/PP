import { startWith, map } from 'rxjs/operators';
import { FormControl } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { Diagnosis } from './../../interfaces/diagnosis.model';
import { Component, OnInit, Inject } from '@angular/core';
import { PatientVisitService } from '../../services/patient-visit.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CompileShallowModuleMetadata } from '@angular/compiler';

@Component({
  selector: 'app-add-diagnosis',
  templateUrl: './add-diagnosis.component.html',
  styleUrls: ['./add-diagnosis.component.css'],
})
export class AddDiagnosisComponent implements OnInit {
  filteredDiagnosisDataSet: Observable<Diagnosis[]>;
  diagnosisDataSet: Diagnosis[] = [];
  diagnosisSearch = new FormControl();
  fieldDisabled: boolean = true;

  patientDiagnosisModel: any = {
    appointmentId: 0,
    diagnosis: {
      diagnosisId: 0,
      diagnosisCode: '',
      diagnosisDescription: '',
      isDeprecated: false,
    },
  };

  constructor(
    @Inject(MAT_DIALOG_DATA) public appointmentId: number,
    private patientVisitService: PatientVisitService,
    private dialog: MatDialogRef<AddDiagnosisComponent>
  ) {}

  ngOnInit(): void {
    this.patientDiagnosisModel.appointmentId=this.appointmentId;
    this.patientVisitService
      .getDiagnosisData()
      .subscribe((response) => (this.diagnosisDataSet = response));
    this.filteredDiagnosisDataSet = this.diagnosisSearch.valueChanges.pipe(
      startWith(''),
      map((diagnosis) =>
        diagnosis
          ? this._diagnosisFilter(diagnosis)
          : this.diagnosisDataSet.slice()
      )
    );
  }

  private _diagnosisFilter(value: string) {
    const filterValue = value.toLowerCase();
    console.log(this.diagnosisDataSet);
    return this.diagnosisDataSet.filter(
      (diagnosis) =>
        diagnosis.diagnosisId.toString().includes(filterValue) ||
        diagnosis.diagnosisCode.toLocaleLowerCase().includes(filterValue) ||
        diagnosis.diagnosisDescription.toLocaleLowerCase().includes(filterValue)
    );
  }

  setDiagnosisValue(diagnosisCode) {
    const diagnosis = this.diagnosisDataSet.find(
      (value) => value.diagnosisCode === diagnosisCode
    );
    if (diagnosis.diagnosisCode === 'Other') {
      this.fieldDisabled = false;
    } else {
      this.fieldDisabled = true;
    }
    this.patientDiagnosisModel.diagnosis.diagnosisId = diagnosis.diagnosisId;
    this.patientDiagnosisModel.diagnosis.diagnosisCode =
      diagnosis.diagnosisCode;
    this.patientDiagnosisModel.diagnosis.diagnosisDescription =
      diagnosis.diagnosisDescription;
    this.patientDiagnosisModel.diagnosis.isDepricated = diagnosis.isDeprecated;
  }

  addDiagnosis() {
    this.dialog.close({ data: this.patientDiagnosisModel });
  }

  closeDialog() {
    this.dialog.close();
  }
}
