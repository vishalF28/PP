import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletePatientDrugComponent } from './delete-patient-drug.component';

describe('DeletePatientDrugComponent', () => {
  let component: DeletePatientDrugComponent;
  let fixture: ComponentFixture<DeletePatientDrugComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeletePatientDrugComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletePatientDrugComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
