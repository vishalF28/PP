import { PatientDrug } from './../../interfaces/patient-durg-data';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, OnInit, Inject } from '@angular/core';
@Component({
  selector: 'app-delete-patient-drug',
  templateUrl: './delete-patient-drug.component.html',
  styleUrls: ['./delete-patient-drug.component.css'],
})
export class DeletePatientDrugComponent implements OnInit {
  constructor(
    private dialog: MatDialogRef<DeletePatientDrugComponent>,
    @Inject(MAT_DIALOG_DATA) public drugData: PatientDrug
  ) {}

  ngOnInit(): void {}

  doAction() {
    this.dialog.close({ response: 'Yes' });
  }

  closeDialog() {
    this.dialog.close();
  }
}
