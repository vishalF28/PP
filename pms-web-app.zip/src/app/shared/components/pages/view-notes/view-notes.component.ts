import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { NotesView } from '../../interfaces/notes-view.model';
import { NotesService } from '../../services/notes.service';
import { ReplyReceiverNotesComponent } from '../reply-receiver-notes/reply-receiver-notes.component';

@Component({
  selector: 'app-view-notes',
  templateUrl: './view-notes.component.html',
  styleUrls: ['./view-notes.component.css']
})
export class ViewNotesComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  dataSourceNotes: MatTableDataSource<NotesView> = new MatTableDataSource();
  notesSubscription: Subscription;
  resultlength: number;
  notes: NotesView[] = [];

  chatNote: any[] = [{ chatId: 0, senderName: '', senderDesignation: '', isUrgent: '' }];

  displayedColumns: string[] = ['senderName', 'senderDesignation', 'isUrgent', 'action1', 'action2'];


  constructor(private authService: AuthorizationService, private noteService: NotesService,
    private dialog: MatDialog, private snackBar: MatSnackBar, public loader: LoaderService) { }

  ngOnInit(): void {
    this.notesSubscription = this.noteService.getNotesMessages(this.authService.getEmail())
      .subscribe((response) => {
        this.dataSourceNotes.data = response;
        this.dataSourceNotes.sort = this.sort;
        this.dataSourceNotes.paginator = this.paginator;
        this.resultlength = this.dataSourceNotes.data.length;
      });
    console.log("this.dataSource", this.dataSourceNotes);

  }

  doFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceNotes.filter = filterValue.trim().toLowerCase();
    if (this.dataSourceNotes.paginator) {
      this.dataSourceNotes.paginator.firstPage();
    }
  }

  viewNoteDetail(chatId: number) {
    this.dataSourceNotes.data.forEach(note => {
      if (note.chatId === chatId) {
        note.isViewed = true;
      }
    });
    this.noteService.getReceiverNotesBasedOnChatId(chatId).subscribe(response => {
      this.noteService.sendNotification().subscribe();
      this.dialog.open(ReplyReceiverNotesComponent, { data: response })
    });
  }

  deleteNote(chatId: number) {
    this.noteService.deleteReceiverNotesBasedOnChatId(chatId).subscribe(response => {
      this.dataSourceNotes.data = this.dataSourceNotes.data.filter((noteElement) => {
        return noteElement.chatId != chatId;
      });
      this.snackBar.open("Deleted note from conversation successfully", undefined, { duration: 3000 });
      this.noteService.sendNotification().subscribe();
    })
  }
}
