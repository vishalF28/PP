import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPatientProfileByStaffComponent } from './view-patient-profile-by-staff.component';

describe('ViewPatientProfileByStaffComponent', () => {
  let component: ViewPatientProfileByStaffComponent;
  let fixture: ComponentFixture<ViewPatientProfileByStaffComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewPatientProfileByStaffComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPatientProfileByStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
