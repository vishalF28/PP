import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatAccordion } from '@angular/material/expansion';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { PatientAllergy } from 'src/app/features/patient/interfaces/patient-allergy.model';
import { AddAllergyComponent } from 'src/app/features/patient/pages/add-allergy/add-allergy.component';
import { DeleteAllergyComponent } from 'src/app/features/patient/pages/delete-allergy/delete-allergy.component';
import { PatientService } from 'src/app/features/patient/services/patient.service';

@Component({
  selector: 'app-view-patient-profile-by-staff',
  templateUrl: './view-patient-profile-by-staff.component.html',
  styleUrls: ['./view-patient-profile-by-staff.component.css']
})
export class ViewPatientProfileByStaffComponent implements OnInit {

  @ViewChild(MatAccordion) accordion: MatAccordion;

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  dataSource: MatTableDataSource<PatientAllergy>;

  patientSubscription: Subscription;

  patientProfileModel: any = {
    userId: 0, patientId: 0, title: '', firstName: '', lastName: '',
    birthDate: Date, age: 0, gender: '', race: '', languagesKnown: '', emailId: '', ethnicity: '',
    homeAddress: '', contact: 0, allergyFlag: false, isActive: false
  };

  emergencyContactModel: any = {
    relativeId: 0, title: '', firstName: '', lastName: '',
    relationship: '', emailId: '', homeAddress: '', contact: '', portalAccess: ''
  };

  patientAllergyModel: any[] = [{
    patientAllergyMappingId: 0, patientId: 0, allergy: {
      allergyId: 0, allergyType: '', allergyName: '', allergyDescription: '', allergyClinicalInformation: '', isNewlyAdded: false
    }, isAllergyFatal: false,
    isAllergyDeleted: false
  }];

  emergencyContactHomeAddressValue = '';

  displayedColumns: string[] = ['allergyId', 'allergyType', 'allergyName', 'allergyDescription',
    'allergyClinicalInformation', 'isAllergyFatal', 'action'];

  resultlength: number = 0;

  constructor(private authService: AuthorizationService, private patientService: PatientService,
    private dialog: MatDialog, private snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) private patientEmailId: string,
    private profileDialogRef: MatDialogRef<ViewPatientProfileByStaffComponent>
  ) { }


  ngOnInit(): void {
    this.patientSubscription = this.patientProfileModel = this.patientService.getPatientProfileDetails(this.patientEmailId)
      .subscribe(
        (response) => {
          console.log(response);
          this.patientProfileModel = response;
          this.calculateAge(response.birthDate);
          this.dataSource = new MatTableDataSource(this.patientProfileModel.patientAllergy);
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
          this.patientAllergyModel = this.dataSource.data;
          if (response.emergencyContact != null) {
            this.emergencyContactModel = response.emergencyContact;
            this.emergencyContactHomeAddressValue = this.emergencyContactModel.homeAddress;
            if (this.emergencyContactModel.portalAccess == '') {
              this.emergencyContactModel.portalAccess = 'No';
            }
          }
          if (this.patientProfileModel.alleryFlag == '' || this.patientProfileModel.alleryFlag == null) {
            this.patientProfileModel.alleryFlag = 'No'
          }
        }
      );

  }

  public calculateAge(birthDate: Date): void {
    if (birthDate) {
      var timeDiff = Math.abs(Date.now() - new Date(birthDate).getTime());
      this.patientProfileModel.age = Math.floor(
        timeDiff / (1000 * 3600 * 24) / 365.25
      );
    }
  }

  savePatientProfile(patientDetailsForm: NgForm) {

    this.patientService.savePatientDetails(this.patientProfileModel, this.emergencyContactModel,
      this.patientAllergyModel).subscribe((response) => {
        if (response) {
          this.snackBar.open("Patient profile updated successfully.", undefined, { duration: 3000 });
          this.patientProfileModel = response;
          this.calculateAge(response.birthDate);
          this.patientAllergyModel = this.dataSource.data;
          if (response.emergencyContact != null) {
            this.emergencyContactModel = response.emergencyContact;
            this.emergencyContactHomeAddressValue = this.emergencyContactModel.homeAddress;
          }
        }
      });
    this.profileDialogRef.close();
  }

  copyAdderess(checked: boolean) {
    if (checked) {
      this.emergencyContactModel.homeAddress = this.patientProfileModel.homeAddress;
    }
    else {
      this.emergencyContactModel.homeAddress = this.emergencyContactHomeAddressValue;
    }
  }

  openDeleteDialog(allergyData) {
    const dialogRef = this.dialog.open(DeleteAllergyComponent, {
      data: allergyData,
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.response === 'Yes') {
        this.patientService.deleteAllergyForPatient(allergyData.patientAllergyMappingId);
        this.dataSource.data = this.dataSource.data.filter((allergyElement) => {
          return allergyElement.allergy.allergyId != allergyData.allergy.allergyId;
        });
      }
    })
  }

  openAddDialog() {
    const dialogRef = this.dialog.open(AddAllergyComponent, { disableClose: true });
    dialogRef.afterClosed().subscribe((result) => {
      if (result && result.allergyData) {
        const allergyExist = this.dataSource.data.findIndex(
          allergyElement => allergyElement.allergy.allergyId === result.allergyData.allergy.allergyId)
        if (allergyExist == -1 || result.allergyData.allergy.allergyType === 'Other') {
          this.dataSource.data.push(result.allergyData);
          result.allergyData.patientId = this.patientProfileModel.patientId;
          this.patientService.addAllergy(result.allergyData);
          this.dataSource.filter = '';
        }
        else {
          this.snackBar.open("Allergy alredy exist", undefined, { duration: 3000 })
        }
      }
    });
  }

  closeDialog() {
    this.profileDialogRef.close();
  }
  ngOnDestroy() {
    this.patientSubscription.unsubscribe();
  }

}
