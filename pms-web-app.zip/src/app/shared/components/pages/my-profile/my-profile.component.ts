import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { HospitalStaffProfile } from '../../interfaces/hospital-staff-profile.model';
import { StaffService } from '../../services/staff.service';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {

  isDisabled: boolean = true;
  updateFlag: boolean = false;
  staffProfile: HospitalStaffProfile = new HospitalStaffProfile();

  constructor(
    private authService: AuthorizationService,
    private staffService: StaffService,
  ) { }

  ngOnInit(): void {
    this.staffProfile = this.staffService.getStaffProfileDetails(
      this.authService.getEmail()
    );
  }

  updateStaffProfile(profiledetails: NgForm) {
    this.staffService.updateAdminProfileDetails(this.staffProfile);
    this.updateFlag = false;
    this.isDisabled = true;
    profiledetails.disabled;
  }

  enableProfile(profiledetails: NgForm) {
    this.isDisabled = false;
    this.updateFlag = true;
    profiledetails.enabled;
  }

}
