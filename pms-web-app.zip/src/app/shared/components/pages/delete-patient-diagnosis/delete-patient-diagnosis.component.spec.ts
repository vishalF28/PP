import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletePatientDiagnosisComponent } from './delete-patient-diagnosis.component';

describe('DeletePatientDiagnosisComponent', () => {
  let component: DeletePatientDiagnosisComponent;
  let fixture: ComponentFixture<DeletePatientDiagnosisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeletePatientDiagnosisComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletePatientDiagnosisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
