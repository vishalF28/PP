import { Diagnosis } from './../../interfaces/diagnosis.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'app-delete-patient-diagnosis',
  templateUrl: './delete-patient-diagnosis.component.html',
  styleUrls: ['./delete-patient-diagnosis.component.css'],
})
export class DeletePatientDiagnosisComponent implements OnInit {
  constructor(
    private dialog: MatDialogRef<DeletePatientDiagnosisComponent>,
    @Inject(MAT_DIALOG_DATA) public diagnosisData: Diagnosis
  ) {}

  ngOnInit(): void {}

  doAction() {
    this.dialog.close({ response: 'Yes' });
  }

  closeDialog() {
    this.dialog.close();
  }
}
