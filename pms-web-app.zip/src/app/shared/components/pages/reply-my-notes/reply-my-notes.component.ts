import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NotesView } from '../../interfaces/notes-view.model';
import { NotesService } from '../../services/notes.service';

@Component({
  selector: 'app-reply-my-notes',
  templateUrl: './reply-my-notes.component.html',
  styleUrls: ['./reply-my-notes.component.css']
})
export class ReplyMyNotesComponent implements OnInit {

  noteViewModel: any[] = [];
  message: string;
  replyHidden: boolean = false;
  currentNoteView: NotesView;
  constructor(@Inject(MAT_DIALOG_DATA) private noteView: NotesView[],
    private noteService: NotesService, private dialogRef: MatDialogRef<ReplyMyNotesComponent>) { }

  ngOnInit(): void {
    this.noteViewModel = this.noteView;
    console.log(this.noteViewModel)
    this.currentNoteView = this.noteViewModel[0];
    this.noteView.forEach(note => {
      if (note.isDeleted === true) {
        this.replyHidden = true;
      }
    });
  }

  replyNote() {
    this.currentNoteView.message = this.message;
    this.noteService.saveMyReplyMessage(this.currentNoteView).subscribe(response => {
      this.noteService.sendNotification().subscribe();
      this.dialogRef.close();
    });
  }

  closeNote() {
    this.dialogRef.close();
  }
}
