import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplyMyNotesComponent } from './reply-my-notes.component';

describe('ReplyMyNotesComponent', () => {
  let component: ReplyMyNotesComponent;
  let fixture: ComponentFixture<ReplyMyNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReplyMyNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplyMyNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
