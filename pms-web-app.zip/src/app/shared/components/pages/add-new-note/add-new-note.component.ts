import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { NotesService } from '../../services/notes.service';

@Component({
  selector: 'app-add-new-note',
  templateUrl: './add-new-note.component.html',
  styleUrls: ['./add-new-note.component.css']
})
export class AddNewNoteComponent implements OnInit {

  filteredPhysicianDataSet: Observable<any[]>;
  physicianDataSet: any[] = [];
  physicianSearch = new FormControl();
  physicianModel: any = { emailId: '', fullName: '', physicianId: 0, role: '' };
  noteViewModel = {
    noteId: 0, senderName: '', senderDesignation: '', message: '', isUrgent: false,
    receiverName: '', receiverDesignation: '', senderEmailId: '', receiverEmailId: ''
  };

  constructor(private notesService: NotesService, private authService: AuthorizationService,
    private snackBar: MatSnackBar, private dialogRef: MatDialogRef<AddNewNoteComponent>) { }

  ngOnInit(): void {
    this.notesService.getPhysicianData().subscribe(response => {
      this.physicianDataSet = response;
      const findIndexOfCurrentUser = this.physicianDataSet.findIndex(
        (physican) => physican.emailId === this.authService.getEmail()
      );
      this.physicianDataSet.splice(findIndexOfCurrentUser, 1);
    });



    this.filteredPhysicianDataSet = this.physicianSearch.valueChanges
      .pipe(
        startWith(''),
        map(physician => physician ? this.physicianFilter(physician) : this.physicianDataSet.slice())
      );
  }

  private physicianFilter(value: string): any[] {
    const filterValue = value.toLowerCase();

    return this.physicianDataSet.filter(physician =>
      physician.firstName.toLocaleLowerCase().includes(filterValue) ||
      physician.lastName.toLocaleLowerCase().includes(filterValue)
    );
  }

  setPhysicianName(physicianEmailId: any) {
    const physician = this.physicianDataSet.find(value => value.emailId === physicianEmailId);
    this.noteViewModel.receiverEmailId = physicianEmailId;
    this.noteViewModel.receiverName = physician.title + ". " + physician.firstName + " " + physician.lastName;
    this.noteViewModel.receiverDesignation = physician.role;
  }

  sendNote() {
    this.noteViewModel.senderEmailId = this.authService.getEmail();
    this.noteViewModel.senderName = this.authService.getTitle() + ". " + this.authService.getFirstName() + " " + this.authService.getLastName();
    this.noteViewModel.senderDesignation = this.authService.getRole();
    this.notesService.sendNote(this.noteViewModel).subscribe(response => {
      this.snackBar.open("Note sent successfully", undefined, { duration: 3000 });
      this.dialogRef.close();
      this.notesService.sendNotification().subscribe();
    });
  }

  closeDialog() {
    this.dialogRef.close();
  }
}
