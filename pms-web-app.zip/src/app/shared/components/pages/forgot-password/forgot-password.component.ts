import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoaderService } from 'src/app/core/services/loader.service';
import { ForgotPasswordService } from '../../services/forgot-password.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  emailId: '';

  constructor(public loader: LoaderService, private forgotPasswordService: ForgotPasswordService) { }

  ngOnInit(): void { }

  forgotPassword(forgotPasswordForm: NgForm) {
    this.forgotPasswordService.forgotPassword(this.emailId);
    forgotPasswordForm.resetForm();
  }

}
