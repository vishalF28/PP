import { AppointmentView } from './../../../../features/patient/interfaces/appointment-view.model';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { PatientVisitService } from '../../services/patient-visit.service';
import { AuthorizationService } from '../../../../features/authorization/services/authorization.service';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TimingSlots } from '../../interfaces/timing-slots.model';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/core/services/loader.service';

@Component({
  selector: 'app-view-appointments',
  templateUrl: './view-appointments.component.html',
  styleUrls: ['./view-appointments.component.css'],
})
export class ViewAppointmentsComponent implements OnInit {
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  dataSourceAppointments: MatTableDataSource<AppointmentView> =
    new MatTableDataSource();
  appointmentSubscription: Subscription;
  resultlength: number;
  appointmentDetails: AppointmentView[] = [];

  displayedColumns: string[] = [
    'appointmentId',
    'title',
    'patientName',
    'physicianName',
    'dateOfAppointment',
    'timeOfAppointment',
    'action',
  ];

  constructor(
    public router: Router,
    private patientVisitService: PatientVisitService,
    private authService: AuthorizationService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    public loader: LoaderService
  ) { }

  ngOnInit(): void {
    this.appointmentSubscription = this.patientVisitService
      .getUpcomingAppointments(this.authService.getEmail())
      .subscribe((response) => {
        console.log(response);
        response.forEach((appointment) => {
          const appointmentHistoryModel: any = {
            appointmentId: 0,
            title: '',
            physicianEmailId: '',
            dateOfAppointment: new Date(),
            timeOfAppointment: '',
            isVisited: false,
            isRescheduled: false,
            isDeleted: false,
            physicianName: '',
            patientName: '',
            patientId: 0,
          };
          appointmentHistoryModel.appointmentId = appointment.appointmentId;
          appointmentHistoryModel.title = appointment.title;
          appointmentHistoryModel.dateOfAppointment =
            appointment.dateOfAppointment;
          appointmentHistoryModel.physicianEmailId =
            appointment.physicianEmailId;
          appointmentHistoryModel.physicianName = appointment.physicianName;
          appointmentHistoryModel.patientName = appointment.patientName;
          appointmentHistoryModel.timeOfAppointment =
            TimingSlots[appointment.timeOfAppointment];
          appointmentHistoryModel.isVisited = appointment.isVisited;
          appointmentHistoryModel.isRescheduled = appointment.isRescheduled;
          appointmentHistoryModel.isDeleted = appointment.isDeleted;
          appointmentHistoryModel.patientId = appointment.patientId;
          this.appointmentDetails.push(appointmentHistoryModel);
        });
        this.dataSourceAppointments = new MatTableDataSource(
          this.appointmentDetails
        );
        this.dataSourceAppointments.sort = this.sort;
        this.dataSourceAppointments.paginator = this.paginator;
        this.resultlength = this.dataSourceAppointments.data.length;
      });
  }

  doFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceAppointments.filter = filterValue.trim().toLowerCase();

    if (this.dataSourceAppointments.paginator) {
      this.dataSourceAppointments.paginator.firstPage();
    }
  }
}
