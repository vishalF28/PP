import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { NotesView } from '../../interfaces/notes-view.model';
import { NotesService } from '../../services/notes.service';
import { AddNewNoteComponent } from '../add-new-note/add-new-note.component';
import { ReplyMyNotesComponent } from '../reply-my-notes/reply-my-notes.component';

@Component({
  selector: 'app-my-notes',
  templateUrl: './my-notes.component.html',
  styleUrls: ['./my-notes.component.css']
})
export class MyNotesComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  dataSourceNotes: MatTableDataSource<NotesView> = new MatTableDataSource();
  notesSubscription: Subscription;
  resultlength: number;
  notes: NotesView[] = [];


  displayedColumns: string[] = ['receiverName', 'receiverDesignation', 'isUrgent', 'action1', 'action2'];

  constructor(private dialog: MatDialog, private authService: AuthorizationService,
    private noteService: NotesService, private snackBar: MatSnackBar, public loader: LoaderService) { }

  ngOnInit(): void {
    this.notesSubscription = this.noteService.getMyNotesMessages(this.authService.getEmail())
      .subscribe((response) => {
        this.dataSourceNotes.data = response;
        this.dataSourceNotes.sort = this.sort;
        this.dataSourceNotes.paginator = this.paginator;
        this.resultlength = this.dataSourceNotes.data.length;
      })
  }

  doFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceNotes.filter = filterValue.trim().toLowerCase();
    if (this.dataSourceNotes.paginator) {
      this.dataSourceNotes.paginator.firstPage();
    }
  }

  addNewNote() {
    const dialogRef = this.dialog.open(AddNewNoteComponent, {
      disableClose: false,
    });
  }

  viewNoteDetail(chatId: number) {
    this.dataSourceNotes.data.forEach(note => {
      if (note.chatId === chatId) {
        note.isViewed = true;
      }
    });
    this.noteService.getMyNotesBasedOnChatId(chatId).subscribe(response => {
      this.noteService.sendNotification().subscribe();
      this.dialog.open(ReplyMyNotesComponent, { data: response })
    });
  }

  deleteNote(chatId: number) {
    this.noteService.deleteSenderNotesBasedOnChatId(chatId).subscribe(response => {
      this.dataSourceNotes.data = this.dataSourceNotes.data.filter((noteElement) => {
        return noteElement.chatId != chatId;
      });
      this.snackBar.open("Deleted note from conversation successfully", undefined, { duration: 3000 });
      this.noteService.sendNotification().subscribe();
    })
  }
}
