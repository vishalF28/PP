import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { NotesView } from '../../interfaces/notes-view.model';
import { NotesService } from '../../services/notes.service';

@Component({
  selector: 'app-reply-receiver-notes',
  templateUrl: './reply-receiver-notes.component.html',
  styleUrls: ['./reply-receiver-notes.component.css']
})
export class ReplyReceiverNotesComponent implements OnInit {

  noteViewModel: any[] = [];
  message: string;
  replyHidden: boolean = false;
  currentNoteView: NotesView;
  currentLoginUser: string;

  constructor(@Inject(MAT_DIALOG_DATA) private noteView: NotesView[],
    private noteService: NotesService, private dialogRef: MatDialogRef<ReplyReceiverNotesComponent>,
    private authService: AuthorizationService) { }

  ngOnInit(): void {
    this.noteViewModel = this.noteView;
    this.currentLoginUser = this.authService.getEmail();
    console.log(this.noteViewModel);
    this.currentNoteView = this.noteViewModel[0];
    this.noteView.forEach(note => {
      if (note.isDeleted === true) {
        this.replyHidden = true;
      }
    });

  }

  replyNote() {
    this.currentNoteView.message = this.message;
    this.noteService.saveReceiverReplyMessage(this.currentNoteView).subscribe(response => {
      this.noteService.sendNotification().subscribe();
      this.dialogRef.close();
    });
  }

  closeNote() {
    this.dialogRef.close();
  }
}
