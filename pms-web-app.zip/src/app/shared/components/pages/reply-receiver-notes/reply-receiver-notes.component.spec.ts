import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplyReceiverNotesComponent } from './reply-receiver-notes.component';

describe('ReplyReceiverNotesComponent', () => {
  let component: ReplyReceiverNotesComponent;
  let fixture: ComponentFixture<ReplyReceiverNotesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReplyReceiverNotesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplyReceiverNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
