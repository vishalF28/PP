import { Component, OnInit } from '@angular/core';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';

@Component({
  selector: 'app-manage-notes',
  templateUrl: './manage-notes.component.html',
  styleUrls: ['./manage-notes.component.css']
})
export class ManageNotesComponent implements OnInit {

  currentLoginRole: string;

  constructor(private authService: AuthorizationService) { }

  ngOnInit(): void {
    this.currentLoginRole = this.authService.getRole();
  }

}
