import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { ChangePasswordService } from '../../services/change-password.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css'],
})
export class ChangePasswordComponent implements OnInit {
  changepasswordviewmodel = {
    emailId: '',
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  };

  oldPassword: boolean = true;
  newPassword: boolean = true;
  confirmPassword: boolean = true;

  constructor(
    private authService: AuthorizationService,
    private changePasswordService: ChangePasswordService
  ) {}

  ngOnInit(): void {
    this.changepasswordviewmodel.emailId = this.authService.getEmail();
  }

  changePassword(changePasswordForm: NgForm) {
    this.changePasswordService.changePasswordService(
      this.changepasswordviewmodel
    );
    this.clearForm(changePasswordForm);
  }

  clearForm(changePasswordForm: NgForm) {
    changePasswordForm.resetForm();
  }
}
