import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ChangePasswordComponent } from './change-password.component';
import { AuthorizationService } from '../../../../features/authorization/services/authorization.service';
import { ChangePasswordService } from '../../services/change-password.service';
import { FormsModule, NgForm } from '@angular/forms';
import { HttpService } from '../../../../core/services/http.service';
import { MatSnackBar } from '@angular/material/snack-bar';

describe('ChangePasswordComponent', () => {
  let mockAuthorizationService;
  let mockChangePasswordService: ChangePasswordService;
  let component: ChangePasswordComponent;
  let fixture: ComponentFixture<ChangePasswordComponent>;
  let httpService: HttpService;
  let snackBar: MatSnackBar;
  let testForm: NgForm;
  let spy: any;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChangePasswordComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    mockAuthorizationService = jasmine.createSpyObj(['getEmail']);
    testForm = jasmine.createSpyObj(['resetForm']);
    //mockChangePasswordService = jasmine.createSpyObj(['changePasswordService']);
    mockChangePasswordService = new ChangePasswordService(
      httpService,
      snackBar,
      mockAuthorizationService
    );
    TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [ChangePasswordComponent],
      providers: [
        {
          provide: AuthorizationService,
          useValue: mockAuthorizationService,
        },
        {
          provide: ChangePasswordService,
          useValue: mockChangePasswordService,
        },
      ],
    });
    mockAuthorizationService.getEmail.and.returnValue(
      'satpal.chhabra@citiustech.com'
    );
    fixture = TestBed.createComponent(ChangePasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should call the changePassword function of the ChangePasswordService', () => {
    testForm = <NgForm>{
      value: {
        oldPassword: 'Admin@123',
        newPassword: 'Admin@1234',
        confirmPassword: 'Admin@1234',
      },
    };
    spyOn(component, 'clearForm');
    spy = spyOn(mockChangePasswordService, 'changePasswordService');
    component.changePassword(testForm);
    expect(spy).toHaveBeenCalled();
  });
});
