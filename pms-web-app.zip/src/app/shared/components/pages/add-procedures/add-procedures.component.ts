import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PatientVisitService } from './../../services/patient-visit.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { Component, OnInit, Inject } from '@angular/core';
import { startWith, map } from 'rxjs/operators';
import { Procedure } from '../../interfaces/procedure.model';
import { PatientProcedure } from '../../interfaces/patient-procedure';

@Component({
  selector: 'app-add-procedures',
  templateUrl: './add-procedures.component.html',
  styleUrls: ['./add-procedures.component.css'],
})
export class AddProceduresComponent implements OnInit {
  filteredProcedureDataSet: Observable<Procedure[]>;
  procedureDataSet: Procedure[] = [];
  procedureSearch = new FormControl();
  fieldDisabled: boolean = true;

  patientProcedureModel: any = {
    patientProcedureMappingId: 0,
    patientId: 0,
    procedure: {
      procedureId: 0,
      procedureCode: 0,
      procedureDescription: '',
    },
  };

  constructor(
    @Inject(MAT_DIALOG_DATA) public appointmentId: number,
    private patientVisitService: PatientVisitService,
    private dialog: MatDialogRef<AddProceduresComponent>
  ) {}

  ngOnInit(): void {
    this.patientProcedureModel.appointmentId = this.appointmentId;
    this.patientVisitService
      .getProcedureData()
      .subscribe((response) => (this.procedureDataSet = response));
    this.filteredProcedureDataSet = this.procedureSearch.valueChanges.pipe(
      startWith(''),
      map((procedure) =>
        procedure
          ? this._procedureFilter(procedure)
          : this.procedureDataSet.slice()
      )
    );
  }

  private _procedureFilter(value: string): Procedure[] {
    const filterValue = value.toLowerCase();
    return this.procedureDataSet.filter(
      (procedure) =>
        procedure.procedureId.toString().includes(filterValue) ||
        procedure.procedureCode.toLocaleLowerCase().includes(filterValue) ||
        procedure.procedureDescription.toLocaleLowerCase().includes(filterValue)
    );
  }

  setProcedureValue(procedureCode) {
    const procedure = this.procedureDataSet.find(
      (value) => value.procedureCode === procedureCode
    );
    if (procedure.procedureCode === 'Other') {
      this.fieldDisabled = false;
    } else {
      this.fieldDisabled = true;
    }
    this.patientProcedureModel.procedure.procedureId = procedure.procedureId;
    this.patientProcedureModel.procedure.procedureCode =
      procedure.procedureCode;

    this.patientProcedureModel.procedure.procedureDescription =
      procedure.procedureDescription;
  }

  addProcedure() {
    this.dialog.close({ data: this.patientProcedureModel });
  }

  closeDialog() {
    this.dialog.close();
  }
}
