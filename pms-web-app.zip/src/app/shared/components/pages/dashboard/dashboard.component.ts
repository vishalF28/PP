import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  private authListner: Subscription;
  userIsAuthenticated = false;
  role: string;

  constructor(private authService: AuthorizationService) { }

  ngOnInit(): void {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.role = this.authService.getRole();
    this.authListner = this.authService.getAuthStatusListener().subscribe(
      isAuthenticated => { this.userIsAuthenticated = isAuthenticated; }
    );
  }

  ngOnDestroy() {
    this.authListner.unsubscribe();
  }

}
