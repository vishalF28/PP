import { NgModule } from '@angular/core';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSlideToggleModule } from '@angular/material/slide-toggle'
import { MatBadgeModule } from '@angular/material/badge';

@NgModule({
  declarations: [],
  imports: [
    MatSidenavModule, MatButtonModule, MatToolbarModule, MatButtonModule, MatIconModule
    , MatListModule, MatCardModule, MatExpansionModule, MatInputModule, MatFormFieldModule
    , MatSnackBarModule, MatSelectModule, MatRadioModule, MatAutocompleteModule, MatDatepickerModule, MatNativeDateModule,
    MatProgressSpinnerModule, MatTableModule, MatSortModule, MatPaginatorModule, MatGridListModule, MatCheckboxModule,
    MatProgressBarModule, MatStepperModule, MatChipsModule, MatDialogModule, MatTabsModule, MatSlideToggleModule,
    MatBadgeModule
  ],
  exports: [
    MatSidenavModule, MatButtonModule, MatToolbarModule, MatButtonModule, MatIconModule
    , MatListModule, MatCardModule, MatExpansionModule, MatInputModule, MatFormFieldModule
    , MatSnackBarModule, MatSelectModule, MatRadioModule, MatAutocompleteModule, MatDatepickerModule, MatNativeDateModule,
    MatProgressSpinnerModule, MatTableModule, MatSortModule, MatPaginatorModule, MatGridListModule, MatCheckboxModule,
    MatProgressBarModule, MatStepperModule, MatChipsModule, MatDialogModule, MatTabsModule, MatSlideToggleModule,
    MatBadgeModule
  ]
})
export class MaterialModule { }
