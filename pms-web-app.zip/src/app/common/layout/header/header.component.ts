import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() isDarkTheme: boolean = false;
  @Output() themeToggle = new EventEmitter<boolean>();

  @Output() sidenavToggle = new EventEmitter<void>();

  private authListner: Subscription;
  userIsAuthenticated = false;

  constructor(private authService: AuthorizationService) { }

  ngOnInit(): void {
    this.userIsAuthenticated = this.authService.getIsAuth();
    this.authListner = this.authService.getAuthStatusListener().subscribe(
      isAuthenticated => { this.userIsAuthenticated = isAuthenticated; }
    );
    this.isDarkTheme = sessionStorage.getItem('theme') === "Dark" ? true : false;
  }

  onToggleSidebar() {
    this.sidenavToggle.emit();
  }

  changeTheme() {
    this.isDarkTheme = !this.isDarkTheme;
    sessionStorage.setItem('theme', this.isDarkTheme ? "Dark" : "Light");
    this.themeToggle.emit(this.isDarkTheme);
  }
  onDestroy() {
    this.authListner.unsubscribe();
  }
}
