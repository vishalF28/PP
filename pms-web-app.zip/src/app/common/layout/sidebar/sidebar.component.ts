import { MediaMatcher } from '@angular/cdk/layout';
import { ChangeDetectorRef } from '@angular/core';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Subscription } from 'rxjs';
import { NotificationSocketService } from 'src/app/core/services/notification-socket.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  @Output() sideNavClose = new EventEmitter<void>();

  title: string = '';
  firstName: string = '';
  lastName: string = '';
  role: string = '';

  private authListner: Subscription;
  userIsAuthenticated = false;

  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;

  public notifications = 0;

  public notificationDataList: any[] = [];

  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher,
    private authService: AuthorizationService, private notificationService: NotificationSocketService) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
  }

  ngOnInit(): void {
    this.authListner = this.authService.getAuthStatusListener().subscribe(
      isAuthenticated => { this.userIsAuthenticated = isAuthenticated; }
    );

    // Open connection with server socket
    let stompClient = this.notificationService.connect();
    stompClient.connect({}, frame => {
      stompClient.subscribe('/topic/notification', notifications => {
        console.log(notifications);
        this.notificationDataList = JSON.parse(notifications.body);
        this.notificationDataList.forEach(notification => {
          const currentLoggedInUser = this.authService.getEmail();
          if (currentLoggedInUser == notification.emailId) {
            this.notifications = notification.senderCount + notification.receiverCount;
          }
        })

      })
    });
  }

  ngDoCheck(): void {
    this.userIsAuthenticated = this.authService.getIsAuth();
    if (this.userIsAuthenticated) {
      this.role = this.authService.getRole();
      this.firstName = this.authService.getFirstName();
      this.lastName = this.authService.getLastName();
      this.title = this.authService.getTitle();
    }
  }

  onClose() {
    if (this.mobileQuery.matches) {
      this.sideNavClose.emit();
    }
  }

  logout() {
    this.authService.logout();
  }

  ngOnDestroy() {
    this.authListner.unsubscribe();
  }


}
