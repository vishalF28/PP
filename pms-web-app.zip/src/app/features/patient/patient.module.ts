import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignupComponent } from './pages/signup/signup.component';
import { MaterialModule } from 'src/app/common/material/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PatientProfileComponent } from './pages/patient-profile/patient-profile.component';
import { AddAllergyComponent } from './pages/add-allergy/add-allergy.component';
import { DeleteAllergyComponent } from './pages/delete-allergy/delete-allergy.component';
import { PatientDashboardComponent } from './pages/patient-dashboard/patient-dashboard.component';
import { PatientAppointmentHistoryComponent } from './pages/patient-appointment-history/patient-appointment-history.component';



@NgModule({
  declarations: [
    SignupComponent,
    PatientProfileComponent,
    AddAllergyComponent,
    DeleteAllergyComponent,
    PatientDashboardComponent,
    PatientAppointmentHistoryComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  exports: [SignupComponent, PatientProfileComponent, PatientDashboardComponent]
})
export class PatientModule { }
