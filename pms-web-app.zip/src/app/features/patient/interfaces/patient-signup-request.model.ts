export interface PatientSignUpRequest {
    title: string;
    firstName: string;
    lastName: string;
    birthDate: Date;
    contact: string;
    emailId: string;
    password: string;
    gender: string;
}