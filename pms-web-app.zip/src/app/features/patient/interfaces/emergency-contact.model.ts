export class EmergencyContact {
    relativeId: number;
    title: string;
    firstName: string;
    lastName: string;
    relationship: string;
    emailId: string;
    homeAddress: string;
    contact: string;
    portalAccess: string;
}
