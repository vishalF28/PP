
export interface AppointmentView {
    appointmentId: number;
    title: string;
    physicianEmailId: string;
    physicianName: string;
    patientName: string;
    dateOfAppointment: Date;
    timeOfAppointment: string;
    isVisited: boolean;
    isRescheduled: boolean;
    isDeleted: boolean;
    dataCollectionAppointmentBooked: boolean;
    readyForScheduling: boolean;
}