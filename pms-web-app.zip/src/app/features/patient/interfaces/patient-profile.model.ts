import { Allergy } from "./allergy.model";
import { EmergencyContact } from "./emergency-contact.model";
import { PatientAllergy } from "./patient-allergy.model";

export class PatientProfile {
    patientId: number;
    userId: number;
    title: string;
    firstName: string;
    lastName: string;
    birthDate: Date;
    age: number;
    gender: string;
    race: string;
    languagesKnown: string;
    emailId: string;
    ethnicity: string;
    homeAddress: string;
    contact: number;
    isActive: boolean;
    emergencyContact: EmergencyContact;
    patientAllergy: PatientAllergy[];
    allergyFlag: boolean;
}
