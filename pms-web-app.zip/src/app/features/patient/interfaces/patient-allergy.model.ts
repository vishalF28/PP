import { Allergy } from "./allergy.model";

export interface PatientAllergy {
    patientAllergyMappingId: number;
    patientId: number;
    allergy: Allergy;
    isAllergyFatal: string;
    isAllergyDeleted: boolean;
}