import { TimingSlots } from "src/app/shared/components/interfaces/timing-slots.model";

export interface AppointmentDetailsResponse {
    appointmentId: number;
    title: string;
    physicianEmailId: string;
    dateOfAppointment: Date;
    timeOfAppointment: TimingSlots;
    isVisited: boolean;
    isRescheduled: boolean;
    isDeleted: boolean;
}