import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PatientAllergy } from '../../interfaces/patient-allergy.model';

@Component({
  selector: 'app-delete-allergy',
  templateUrl: './delete-allergy.component.html',
  styleUrls: ['./delete-allergy.component.css']
})
export class DeleteAllergyComponent implements OnInit {

  constructor(private dialog: MatDialogRef<DeleteAllergyComponent>,
    @Inject(MAT_DIALOG_DATA) public allergyData: PatientAllergy) { }

  ngOnInit(): void {
  }

  doAction() {
    this.dialog.close({ response: 'Yes' });
  }

  closeDialog() {
    this.dialog.close();
  }

}
