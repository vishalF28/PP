import { Component, Inject, OnInit, Optional } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Allergy } from '../../interfaces/allergy.model';
import { PatientService } from '../../services/patient.service';

@Component({
  selector: 'app-add-allergy',
  templateUrl: './add-allergy.component.html',
  styleUrls: ['./add-allergy.component.css']
})
export class AddAllergyComponent implements OnInit {

  filteredAllergyDataSet: Observable<Allergy[]>;
  allergyDataSet: Allergy[] = [];
  allergySearch = new FormControl();
  fieldDisabled: boolean = true;


  patientAllergyModel: any = {
    patientAllergyMappingId: 0, patientId: 0, allergy: {
      allergyId: 0, allergyType: '', allergyName: '', allergyDescription: '', allergyClinicalInformation: '', isNewlyAdded: false
    }, isAllergyFatal: 'No',
    isAllergyDeleted: false
  };

  constructor(private patientService: PatientService,
    private dialog: MatDialogRef<AddAllergyComponent>) { }


  ngOnInit(): void {
    this.patientService.getAllergyData().subscribe(response => this.allergyDataSet = response);
    this.filteredAllergyDataSet = this.allergySearch.valueChanges
      .pipe(
        startWith(''),
        map(allergy => allergy ? this._allergyFilter(allergy) : this.allergyDataSet.slice())
      );
  }

  private _allergyFilter(value: string): Allergy[] {
    const filterValue = value.toLowerCase();
    return this.allergyDataSet.filter(allergy =>
      allergy.allergyId.toString().includes(filterValue) ||
      allergy.allergyName.toLocaleLowerCase().includes(filterValue) ||
      allergy.allergyType.toLocaleLowerCase().includes(filterValue) ||
      allergy.allergyClinicalInformation.toLocaleLowerCase().includes(filterValue) ||
      allergy.allergyDescription.toLocaleLowerCase().includes(filterValue)
    );
  }

  setAllergyValue(allergyName) {
    const allergy = this.allergyDataSet.find(value => value.allergyName === allergyName);
    if (allergy.allergyType === 'Other') {
      this.fieldDisabled = false;
      this.patientAllergyModel.allergy.isNewlyAdded = true;
    }
    else {
      this.fieldDisabled = true;
    }
    this.patientAllergyModel.allergy.allergyId = allergy.allergyId;
    this.patientAllergyModel.allergy.allergyType = allergy.allergyType;
    this.patientAllergyModel.allergy.allergyName = allergy.allergyName;
    this.patientAllergyModel.allergy.allergyClinicalInformation = allergy.allergyClinicalInformation;
    this.patientAllergyModel.allergy.allergyDescription = allergy.allergyDescription;

  }

  addAllergy() {
    this.dialog.close({ allergyData: this.patientAllergyModel });
  }

  closeDialog() {
    this.dialog.close();
  }

}
