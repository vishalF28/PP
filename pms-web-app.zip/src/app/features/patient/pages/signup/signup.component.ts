import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/core/services/loader.service';
import { PatientService } from '../../services/patient.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  hidePassword = true;
  hideConfirmPassword = true;

  todaysDate = new Date();

  patientSignupForm: any = {
    title: '', firstName: '', lastName: '', birthDate: null, contact: '', emailId: '',
    password: '', confirmPassword: '', gender: ''
  };

  constructor(private patientService: PatientService, public loader: LoaderService, private router: Router) { }

  ngOnInit(): void { }

  signUpPatient(signupForm: NgForm) {
    this.patientService.signUpPatient(this.patientSignupForm);
  }

}
