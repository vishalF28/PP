import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { TimingSlots } from 'src/app/shared/components/interfaces/timing-slots.model';
import { PatientService } from '../../services/patient.service';
import { AppointmentView } from '../../interfaces/appointment-view.model'

@Component({
  selector: 'app-patient-dashboard',
  templateUrl: './patient-dashboard.component.html',
  styleUrls: ['./patient-dashboard.component.css']
})
export class PatientDashboardComponent implements OnInit {

  appointmentSubscription: Subscription;

  todaysAppointments: any[] = [];
  upcomingAppointments: any[] = [];
  rejectedAppointments: any[] = [];

  tempDate: Date = new Date();
  todaysDate: Date = new Date(this.tempDate.getFullYear(), this.tempDate.getMonth(), this.tempDate.getDate());

  constructor(private patientService: PatientService, private authService: AuthorizationService) { }

  ngOnInit(): void {
    this.todaysDate.setHours(0, 0, 0, 0);
    this.appointmentSubscription = this.patientService.getUpcomingAppointments(this.authService.getEmail())
      .subscribe(
        (response) => {
          response.forEach(appointment => {
            const appointmentViewModel: AppointmentView = {
              appointmentId: 0, title: '', physicianEmailId: '', dateOfAppointment: new Date(),
              timeOfAppointment: '', isVisited: false, isRescheduled: false, isDeleted: false, physicianName: '', 
              patientName: '', readyForScheduling: false, dataCollectionAppointmentBooked: false
            };

            appointmentViewModel.appointmentId = appointment.appointmentId;
            appointmentViewModel.title = appointment.title;
            appointmentViewModel.dateOfAppointment = appointment.dateOfAppointment;
            appointmentViewModel.physicianEmailId = appointment.physicianEmailId;
            appointmentViewModel.timeOfAppointment = TimingSlots[appointment.timeOfAppointment];
            appointmentViewModel.isVisited = appointment.isVisited;
            appointmentViewModel.isRescheduled = appointment.isRescheduled;
            appointmentViewModel.isDeleted = appointment.isDeleted;
            appointmentViewModel.physicianName = appointment.physicianName;
            appointmentViewModel.patientName = appointment.patientName;
            const appointmentDate = new Date(appointment.dateOfAppointment);
            if (appointment.isDeleted === true) {
              this.rejectedAppointments.push(appointmentViewModel);
            }
            else if (appointmentDate.toDateString() == this.todaysDate.toDateString()) {
              this.todaysAppointments.push(appointmentViewModel);
            }
            else if (appointmentDate >= this.todaysDate) {
              this.upcomingAppointments.push(appointmentViewModel);
            }
          });

        }
      );
  }
}
