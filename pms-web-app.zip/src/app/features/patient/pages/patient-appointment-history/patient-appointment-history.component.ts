import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { TimingSlots } from 'src/app/shared/components/interfaces/timing-slots.model';
import { AppointmentDetailsResponse } from '../../interfaces/appointment-details.model';
import { AppointmentView } from '../../interfaces/appointment-view.model';
import { PatientService } from '../../services/patient.service';

@Component({
  selector: 'app-patient-appointment-history',
  templateUrl: './patient-appointment-history.component.html',
  styleUrls: ['./patient-appointment-history.component.css']
})
export class PatientAppointmentHistoryComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  dataSourceAppointmentHistory: MatTableDataSource<AppointmentView> = new MatTableDataSource();
  appointmentSubscription: Subscription;
  resultlength: number;
  appointmentDetails: AppointmentView[] = [];

  appointmentHistoryModel: AppointmentView = {
    appointmentId: 0, title: '', physicianEmailId: '', dateOfAppointment: new Date(),
    timeOfAppointment: '', isVisited: false, isRescheduled: false, isDeleted: false, 
    physicianName: '', patientName: '', dataCollectionAppointmentBooked: false,
    readyForScheduling: false
  };

  displayedColumns: string[] = ['appointmentId', 'title', 'physicianName', 'dateOfAppointment',
    'action', 'action2'];

  constructor(private patientService: PatientService, private authService: AuthorizationService
    , public router: Router) { }

  ngOnInit(): void {
    this.appointmentSubscription = this.patientService.getPatientAppointmentsHistory(this.authService.getEmail())
      .subscribe(
        (response) => {
          console.log('response', response);
          
          response.forEach(appointment => {
            const appointmentHistoryModel: AppointmentView = {
              appointmentId: 0, title: '', physicianEmailId: '', dateOfAppointment: new Date(),
              timeOfAppointment: '', isVisited: false, isRescheduled: false, isDeleted: false, physicianName: '', 
              patientName: '', readyForScheduling: false, dataCollectionAppointmentBooked: false
            };

            appointmentHistoryModel.appointmentId = appointment.appointmentId;
            appointmentHistoryModel.title = appointment.title;
            appointmentHistoryModel.dateOfAppointment = appointment.dateOfAppointment;
            appointmentHistoryModel.physicianEmailId = appointment.physicianEmailId;
            appointmentHistoryModel.physicianName = appointment.physicianName;
            appointmentHistoryModel.timeOfAppointment = TimingSlots[appointment.timeOfAppointment];
            appointmentHistoryModel.isVisited = appointment.isVisited;
            appointmentHistoryModel.isRescheduled = appointment.isRescheduled;
            appointmentHistoryModel.isDeleted = appointment.isDeleted;
            appointmentHistoryModel.readyForScheduling = appointment.readyForScheduling;
            appointmentHistoryModel.dataCollectionAppointmentBooked = appointment.dataCollectionAppointmentBooked;
            this.appointmentDetails.push(appointmentHistoryModel);
          });
          this.dataSourceAppointmentHistory = new MatTableDataSource(this.appointmentDetails);
          this.dataSourceAppointmentHistory.sort = this.sort;
          this.dataSourceAppointmentHistory.paginator = this.paginator;
          this.resultlength = this.dataSourceAppointmentHistory.data.length;
        }
      );
  }

  doFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceAppointmentHistory.filter = filterValue.trim().toLowerCase();

    if (this.dataSourceAppointmentHistory.paginator) {
      this.dataSourceAppointmentHistory.paginator.firstPage();
    }
  }

}
