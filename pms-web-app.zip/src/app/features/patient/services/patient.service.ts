import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';
import { Allergy } from '../interfaces/allergy.model';
import { AppointmentDetailsResponse } from '../interfaces/appointment-details.model';
import { EmergencyContact } from '../interfaces/emergency-contact.model';
import { PatientAllergy } from '../interfaces/patient-allergy.model';
import { PatientProfile } from '../interfaces/patient-profile.model';
import { PatientSignUpRequest } from '../interfaces/patient-signup-request.model';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private httpService: HttpService, private snackBar: MatSnackBar, private route: Router) { }

  signUpPatient(patientSignupForm: any) {
    let patientSignupRequest: PatientSignUpRequest = {
      title: patientSignupForm.title, firstName: patientSignupForm.firstName, lastName: patientSignupForm.lastName,
      birthDate: patientSignupForm.birthDate, contact: patientSignupForm.contact, emailId: patientSignupForm.emailId,
      password: patientSignupForm.password, gender: patientSignupForm.gender
    }
    this.httpService.post(environment.authbaseurl + "/authentication/patient-signup", patientSignupRequest).subscribe(
      (response) => {
        this.snackBar.open(response.message, undefined, { duration: 3000 });
        this.route.navigate(['/login']);
      }
    )
  }

  getPatientProfileDetails(emailId: string) {
    return this.httpService.get<PatientProfile>(environment.patientbaseurl + '/patient/get-patient-profile/' + emailId);
  }
  public calculateAge(birthDate: Date): number {
    if (birthDate) {
      var timeDiff = Math.abs(Date.now() - new Date(birthDate).getTime());
      return Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
    }
  }

  savePatientDetails(patientProfile: PatientProfile, emergencyContact: EmergencyContact, patientAllergy: PatientAllergy[]) {
    patientProfile.emergencyContact = emergencyContact;
    patientAllergy.forEach(allergy => { allergy.patientId = patientProfile.patientId });
    patientProfile.patientAllergy = patientAllergy;
    return this.httpService.put(environment.patientbaseurl + '/patient/save-patient-profile', patientProfile);

  }

  getAllergyData() {
    return this.httpService.get<Allergy[]>(environment.patientbaseurl + '/allergy/getall');
  }

  deleteAllergyForPatient(patientAllergyMappingId: number) {
    this.httpService.delete(environment.patientbaseurl + "/patient/delete-patient-allergy/" + patientAllergyMappingId)
      .subscribe((response) => {
        this.snackBar.open(response.message, undefined, { duration: 3000 });
      });
  }

  getUpcomingAppointments(emailId: string) {
    return this.httpService.get<AppointmentDetailsResponse[]>(environment.appointmenturl + "/appointment/get-upcoming-patient-appointments/" + emailId);
  }

  getPatientAppointmentsHistory(emailId: string) {
    return this.httpService.get<AppointmentDetailsResponse[]>(environment.appointmenturl + "/appointment/get-patient-appointments-history/" + emailId);
  }

  addAllergy(allergyData: any) {
    this.httpService.post(environment.patientbaseurl + "/patient/add-patient-allergy", allergyData)
      .subscribe(response => { this.snackBar.open("Allergy added successfully", undefined, { duration: 3000 }) });

  }
}
