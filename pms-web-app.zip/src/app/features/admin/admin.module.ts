import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminDashboardComponent } from './pages/admin-dashboard/admin-dashboard.component';
import { ViewAllPatientComponent } from './pages/view-all-patient/view-all-patient.component';
import { ViewAllStaffComponent } from './pages/view-all-staff/view-all-staff.component';
import { RegisterHospitalStaffComponent } from './pages/register-hospital-staff/register-hospital-staff.component';
import { MaterialModule } from 'src/app/common/material/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddMasterDataComponent } from './pages/add-master-data/add-master-data.component';
import { EditAllergyMasterComponent } from './pages/add-master-data/edit-allergy-master/edit-allergy-master.component';
import { EditDiagnosisMasterComponent } from './pages/add-master-data/edit-diagnosis-master/edit-diagnosis-master.component';
import { EditProcedureMasterComponent } from './pages/add-master-data/edit-procedure-master/edit-procedure-master.component';
import { EditDrugDataMasterComponent } from './pages/add-master-data/edit-drug-data-master/edit-drug-data-master.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AllergyMasterDataComponent } from './pages/allergy-master-data/allergy-master-data.component';
import { DiagnosisMasterDataComponent } from './pages/diagnosis-master-data/diagnosis-master-data.component';
import { ProcedureMasterDataComponent } from './pages/procedure-master-data/procedure-master-data.component';
import { DrugMasterDataComponent } from './pages/drug-master-data/drug-master-data.component';
import { AddOtherAllergyToMasterComponent } from './pages/add-other-allergy-to-master/add-other-allergy-to-master.component';
import { AddOtherDiagnosisToMasterComponent } from './pages/add-other-diagnosis-to-master/add-other-diagnosis-to-master.component';
import { AddOtherDrugToMasterComponent } from './pages/add-other-drug-to-master/add-other-drug-to-master.component';
import { AddOtherProcedureToMasterComponent } from './pages/add-other-procedure-to-master/add-other-procedure-to-master.component';

@NgModule({
  declarations: [
    AdminDashboardComponent,
    ViewAllPatientComponent,
    ViewAllStaffComponent,
    RegisterHospitalStaffComponent,
    AddMasterDataComponent,
    EditAllergyMasterComponent,
    EditDiagnosisMasterComponent,
    EditProcedureMasterComponent,
    EditDrugDataMasterComponent,
    AllergyMasterDataComponent,
    DiagnosisMasterDataComponent,
    ProcedureMasterDataComponent,
    DrugMasterDataComponent,
    AddOtherAllergyToMasterComponent,
    AddOtherDiagnosisToMasterComponent,
    AddOtherDrugToMasterComponent,
    AddOtherProcedureToMasterComponent,

  ],
  imports: [
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    NgxChartsModule
  ],
  exports: [AdminDashboardComponent, ViewAllPatientComponent, ViewAllStaffComponent,
    RegisterHospitalStaffComponent]
})
export class AdminModule { }
