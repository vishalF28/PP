import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOtherDiagnosisToMasterComponent } from './add-other-diagnosis-to-master.component';

describe('AddOtherDiagnosisToMasterComponent', () => {
  let component: AddOtherDiagnosisToMasterComponent;
  let fixture: ComponentFixture<AddOtherDiagnosisToMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddOtherDiagnosisToMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOtherDiagnosisToMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
