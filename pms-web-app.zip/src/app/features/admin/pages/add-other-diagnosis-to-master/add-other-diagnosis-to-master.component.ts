import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Diagnosis } from 'src/app/shared/components/interfaces/diagnosis.model';
import { DiagnosisService } from '../../services/diagnosis.service';
import { EditDiagnosisMasterComponent } from '../add-master-data/edit-diagnosis-master/edit-diagnosis-master.component';

@Component({
  selector: 'app-add-other-diagnosis-to-master',
  templateUrl: './add-other-diagnosis-to-master.component.html',
  styleUrls: ['./add-other-diagnosis-to-master.component.css']
})
export class AddOtherDiagnosisToMasterComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) diagnosisMasterSort: MatSort;
  @ViewChild(MatPaginator, { static: false }) diagnosisMasterPaginator: MatPaginator;
  diagnosisMasterDataSource: MatTableDataSource<Diagnosis>;
  diagnosisMasterDataColumns: string[] = ['diagnosisId', 'diagnosisCode', 'isDepricated', 'diagnosisDescription', 'action', 'action2'];
  diagnosisMasterResultLength: number = 0;
  diagnosisMasterSubscription: Subscription;

  constructor(private diagnosisService: DiagnosisService, public loader: LoaderService,
    private dialog: MatDialog, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.diagnosisMasterSubscription = this.diagnosisService.getAllNewDiagnosisData().subscribe(
      (diagnosis: Diagnosis[]) => {
        this.diagnosisMasterDataSource = new MatTableDataSource(diagnosis);
        this.diagnosisMasterResultLength = this.diagnosisMasterDataSource.data.length;
        this.diagnosisMasterDataSource.sort = this.diagnosisMasterSort;
        this.diagnosisMasterDataSource.paginator = this.diagnosisMasterPaginator;
      }
    )
  }

  searchDiagnosis(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.diagnosisMasterDataSource.filter = filterValue.trim().toLowerCase();
    if (this.diagnosisMasterDataSource.paginator) {
      this.diagnosisMasterDataSource.paginator.firstPage();
    }
  }

  openDialogEditDiagnosis(diagnosis: Diagnosis) {
    const dialogRef = this.dialog.open(EditDiagnosisMasterComponent, { disableClose: true, data: diagnosis });
  }

  saveDiagnosisToMaster(diagnosis: Diagnosis) {
    this.diagnosisService.saveDiagnosis(diagnosis).subscribe(response => {
      this.snackBar.open("Save diagnosis successfully.", undefined, { duration: 3000 });
      const findIndexofCurrentDiagnosis = this.diagnosisMasterDataSource.
        data.findIndex((diagnoses) => diagnoses.diagnosisId === diagnosis.diagnosisId);
      this.diagnosisMasterDataSource.data.splice(findIndexofCurrentDiagnosis, 1);
      this.diagnosisMasterDataSource.filter = '';
    });
  }

  ngOnDestroy() {
    this.diagnosisMasterSubscription.unsubscribe();
  }
}
