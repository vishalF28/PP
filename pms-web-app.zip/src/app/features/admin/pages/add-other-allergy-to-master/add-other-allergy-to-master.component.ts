import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Allergy } from 'src/app/features/patient/interfaces/allergy.model';
import { AllergyService } from '../../services/allergy.service';
import { EditAllergyMasterComponent } from '../add-master-data/edit-allergy-master/edit-allergy-master.component';

@Component({
  selector: 'app-add-other-allergy-to-master',
  templateUrl: './add-other-allergy-to-master.component.html',
  styleUrls: ['./add-other-allergy-to-master.component.css']
})
export class AddOtherAllergyToMasterComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) allergyMasterSort: MatSort;
  @ViewChild(MatPaginator, { static: false }) allergyMasterPaginator: MatPaginator;
  allergyMasterDataSource: MatTableDataSource<Allergy>;
  allergyMasterDataColumns: string[] = ['allergyId', 'allergyClinicalInformation', 'allergyName', 'allergyType', 'allergyDescription', 'action', 'action2'];
  allergyMasterResultLength: number = 0;
  allergyMasterSubscription: Subscription;

  constructor(private allergyService: AllergyService, public loader: LoaderService,
    private dialog: MatDialog, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.allergyMasterSubscription = this.allergyService.getAllNewAllergyData().subscribe(
      (allergy: Allergy[]) => {
        this.allergyMasterDataSource = new MatTableDataSource(allergy);
        this.allergyMasterResultLength = this.allergyMasterDataSource.data.length;
        this.allergyMasterDataSource.sort = this.allergyMasterSort;
        this.allergyMasterDataSource.paginator = this.allergyMasterPaginator;
      }
    )
  }

  searchAllergyMaster(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.allergyMasterDataSource.filter = filterValue.trim().toLowerCase();
    if (this.allergyMasterDataSource.paginator) {
      this.allergyMasterDataSource.paginator.firstPage();
    }
  }

  OpenDialogEditAllergy(allergy: Allergy) {
    const allergydialogRef = this.dialog.open(EditAllergyMasterComponent, { disableClose: true, data: allergy });
  }

  saveAllergyToMasterTable(allergy: Allergy) {
    allergy.isNewlyAdded = false;
    this.allergyService.saveAllergies(allergy).subscribe(response => {
      this.snackBar.open("Save allergy successfully.", undefined, { duration: 3000 });
      const findIndexOfCurrentAllergy = this.allergyMasterDataSource.data.findIndex(
        (allergy) => allergy.allergyId === allergy.allergyId
      );
      this.allergyMasterDataSource.data.splice(findIndexOfCurrentAllergy, 1);
      this.allergyMasterDataSource.filter = '';
    });
  }

  ngOnDestroy() {
    this.allergyMasterSubscription.unsubscribe();
  }

}
