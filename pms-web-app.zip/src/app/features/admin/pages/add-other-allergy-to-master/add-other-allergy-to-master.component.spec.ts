import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOtherAllergyToMasterComponent } from './add-other-allergy-to-master.component';

describe('AddOtherAllergyToMasterComponent', () => {
  let component: AddOtherAllergyToMasterComponent;
  let fixture: ComponentFixture<AddOtherAllergyToMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddOtherAllergyToMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOtherAllergyToMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
