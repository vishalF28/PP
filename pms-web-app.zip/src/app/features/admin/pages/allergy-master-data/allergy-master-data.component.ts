import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Allergy } from 'src/app/features/patient/interfaces/allergy.model';
import { AllergyService } from '../../services/allergy.service';
import { EditAllergyMasterComponent } from '../add-master-data/edit-allergy-master/edit-allergy-master.component';

@Component({
  selector: 'app-allergy-master-data',
  templateUrl: './allergy-master-data.component.html',
  styleUrls: ['./allergy-master-data.component.css']
})
export class AllergyMasterDataComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) allergyMasterSort: MatSort;
  @ViewChild(MatPaginator, { static: false }) allergyMasterPaginator: MatPaginator;
  allergyMasterDataSource: MatTableDataSource<Allergy>;
  allergyMasterDataColumns: string[] = ['allergyClinicalInformation', 'allergyName', 'allergyType', 'allergyDescription', 'action'];
  allergyMasterResultLength: number = 0;
  allergyMasterSubscription: Subscription;

  constructor(private allergyService: AllergyService, public loader: LoaderService,
    private dialog: MatDialog, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.allergyMasterSubscription = this.allergyService.getAllAllergyData().subscribe(
      (allergy: Allergy[]) => {
        this.allergyMasterDataSource = new MatTableDataSource(allergy);
        this.allergyMasterResultLength = this.allergyMasterDataSource.data.length;
        this.allergyMasterDataSource.sort = this.allergyMasterSort;
        this.allergyMasterDataSource.paginator = this.allergyMasterPaginator;
      }
    )
  }

  searchAllergyMaster(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.allergyMasterDataSource.filter = filterValue.trim().toLowerCase();
    if (this.allergyMasterDataSource.paginator) {
      this.allergyMasterDataSource.paginator.firstPage();
    }
  }

  OpenDialogEditAllergy(allergy: Allergy) {
    const allergydialogRef = this.dialog.open(EditAllergyMasterComponent, { disableClose: true, data: allergy });
    allergydialogRef.afterClosed().subscribe(
      (response) => {
        if (response) {
          this.allergyService.saveAllergies(allergy).subscribe(response => {
            this.snackBar.open("Updated allergy details successfully.", undefined, { duration: 3000 });
          });
        }
      });
  }

  ngOnDestroy() {
    this.allergyMasterSubscription.unsubscribe();
  }

}
