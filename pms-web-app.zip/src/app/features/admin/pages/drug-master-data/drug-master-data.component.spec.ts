import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DrugMasterDataComponent } from './drug-master-data.component';

describe('DrugMasterDataComponent', () => {
  let component: DrugMasterDataComponent;
  let fixture: ComponentFixture<DrugMasterDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DrugMasterDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DrugMasterDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
