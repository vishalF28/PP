import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Drug } from 'src/app/shared/components/interfaces/drug.model';
import { DrugDataService } from '../../services/drug-data.service';
import { EditDrugDataMasterComponent } from '../add-master-data/edit-drug-data-master/edit-drug-data-master.component';

@Component({
  selector: 'app-drug-master-data',
  templateUrl: './drug-master-data.component.html',
  styleUrls: ['./drug-master-data.component.css']
})
export class DrugMasterDataComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) drugMasterSort: MatSort;
  @ViewChild(MatPaginator, { static: false }) drugMasterPaginator: MatPaginator;
  drugMasterDataSource: MatTableDataSource<Drug>;
  drugMasterDataColumns: string[] = ['drugName', 'drugGenericName', 'drugManufacturerName', 'drugForm', 'drugStrength', 'action'];
  drugMasterResultLength: number = 0;
  drugMasterSubscription: Subscription;

  constructor(private drugService: DrugDataService, public loader: LoaderService,
    private dialog: MatDialog, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.drugMasterSubscription = this.drugService.getAllDrugData().subscribe(
      (drug: Drug[]) => {
        console.log(drug);
        this.drugMasterDataSource = new MatTableDataSource(drug);
        this.drugMasterResultLength = this.drugMasterDataSource.data.length;
        this.drugMasterDataSource.sort = this.drugMasterSort;
        this.drugMasterDataSource.paginator = this.drugMasterPaginator;
      }
    )
  }

  searchDrug(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.drugMasterDataSource.filter = filterValue.trim().toLowerCase();
    if (this.drugMasterDataSource.paginator) {
      this.drugMasterDataSource.paginator.firstPage();
    }
  }

  OpenDialogEditDrugData(drug: Drug) {
    const dialogRef = this.dialog.open(EditDrugDataMasterComponent, { disableClose: true, data: drug });
    dialogRef.afterClosed().subscribe(
      (response) => {
        if (response) {
          this.drugService.saveDrugData(drug).subscribe(response => {
            this.snackBar.open("Updated drug details successfully.", undefined, { duration: 3000 });
          });
        }
      });
  }

  ngOnDestroy() {
    this.drugMasterSubscription.unsubscribe();
  }
}
