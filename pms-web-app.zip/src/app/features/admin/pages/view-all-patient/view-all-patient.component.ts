import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { PatientDetailsResponse } from '../../interfaces/patient-details-response.model';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-view-all-patient',
  templateUrl: './view-all-patient.component.html',
  styleUrls: ['./view-all-patient.component.css']
})
export class ViewAllPatientComponent implements OnInit {
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  dataSource: MatTableDataSource<PatientDetailsResponse>;

  displayedColumns: string[] = ['userId', 'fullName', 'emailId', 'isActive', 'action'];

  private patientDataSubscription: Subscription;

  patients: PatientDetailsResponse[] = [];

  constructor(private adminService: AdminService, public loader: LoaderService,
    private snackBar: MatSnackBar) { }

  resultlength: number;

  ngOnInit(): void {
    this.dataSource = new MatTableDataSource();
    this.adminService.getAllPatientData();
    this.patientDataSubscription = this.adminService.getPatientUpdatedDataListner().subscribe((patient: PatientDetailsResponse[]) => {
      this.dataSource = new MatTableDataSource(patient);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.resultlength = this.dataSource.data.length;
    });
  }

  doFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  activateAccount(patientData) {
    this.adminService.activateOrDeactivatePatientAccount(patientData, true);
    this.snackBar.open("You have activated account of " + patientData.emailId, null, { duration: 2000 });
  }

  deactivateAccount(patientData) {
    this.adminService.activateOrDeactivatePatientAccount(patientData, false);
    this.snackBar.open("You have deactivated account of " + patientData.emailId, null, { duration: 2000 });
  }

  ngOnDestroy() {
    this.patientDataSubscription.unsubscribe();
  }
}