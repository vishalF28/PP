import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterHospitalStaffComponent } from './register-hospital-staff.component';

describe('RegisterHospitalStaffComponent', () => {
  let component: RegisterHospitalStaffComponent;
  let fixture: ComponentFixture<RegisterHospitalStaffComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisterHospitalStaffComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterHospitalStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
