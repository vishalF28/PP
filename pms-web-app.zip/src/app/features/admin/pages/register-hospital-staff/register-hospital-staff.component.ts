import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-register-hospital-staff',
  templateUrl: './register-hospital-staff.component.html',
  styleUrls: ['./register-hospital-staff.component.css']
})
export class RegisterHospitalStaffComponent implements OnInit {
  specialities: any[] = ['Dermatology', 'Neurology', 'Ophthalmology', 'Pathology',
    'Urology', 'Preventive Medicine', 'Cardiology', 'General'];

  specialitiesNurse: any[] = ['Registered Nurse', 'Advanced Practice Registered Nurse', 'Nursing Assistant'
    , 'Licensed Practical Nurse', 'General'];

  hospitalstaff: any = {
    title: '', emailId: '', firstName: '', lastName: '', role: '',
    birthDate: Date, contact: '', speciality: 'general', gender: ''
  }

  //bind on UI to disable futures date
  todaysDate = new Date();

  constructor(private adminService: AdminService, private snackBar: MatSnackBar,
    public loader: LoaderService) { }

  ngOnInit(): void {
  }

  registerNewHospitalStaff(registrationForm: NgForm) {
    this.adminService.registerNewHospitalStaff(this.hospitalstaff);
    this.resetForm(registrationForm);
  }

  resetForm(registrationForm: NgForm) {
    registrationForm.resetForm();
  }

}
