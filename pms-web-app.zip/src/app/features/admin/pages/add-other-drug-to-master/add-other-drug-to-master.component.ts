import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Drug } from 'src/app/shared/components/interfaces/drug.model';
import { DrugDataService } from '../../services/drug-data.service';
import { EditDrugDataMasterComponent } from '../add-master-data/edit-drug-data-master/edit-drug-data-master.component';

@Component({
  selector: 'app-add-other-drug-to-master',
  templateUrl: './add-other-drug-to-master.component.html',
  styleUrls: ['./add-other-drug-to-master.component.css']
})
export class AddOtherDrugToMasterComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) drugMasterSort: MatSort;
  @ViewChild(MatPaginator, { static: false }) drugMasterPaginator: MatPaginator;
  drugMasterDataSource: MatTableDataSource<Drug>;
  drugMasterDataColumns: string[] = ['drugName', 'drugGenericName', 'drugManufacturerName', 'drugForm', 'drugStrength', 'action', 'action2'];
  drugMasterResultLength: number = 0;
  drugMasterSubscription: Subscription;

  constructor(private drugService: DrugDataService, public loader: LoaderService,
    private dialog: MatDialog, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.drugMasterSubscription = this.drugService.getAllNewDrugData().subscribe(
      (drug: Drug[]) => {
        this.drugMasterDataSource = new MatTableDataSource(drug);
        this.drugMasterResultLength = this.drugMasterDataSource.data.length;
        this.drugMasterDataSource.sort = this.drugMasterSort;
        this.drugMasterDataSource.paginator = this.drugMasterPaginator;
      }
    )
  }

  searchDrug(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.drugMasterDataSource.filter = filterValue.trim().toLowerCase();
    if (this.drugMasterDataSource.paginator) {
      this.drugMasterDataSource.paginator.firstPage();
    }
  }

  OpenDialogEditDrugData(drug: Drug) {
    const dialogRef = this.dialog.open(EditDrugDataMasterComponent, { disableClose: true, data: drug });
  }

  saveDrugToMaster(drugData: Drug) {
    this.drugService.saveDrugData(drugData).subscribe(response => {
      this.snackBar.open("Save drug successfully.", undefined, { duration: 3000 });
      const findIndexOfCurrentDrugData = this.drugMasterDataSource.data.findIndex((drugDataDetail) =>
        drugDataDetail.drugId === drugData.drugId);
      this.drugMasterDataSource.data.splice(findIndexOfCurrentDrugData, 1);
      this.drugMasterDataSource.filter = '';
    });
  }

  ngOnDestroy() {
    this.drugMasterSubscription.unsubscribe();
  }

}
