import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Procedure } from '../../../interfaces/procedure.model';

@Component({
  selector: 'app-edit-procedure-master',
  templateUrl: './edit-procedure-master.component.html',
  styleUrls: ['./edit-procedure-master.component.css']
})
export class EditProcedureMasterComponent implements OnInit {

  constructor(private dialog: MatDialogRef<Procedure>,
    @Inject(MAT_DIALOG_DATA) public procedureData: Procedure) { }


  procedureDataModel: any = { procedureId: 0, procedureCode: '', procedureDescription: '', procedureIsDepricated: false }


  ngOnInit(): void {
    this.procedureDataModel = this.procedureData;
  }

  addProcedure() {
    this.dialog.close({ Procedure: this.procedureDataModel });
  }

  closeDialog() {
    this.dialog.close();
  }

}
