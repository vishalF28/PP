import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditProcedureMasterComponent } from './edit-procedure-master.component';

describe('EditProcedureMasterComponent', () => {
  let component: EditProcedureMasterComponent;
  let fixture: ComponentFixture<EditProcedureMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditProcedureMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditProcedureMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
