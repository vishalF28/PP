import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DrugData } from '../../../interfaces/drug-data.model';
@Component({
  selector: 'app-edit-drug-data-master',
  templateUrl: './edit-drug-data-master.component.html',
  styleUrls: ['./edit-drug-data-master.component.css']
})
export class EditDrugDataMasterComponent implements OnInit {


  constructor(private dialog: MatDialogRef<EditDrugDataMasterComponent>,
    @Inject(MAT_DIALOG_DATA) public drugData: DrugData) { }

  drugDataModel: any = {
    drugId: 0, drugName: '', drugManufacturerName: '', drugForm: '', drugGenericName: '', drugStrength: ''
  };

  ngOnInit(): void {
    this.drugDataModel = this.drugData;
  }

  closeDialog() {
    this.dialog.close();
  }

  addDrugData() {
    this.dialog.close({ drugData: this.drugDataModel })
  }
}
