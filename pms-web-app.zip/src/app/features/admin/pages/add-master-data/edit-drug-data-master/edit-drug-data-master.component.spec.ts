import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDrugDataMasterComponent } from './edit-drug-data-master.component';

describe('EditDrugDataMasterComponent', () => {
  let component: EditDrugDataMasterComponent;
  let fixture: ComponentFixture<EditDrugDataMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditDrugDataMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDrugDataMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
