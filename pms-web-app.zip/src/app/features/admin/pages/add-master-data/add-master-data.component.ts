import { Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';

@Component({
  selector: 'app-add-master-data',
  templateUrl: './add-master-data.component.html',
  styleUrls: ['./add-master-data.component.css']
})
export class AddMasterDataComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}


