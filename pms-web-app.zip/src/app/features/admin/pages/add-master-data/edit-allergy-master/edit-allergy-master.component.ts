import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Allergy } from '../../../interfaces/allergy.model';

@Component({
  selector: 'app-edit-allergy-master',
  templateUrl: './edit-allergy-master.component.html',
  styleUrls: ['./edit-allergy-master.component.css']
})
export class EditAllergyMasterComponent implements OnInit {

  constructor(private dialog: MatDialogRef<EditAllergyMasterComponent>,
    @Inject(MAT_DIALOG_DATA) public allergyData: Allergy
  ) { }

  allergyDataModel: any = {
    allergyId: 0, allergyName: '', allergyType: '',
    allergyDescription: '', allergyClinicalInformation: '', isNewlyAdded: false
  }

  ngOnInit(): void {
    this.allergyDataModel = this.allergyData;
  }

  addAllergy() {
    this.dialog.close({ allergy: this.allergyDataModel });
  }

  closeDialog() {
    this.dialog.close();
  }
}
