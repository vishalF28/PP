import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAllergyMasterComponent } from './edit-allergy-master.component';

describe('EditAllergyMasterComponent', () => {
  let component: EditAllergyMasterComponent;
  let fixture: ComponentFixture<EditAllergyMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditAllergyMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAllergyMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
