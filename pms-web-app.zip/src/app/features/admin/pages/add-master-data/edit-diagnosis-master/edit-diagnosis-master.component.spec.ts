import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDiagnosisMasterComponent } from './edit-diagnosis-master.component';

describe('EditDiagnosisMasterComponent', () => {
  let component: EditDiagnosisMasterComponent;
  let fixture: ComponentFixture<EditDiagnosisMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditDiagnosisMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDiagnosisMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
