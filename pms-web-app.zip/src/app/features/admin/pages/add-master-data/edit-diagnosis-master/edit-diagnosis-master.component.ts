import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Diagnosis } from '../../../interfaces/diagnosis.model';

@Component({
  selector: 'app-edit-diagnosis-master',
  templateUrl: './edit-diagnosis-master.component.html',
  styleUrls: ['./edit-diagnosis-master.component.css']
})
export class EditDiagnosisMasterComponent implements OnInit {

  constructor(private dialog: MatDialogRef<Diagnosis>,
    @Inject(MAT_DIALOG_DATA) public diagnosisData: Diagnosis) { }


  diagnosisDataModel: any = { diagnosisCode: '', diagnosisDescription: '', isDepricated: false };

  ngOnInit(): void {
    this.diagnosisDataModel = this.diagnosisData;
  }

  addDiagnosis() {
    this.dialog.close({ Diagnosis: this.diagnosisDataModel });
  }

  closeDialog() {
    this.dialog.close();
  }

}
