import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NgForm } from '@angular/forms';

import { AddMasterDataComponent } from './add-master-data.component';

fdescribe('AddMasterDataComponent', () => {
  let component: AddMasterDataComponent;
  let fixture: ComponentFixture<AddMasterDataComponent>;
  let testForm: NgForm;


  beforeEach(async () => {
    await TestBed.configureTestingModule({

      declarations: [AddMasterDataComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMasterDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call the accept diagnosis function of Add master data ', () => {
    testForm = <NgForm>{
      value: {

      }
    }

  });




});
