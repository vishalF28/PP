import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiagnosisMasterDataComponent } from './diagnosis-master-data.component';

describe('DiagnosisMasterDataComponent', () => {
  let component: DiagnosisMasterDataComponent;
  let fixture: ComponentFixture<DiagnosisMasterDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DiagnosisMasterDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DiagnosisMasterDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
