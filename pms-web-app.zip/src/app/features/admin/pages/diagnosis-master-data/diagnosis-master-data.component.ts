import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Diagnosis } from '../../interfaces/diagnosis.model';
import { DiagnosisService } from '../../services/diagnosis.service';
import { EditDiagnosisMasterComponent } from '../add-master-data/edit-diagnosis-master/edit-diagnosis-master.component';

@Component({
  selector: 'app-diagnosis-master-data',
  templateUrl: './diagnosis-master-data.component.html',
  styleUrls: ['./diagnosis-master-data.component.css']
})
export class DiagnosisMasterDataComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) diagnosisMasterSort: MatSort;
  @ViewChild(MatPaginator, { static: false }) diagnosisMasterPaginator: MatPaginator;
  diagnosisMasterDataSource: MatTableDataSource<Diagnosis>;
  diagnosisMasterDataColumns: string[] = ['diagnosisCode', 'diagnosisDescription', 'action'];
  diagnosisMasterResultLength: number = 0;
  diagnosisMasterSubscription: Subscription;

  constructor(private diagnosisService: DiagnosisService, public loader: LoaderService,
    private dialog: MatDialog, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.diagnosisMasterSubscription = this.diagnosisService.getAllDiagnosis().subscribe(
      (diagnosis: Diagnosis[]) => {
        this.diagnosisMasterDataSource = new MatTableDataSource(diagnosis);
        this.diagnosisMasterResultLength = this.diagnosisMasterDataSource.data.length;
        this.diagnosisMasterDataSource.sort = this.diagnosisMasterSort;
        this.diagnosisMasterDataSource.paginator = this.diagnosisMasterPaginator;
      }
    )
  }

  searchDiagnosis(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.diagnosisMasterDataSource.filter = filterValue.trim().toLowerCase();
    if (this.diagnosisMasterDataSource.paginator) {
      this.diagnosisMasterDataSource.paginator.firstPage();
    }
  }

  openDialogEditDiagnosis(diagnosis: Diagnosis) {
    const dialogRef = this.dialog.open(EditDiagnosisMasterComponent, { disableClose: true, data: diagnosis });
    dialogRef.afterClosed().subscribe(
      (response) => {
        if (response) {
          this.diagnosisService.saveDiagnosis(diagnosis).subscribe(response => {
            this.snackBar.open("Updated diagnosis details successfully.", undefined, { duration: 3000 });
          });
        }
      });
  }

  ngOnDestroy() {
    this.diagnosisMasterSubscription.unsubscribe();
  }

}
