import { Component, OnInit } from '@angular/core';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {



  nurseCount: number = 0;
  physicianCount: number = 0;
  patientCount: number = 0;
  newlyAddedPatientCount: number = 0;

  specialityPhysicianCount = [];
  specialityNurseCount = [];

  constructor(private adminService: AdminService, public loader: LoaderService) {
    Object.assign(this.specialityPhysicianCount);
    Object.assign(this.specialityNurseCount);
  }

  ngOnInit(): void {
    this.adminService.getUserCountByRole('NURSE').subscribe((data) => { this.nurseCount = data });
    this.adminService.getUserCountByRole('PHYSICIAN').subscribe((data) => { this.physicianCount = data });
    this.adminService.getPatientCount().subscribe((data) => { this.patientCount = data });
    this.adminService.getNewAddedPatientCount().subscribe((data) => { this.newlyAddedPatientCount = data });

    this.adminService.getCountOfPhysicianBySpeciality().subscribe(
      (response) => {
        Object.keys(response).forEach((element) => {
          this.specialityPhysicianCount.push({ name: element, value: response[element] });
        })
        this.specialityPhysicianCount = [...this.specialityPhysicianCount];
      }
    );

    this.adminService.getCountOfNurseBySpeciality().subscribe(
      (response) => {
        Object.keys(response).forEach((element) => {
          this.specialityNurseCount.push({ name: element, value: response[element] });
        })
        this.specialityNurseCount = [...this.specialityNurseCount];
      }
    );
  }

}
