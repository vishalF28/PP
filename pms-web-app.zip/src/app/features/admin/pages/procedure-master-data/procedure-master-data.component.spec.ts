import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcedureMasterDataComponent } from './procedure-master-data.component';

describe('ProcedureMasterDataComponent', () => {
  let component: ProcedureMasterDataComponent;
  let fixture: ComponentFixture<ProcedureMasterDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProcedureMasterDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcedureMasterDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
