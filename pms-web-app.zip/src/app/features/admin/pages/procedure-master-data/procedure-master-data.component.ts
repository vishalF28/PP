import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Procedure } from 'src/app/shared/components/interfaces/procedure.model';
import { ProcedureService } from '../../services/procedure.service';
import { EditProcedureMasterComponent } from '../add-master-data/edit-procedure-master/edit-procedure-master.component';

@Component({
  selector: 'app-procedure-master-data',
  templateUrl: './procedure-master-data.component.html',
  styleUrls: ['./procedure-master-data.component.css']
})
export class ProcedureMasterDataComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) procedureMasterSort: MatSort;
  @ViewChild(MatPaginator, { static: false }) procedureMasterPaginator: MatPaginator;
  procedureMasterDataSource: MatTableDataSource<Procedure>;
  procedureMasterDataColumns: string[] = ['procedureCode', 'procedureDescription', 'action'];
  procedureMasterResultLength: number = 0;
  procedureMasterSubscription: Subscription;

  constructor(private procedureService: ProcedureService, public loader: LoaderService,
    private dialog: MatDialog, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.procedureMasterSubscription = this.procedureService.getAllProcedure().subscribe(
      (procedure: Procedure[]) => {
        this.procedureMasterDataSource = new MatTableDataSource(procedure);
        this.procedureMasterResultLength = this.procedureMasterDataSource.data.length;
        this.procedureMasterDataSource.sort = this.procedureMasterSort;
        this.procedureMasterDataSource.paginator = this.procedureMasterPaginator;
      }
    )
  }

  searchProcedure(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.procedureMasterDataSource.filter = filterValue.trim().toLowerCase();
    if (this.procedureMasterDataSource.paginator) {
      this.procedureMasterDataSource.paginator.firstPage();
    }
  }

  openDialogEditProcedure(procedure: Procedure) {
    const procedureDialogRef = this.dialog.open(EditProcedureMasterComponent, { disableClose: true, data: procedure });
    procedureDialogRef.afterClosed().subscribe(
      (response) => {
        if (response) {
          this.procedureService.saveProcedure(procedure).subscribe(response => {
            this.snackBar.open("Updated procedure details successfully.", undefined, { duration: 3000 });
          });
        }
      });
  }

  ngOnDestroy() {
    this.procedureMasterSubscription.unsubscribe();
  }

}
