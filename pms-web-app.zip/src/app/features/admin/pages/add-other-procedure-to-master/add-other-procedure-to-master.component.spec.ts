import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOtherProcedureToMasterComponent } from './add-other-procedure-to-master.component';

describe('AddOtherProcedureToMasterComponent', () => {
  let component: AddOtherProcedureToMasterComponent;
  let fixture: ComponentFixture<AddOtherProcedureToMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddOtherProcedureToMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOtherProcedureToMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
