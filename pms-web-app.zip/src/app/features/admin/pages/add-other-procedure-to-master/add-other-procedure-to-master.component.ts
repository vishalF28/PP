import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { Procedure } from 'src/app/shared/components/interfaces/procedure.model';
import { ProcedureService } from '../../services/procedure.service';
import { EditProcedureMasterComponent } from '../add-master-data/edit-procedure-master/edit-procedure-master.component';

@Component({
  selector: 'app-add-other-procedure-to-master',
  templateUrl: './add-other-procedure-to-master.component.html',
  styleUrls: ['./add-other-procedure-to-master.component.css']
})
export class AddOtherProcedureToMasterComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) procedureMasterSort: MatSort;
  @ViewChild(MatPaginator, { static: false }) procedureMasterPaginator: MatPaginator;
  procedureMasterDataSource: MatTableDataSource<Procedure>;
  procedureMasterDataColumns: string[] = ['procedureId', 'procedureCode', 'procedureDescription', 'procedureIsDeprecated', 'action', 'action2'];
  procedureMasterResultLength: number = 0;
  procedureMasterSubscription: Subscription;

  constructor(private procedureService: ProcedureService, public loader: LoaderService,
    private dialog: MatDialog, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.procedureMasterSubscription = this.procedureService.getAllNewProcedures().subscribe(
      (procedure: Procedure[]) => {
        this.procedureMasterDataSource = new MatTableDataSource(procedure);
        this.procedureMasterResultLength = this.procedureMasterDataSource.data.length;
        this.procedureMasterDataSource.sort = this.procedureMasterSort;
        this.procedureMasterDataSource.paginator = this.procedureMasterPaginator;
      }
    )
  }

  searchProcedure(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.procedureMasterDataSource.filter = filterValue.trim().toLowerCase();
    if (this.procedureMasterDataSource.paginator) {
      this.procedureMasterDataSource.paginator.firstPage();
    }
  }

  openDialogEditProcedure(procedure: Procedure) {
    const procedureDialogRef = this.dialog.open(EditProcedureMasterComponent, { disableClose: true, data: procedure })
  }

  saveProcedureToMaster(procedureData: Procedure) {
    this.procedureService.saveProcedure(procedureData).subscribe(responnse => {
      this.snackBar.open("Save procedure successfully.", undefined, { duration: 3000 });
      const findIndexofCurrentProcedure = this.procedureMasterDataSource.
        data.findIndex((procedure) => procedure.procedureId === procedureData.procedureId);
      this.procedureMasterDataSource.data.splice(findIndexofCurrentProcedure, 1);
      this.procedureMasterDataSource.filter = '';
    })
  }

  ngOnDestroy() {
    this.procedureMasterSubscription.unsubscribe();
  }

}
