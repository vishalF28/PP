import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { HospitalStaffResponse } from '../../interfaces/hospital-staff-response.model';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-view-all-staff',
  templateUrl: './view-all-staff.component.html',
  styleUrls: ['./view-all-staff.component.css']
})
export class ViewAllStaffComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  dataSource: MatTableDataSource<HospitalStaffResponse>;

  displayedColumns: string[] = ['userId', 'fullName', 'emailId', 'role', 'isActive', 'action'];

  private staffDataSubscription: Subscription;

  resultlength: number = 0;

  constructor(private adminService: AdminService, public loader: LoaderService,
    private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.dataSource = new MatTableDataSource();
    this.adminService.getAllStaffData();
    this.staffDataSubscription = this.adminService.getStaffUpdatedDataListner().subscribe((staff: HospitalStaffResponse[]) => {
      this.dataSource = new MatTableDataSource(staff);
      this.resultlength = this.dataSource.data.length;
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  doFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deactivateAccount(staffData) {
    this.adminService.activateOrDeactivateStaffAccount(staffData, false);
    this.snackBar.open("You have deactivated account of " + staffData.emailId, null, { duration: 2000 });
  }

  activateAccount(staffData) {
    this.adminService.activateOrDeactivateStaffAccount(staffData, true);
    this.snackBar.open("You have activated account of " + staffData.emailId, null, { duration: 2000 });
  }

  ngDestroy() {
    this.staffDataSubscription.unsubscribe();
  }

}
