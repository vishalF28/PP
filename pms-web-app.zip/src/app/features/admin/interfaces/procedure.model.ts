export class Procedure{
    procedureId:number;
    procedureCode:string;
    procedureDescription:string;
    procedureIsDeprecated:boolean;
}