export class Diagnosis{

        diagnosisId:number;
        diagnosisCode:string;
        isDepricated:boolean;
        diagnosisDescription: string;

}