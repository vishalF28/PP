export class PatientDetailsResponse {
    userId: string;
    fullName: string;
    emailId: string;
    isActive: boolean;
}