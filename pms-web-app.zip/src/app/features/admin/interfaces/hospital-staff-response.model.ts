export interface HospitalStaffResponse {
    userId: string;
    fullName: string;
    emailId: string;
    role: string;
    isActive: boolean;
}