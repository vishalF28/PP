export interface Allergy {
    allergyId: number;
    allergyType: string;
    allergyName: string;
    allergyDescription: string;
    allergyClinicalInformation: string;
    isNewlyAdded: boolean;
}