export class RegisterStaffRequest {
    title: string;
    emailId: string;
    firstName: string;
    lastName: string;
    role: string;
    birthDate: Date;
    contact: number;
    speciality: string;
    gender: string;
}