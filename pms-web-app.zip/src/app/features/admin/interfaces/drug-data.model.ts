export interface DrugData {
    drugId: number;
    drugName: string;
    drugGenericName: string;
    drugManufacturerName: string;
    drugForm: string;
    drugStrength: string;

}