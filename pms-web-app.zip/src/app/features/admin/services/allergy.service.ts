import { Injectable } from "@angular/core";
import { HttpService } from "src/app/core/services/http.service";
import { LoaderService } from "src/app/core/services/loader.service";
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from "src/environments/environment";
import { Allergy } from "../../patient/interfaces/allergy.model";


@Injectable({
    providedIn: "root"
})
export class AllergyService {

    constructor(private httpService: HttpService) {
    }

    saveAllergies(Allergies: any) {
        return this.httpService.post(environment.patientbaseurl + "/allergy/save", Allergies);
    }





    getAllNewAllergyData() {
        return this.httpService.get(environment.patientbaseurl + "/allergy/get-newly-added-allergies");
    }

    getAllAllergyData() {
        return this.httpService.get(environment.patientbaseurl + "/allergy/getall");
    }
}



