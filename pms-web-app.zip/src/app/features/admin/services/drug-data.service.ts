import { Injectable } from "@angular/core";

import { HttpService } from "src/app/core/services/http.service";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: "root"
})
export class DrugDataService {
    constructor(private httpService: HttpService) { }

    getAllNewDrugData() {
        return this.httpService.get(environment.appointmenturl + "/drug/get-newly-added-drug");
    }


    saveDrugData(DrugData: any) {
        return this.httpService.post(environment.appointmenturl + "/drug/save", DrugData);
    }


    getAllDrugData() {
        return this.httpService.get(environment.appointmenturl + "/drug/getall");
    }
}