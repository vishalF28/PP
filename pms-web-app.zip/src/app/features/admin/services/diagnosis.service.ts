import { Injectable } from "@angular/core";
import { HttpService } from "src/app/core/services/http.service";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: "root"
})
export class DiagnosisService {
    constructor(private httpService: HttpService) {
    }

    saveDiagnosis(diagnosis: any) {
        return this.httpService.post(environment.appointmenturl + "/diagnosis/save", diagnosis);
    }

    getAllDiagnosis() {
        return this.httpService.get(environment.appointmenturl + "/diagnosis/getall");
    }

    getAllNewDiagnosisData() {
        return this.httpService.get(environment.appointmenturl + "/diagnosis/get-newly-added-diagnosis");
    }

}