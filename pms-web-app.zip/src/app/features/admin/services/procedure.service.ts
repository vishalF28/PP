import { Injectable } from "@angular/core";
import { HttpService } from "src/app/core/services/http.service";
import { environment } from "src/environments/environment";


@Injectable({
    providedIn: "root"
})
export class ProcedureService {
    constructor(private httpService: HttpService) {

    }

    getAllProcedure() {
        return this.httpService.get(environment.appointmenturl + "/procedure/getall");
    }

    saveProcedure(Procedure: any) {
        return this.httpService.post(environment.appointmenturl + "/procedure/save", Procedure);
    }

    getAllNewProcedures() {
        return this.httpService.get(environment.appointmenturl + "/procedure/get-newly-added-procedures");
    }

}