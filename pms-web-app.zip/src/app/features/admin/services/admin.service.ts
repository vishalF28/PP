import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Subject } from 'rxjs';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';
import { AuthorizationService } from '../../authorization/services/authorization.service';
import { HospitalStaffResponse } from '../interfaces/hospital-staff-response.model';
import { PatientDetailsResponse } from '../interfaces/patient-details-response.model';
import { RegisterStaffRequest } from '../interfaces/register-staff-request.model';

@Injectable({
  providedIn: 'root'
})
export class AdminService {


  private patients: PatientDetailsResponse[] = [];
  private patientsUpdated = new Subject<PatientDetailsResponse[]>();

  private staffs: HospitalStaffResponse[] = [];
  private staffsUpdated = new Subject<HospitalStaffResponse[]>();


  constructor(private httpService: HttpService, private authService: AuthorizationService,
    private snackBar: MatSnackBar) { }

  getUserCountByRole(role: string) {
    return this.httpService.get<number>(environment.adminbaseurl + '/admin/get-count-by-role?role=' + role);
  }

  getPatientCount() {
    return this.httpService.get<number>(environment.adminbaseurl + '/admin/get-patient-count');
  }

  getNewAddedPatientCount() {
    return this.httpService.get<number>(environment.adminbaseurl + '/admin/get-new-patient-count');
  }

  getAllStaffData() {
    this.httpService.get<HospitalStaffResponse[]>(environment.adminbaseurl + '/admin/get-all-staff')
      .subscribe((response) => {
        this.staffs = response;
        const findIndexOfLoggedInAdmin = this.staffs.findIndex(
          (staff) => staff.emailId === this.authService.getEmail()
        );
        this.staffs.splice(findIndexOfLoggedInAdmin, 1);
        this.staffsUpdated.next([...this.staffs]);
      });
  }

  getStaffUpdatedDataListner() {
    return this.staffsUpdated.asObservable();
  }

  activateOrDeactivateStaffAccount(staffData, isAccountActive: boolean) {
    const staffToUpdate: HospitalStaffResponse = staffData;
    this.httpService.put(environment.adminbaseurl + '/admin/update-hospital-staff-status?emailId=' + staffData.emailId + '&status=' + isAccountActive, {})
      .subscribe(() => {
        const updatedStaff = [...this.staffs];
        const oldStaffIndex = updatedStaff.findIndex((staff) => staff.emailId === staffData.emailId);
        updatedStaff[oldStaffIndex] = staffToUpdate;
        staffToUpdate.isActive = isAccountActive;
        this.staffs = updatedStaff;
        this.staffsUpdated.next([...this.staffs]);
      });
  }

  getAllPatientData() {
    this.httpService.get<PatientDetailsResponse[]>(environment.adminbaseurl + '/admin/get-all-patient')
      .subscribe((response) => {
        this.patients = response;
        this.patientsUpdated.next([...this.patients]);
      });
  }

  getPatientUpdatedDataListner() {
    return this.patientsUpdated.asObservable();
  }

  activateOrDeactivatePatientAccount(patientData: PatientDetailsResponse, isAccountActive: boolean) {
    const patientToUpdate: PatientDetailsResponse = patientData;
    this.httpService.put(environment.adminbaseurl + '/admin/update-patient-status?emailId=' + patientData.emailId + '&status=' + isAccountActive, {})
      .subscribe((data) => {
        const updatedPatient = [...this.patients];
        const oldPatientIndex = updatedPatient.findIndex((patient) => patient.emailId === patientToUpdate.emailId);
        updatedPatient[oldPatientIndex] = patientToUpdate;
        patientToUpdate.isActive = isAccountActive;
        this.patients = updatedPatient;
        this.patientsUpdated.next([...this.patients]);
      });
  }

  registerNewHospitalStaff(hospitalstaff: any) {
    let hospitalStaffReqeust: RegisterStaffRequest = {
      emailId: hospitalstaff.emailId, title: hospitalstaff.title
      , firstName: hospitalstaff.firstName, lastName: hospitalstaff.lastName, role: hospitalstaff.role,
      birthDate: hospitalstaff.birthDate, contact: hospitalstaff.contact, speciality: hospitalstaff.speciality
      , gender: hospitalstaff.gender
    };
    this.httpService.post(environment.authbaseurl + '/authentication/provider-signup', hospitalStaffReqeust)
      .subscribe((response) => {
        this.snackBar.open(response.message, undefined, { duration: 3000 })
      });

  }

  getCountOfPhysicianBySpeciality() {
    return this.httpService.get(environment.adminbaseurl + '/admin/get-physican-count-by-speciality');
  }

  getCountOfNurseBySpeciality() {
    return this.httpService.get(environment.adminbaseurl + '/admin/get-nurse-count-by-speciality');
  }

}
