export interface AppointmentView {
    appointmentId: number;
    title: string;
    physicianEmailId: string;
    physicianName: string;
    patientId: number;
    patientName: string;
    dateOfAppointment: Date;
    timeOfAppointment: string;
    isVisited: boolean;
    isRescheduled: boolean;
    isDeleted: boolean;
}