export interface PatientVitalSigns {
    vitalSignId: number;
    appointmentId: number;
    patientId: number;
    patientName: string;
    height: number;
    weight: number;
    bloodPressure: number;
    temperature: number;
    respirationRate: number;
    capturedByNurseEmailId: string;
    capturedByNurseName: string;
    isVitalSignsCaptured: boolean;
}