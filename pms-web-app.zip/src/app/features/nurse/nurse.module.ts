import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientVisitManagementByNurseComponent } from './pages/patient-visit-management-by-nurse/patient-visit-management-by-nurse.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/common/material/material.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CaptureVitalSignsComponent } from './pages/capture-vital-signs/capture-vital-signs.component';
import { ManageAppointmentByNurseComponent } from './pages/manage-appointment-by-nurse/manage-appointment-by-nurse.component';
import { NurseDashboardComponent } from './pages/nurse-dashboard/nurse-dashboard.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';



@NgModule({
  declarations: [
    PatientVisitManagementByNurseComponent,
    CaptureVitalSignsComponent,
    ManageAppointmentByNurseComponent,
    NurseDashboardComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    FlexLayoutModule,
    NgxChartsModule
  ],
  exports: [NurseDashboardComponent]
})
export class NurseModule { }
