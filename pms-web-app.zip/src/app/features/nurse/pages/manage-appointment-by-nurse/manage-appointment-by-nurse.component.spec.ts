import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAppointmentByNurseComponent } from './manage-appointment-by-nurse.component';

describe('ManageAppointmentByNurseComponent', () => {
  let component: ManageAppointmentByNurseComponent;
  let fixture: ComponentFixture<ManageAppointmentByNurseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageAppointmentByNurseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAppointmentByNurseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
