import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { RescheduleAppointmentPhysicianComponent } from 'src/app/features/physician/pages/reschedule-appointment-physician/reschedule-appointment-physician.component';

import { TimingSlots } from 'src/app/shared/components/interfaces/timing-slots.model';
import { AppointmentView } from '../../interfaces/appointment-view.model';
import { NurseService } from '../../services/nurse.service';

@Component({
  selector: 'app-manage-appointment-by-nurse',
  templateUrl: './manage-appointment-by-nurse.component.html',
  styleUrls: ['./manage-appointment-by-nurse.component.css']
})
export class ManageAppointmentByNurseComponent implements OnInit {

  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  dataSourceAppointments: MatTableDataSource<AppointmentView> =
    new MatTableDataSource();
  appointmentSubscription: Subscription;
  resultlength: number;
  appointmentDetails: AppointmentView[] = [];

  tempDate: Date = new Date();
  todaysDate: Date = new Date(this.tempDate.getFullYear(), this.tempDate.getMonth(), this.tempDate.getDate());


  displayedColumns: string[] = ['title', 'patientName', 'physicianName', 'dateOfAppointment',
    'timeOfAppointment', 'action'];


  constructor(private nurseService: NurseService, private authService: AuthorizationService,
    private dialog: MatDialog, private snackBar: MatSnackBar, public loader: LoaderService) { }

  ngOnInit(): void {
    this.appointmentSubscription = this.nurseService.getPatientAppointmentsForManagement()
      .subscribe((response) => {
        response.forEach((appointment) => {
          const date = appointment.dateOfAppointment;
          const convertedDate = new Date(date);
          console.log(convertedDate.toString() >= this.todaysDate.toString())
          if (convertedDate >= this.todaysDate) {
            const appointmentHistoryModel: AppointmentView = {
              appointmentId: 0, title: '', physicianEmailId: '', dateOfAppointment: new Date(), timeOfAppointment: '',
              isVisited: false, isRescheduled: false, isDeleted: false, physicianName: '',
              patientName: '', patientId: 0,
            };
            appointmentHistoryModel.appointmentId = appointment.appointmentId;
            appointmentHistoryModel.title = appointment.title;
            appointmentHistoryModel.dateOfAppointment = appointment.dateOfAppointment;
            appointmentHistoryModel.physicianEmailId = appointment.physicianEmailId;
            appointmentHistoryModel.physicianName = appointment.physicianName;
            appointmentHistoryModel.patientName = appointment.patientName;
            appointmentHistoryModel.timeOfAppointment = TimingSlots[appointment.timeOfAppointment];
            appointmentHistoryModel.isVisited = appointment.isVisited;
            appointmentHistoryModel.isRescheduled = appointment.isRescheduled;
            appointmentHistoryModel.isDeleted = appointment.isDeleted;
            appointmentHistoryModel.patientId = appointment.patientId;
            this.appointmentDetails.push(appointmentHistoryModel);
          }
        });
        this.dataSourceAppointments = new MatTableDataSource(this.appointmentDetails);
        this.dataSourceAppointments.sort = this.sort;
        this.dataSourceAppointments.paginator = this.paginator;
        this.resultlength = this.dataSourceAppointments.data.length;
      });
  }

  doFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceAppointments.filter = filterValue.trim().toLowerCase();
    if (this.dataSourceAppointments.paginator) {
      this.dataSourceAppointments.paginator.firstPage();
    }
  }

  reschedule(appointmentId: number) {
    const dialogRef = this.dialog.open(RescheduleAppointmentPhysicianComponent, { data: appointmentId });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.dataSourceAppointments.data.forEach(element => {
          if (element.appointmentId === result.currentAppointmentData.appointmentId) {
            element.dateOfAppointment = result.currentAppointmentData.dateOfAppointment;
            element.timeOfAppointment = TimingSlots[result.currentAppointmentData.timeOfAppointment];
          }
        });
      }
    });
  }

}
