import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaptureVitalSignsComponent } from './capture-vital-signs.component';

describe('CaptureVitalSignsComponent', () => {
  let component: CaptureVitalSignsComponent;
  let fixture: ComponentFixture<CaptureVitalSignsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CaptureVitalSignsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CaptureVitalSignsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
