import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PatientVitalSigns } from '../../interfaces/patient-vital-signs.model';
import { NurseService } from '../../services/nurse.service';

@Component({
  selector: 'app-capture-vital-signs',
  templateUrl: './capture-vital-signs.component.html',
  styleUrls: ['./capture-vital-signs.component.css']
})
export class CaptureVitalSignsComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public patientVitalSignModel: PatientVitalSigns,
    private dialog: MatDialogRef<CaptureVitalSignsComponent>) { }

  ngOnInit(): void {

  }

  addVitalSigns() {
    this.dialog.close({ data: this.patientVitalSignModel });
  }

  closeDialog() {
    this.dialog.close();
  }
}
