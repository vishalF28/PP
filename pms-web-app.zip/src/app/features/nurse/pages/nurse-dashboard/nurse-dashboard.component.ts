import { Component, OnInit } from '@angular/core';
import { LoaderService } from 'src/app/core/services/loader.service';
import { NurseService } from '../../services/nurse.service';

@Component({
  selector: 'app-nurse-dashboard',
  templateUrl: './nurse-dashboard.component.html',
  styleUrls: ['./nurse-dashboard.component.css']
})
export class NurseDashboardComponent implements OnInit {

  todaysAppointmentCount: number = 0;

  patientCount: number = 0;

  specialityPhysicianCount = [];
  patientVisitRatio = [];

  constructor(private nurseService: NurseService, public loader: LoaderService) {
    Object.assign(this.specialityPhysicianCount);
    Object.assign(this.patientVisitRatio);
  }

  ngOnInit(): void {
    this.nurseService.getPatientCount().subscribe((data) => { this.patientCount = data });
    this.nurseService.getTodaysAppointmentCount().subscribe((data) => { this.todaysAppointmentCount = data });
    this.nurseService.getCountOfPhysicianBySpeciality().subscribe(
      (response) => {
        Object.keys(response).forEach((element) => {
          this.specialityPhysicianCount.push({ name: element, value: response[element] });
        })
        this.specialityPhysicianCount = [...this.specialityPhysicianCount];
      });

    this.nurseService.getPatientVisitRatio().subscribe(
      (response) => {
        Object.keys(response).forEach((element) => {
          this.patientVisitRatio.push({ name: element, value: response[element] });
        })
        this.patientVisitRatio = [...this.patientVisitRatio];
      });


  }

}
