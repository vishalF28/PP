import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientVisitManagementByNurseComponent } from './patient-visit-management-by-nurse.component';

describe('PatientVisitManagementByNurseComponent', () => {
  let component: PatientVisitManagementByNurseComponent;
  let fixture: ComponentFixture<PatientVisitManagementByNurseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatientVisitManagementByNurseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientVisitManagementByNurseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
