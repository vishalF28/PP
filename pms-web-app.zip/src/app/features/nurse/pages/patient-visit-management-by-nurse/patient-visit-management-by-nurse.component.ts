import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { TimingSlots } from 'src/app/shared/components/interfaces/timing-slots.model';
import { ViewPatientProfileByStaffComponent } from 'src/app/shared/components/pages/view-patient-profile-by-staff/view-patient-profile-by-staff.component';
import { AppointmentView } from '../../interfaces/appointment-view.model';
import { PatientVitalSigns } from '../../interfaces/patient-vital-signs.model';
import { NurseService } from '../../services/nurse.service';
import { CaptureVitalSignsComponent } from '../capture-vital-signs/capture-vital-signs.component';

@Component({
  selector: 'app-patient-visit-management-by-nurse',
  templateUrl: './patient-visit-management-by-nurse.component.html',
  styleUrls: ['./patient-visit-management-by-nurse.component.css'],
})
export class PatientVisitManagementByNurseComponent implements OnInit {
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  dataSourceAppointments: MatTableDataSource<AppointmentView> =
    new MatTableDataSource();
  appointmentSubscription: Subscription;
  resultlength: number;
  appointmentDetails: AppointmentView[] = [];
  patientEmailId: string;

  displayedColumns: string[] = [
    'title',
    'patientName',
    'physicianName',
    'dateOfAppointment',
    'timeOfAppointment',
    'action',
    'action2'
  ];

  patientVitalSignModel: any = {
    patientId: 0,
    patientName: '',
    height: 0,
    weight: 0,
    bloodPressure: 0,
    temperature: 0,
    respirationRate: 0,
    capturedByNurseEmailId: '',
    isVitalSignsCaptured: false,
    vitalSignId: 0,
  };
  constructor(
    private nurseService: NurseService,
    private authService: AuthorizationService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    public loader: LoaderService
  ) { }

  ngOnInit(): void {
    this.appointmentSubscription = this.nurseService
      .getPatientAppointmentsForCaptureVitalSigns()
      .subscribe((response) => {
        response.forEach((appointment) => {
          this.patientEmailId = appointment.patientEmailId;
          const appointmentHistoryModel: AppointmentView = {
            appointmentId: 0,
            title: '',
            physicianEmailId: '',
            dateOfAppointment: new Date(),
            timeOfAppointment: '',
            isVisited: false,
            isRescheduled: false,
            isDeleted: false,
            physicianName: '',
            patientName: '',
            patientId: 0,
          };
          appointmentHistoryModel.appointmentId = appointment.appointmentId;
          appointmentHistoryModel.title = appointment.title;
          appointmentHistoryModel.dateOfAppointment =
            appointment.dateOfAppointment;
          appointmentHistoryModel.physicianEmailId =
            appointment.physicianEmailId;
          appointmentHistoryModel.physicianName = appointment.physicianName;
          appointmentHistoryModel.patientName = appointment.patientName;
          appointmentHistoryModel.timeOfAppointment =
            TimingSlots[appointment.timeOfAppointment];
          appointmentHistoryModel.isVisited = appointment.isVisited;
          appointmentHistoryModel.isRescheduled = appointment.isRescheduled;
          appointmentHistoryModel.isDeleted = appointment.isDeleted;
          appointmentHistoryModel.patientId = appointment.patientId;
          this.appointmentDetails.push(appointmentHistoryModel);
        });
        this.dataSourceAppointments = new MatTableDataSource(
          this.appointmentDetails
        );
        this.dataSourceAppointments.sort = this.sort;
        this.dataSourceAppointments.paginator = this.paginator;
        this.resultlength = this.dataSourceAppointments.data.length;
      });
  }

  doFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSourceAppointments.filter = filterValue.trim().toLowerCase();

    if (this.dataSourceAppointments.paginator) {
      this.dataSourceAppointments.paginator.firstPage();
    }
  }

  captureVitalSigns(appointmentId: number) {
    const appointmentDetail = this.appointmentDetails.find(
      (appointment) => appointment.appointmentId === appointmentId
    );
    this.patientVitalSignModel.appointmentId = appointmentDetail.appointmentId;
    this.patientVitalSignModel.patientId = appointmentDetail.patientId;
    this.patientVitalSignModel.patientName = appointmentDetail.patientName;
    this.patientVitalSignModel.capturedByNurseEmailId =
      this.authService.getEmail();
    this.patientVitalSignModel.capturedByNurseName =
      this.authService.getTitle() +
      '. ' +
      this.authService.getFirstName() +
      ' ' +
      this.authService.getLastName();
    const dialogRef = this.dialog.open(CaptureVitalSignsComponent, {
      data: this.patientVitalSignModel,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const patientVitalSigns: PatientVitalSigns = {
          patientId: 0,
          patientName: '',
          height: 0,
          weight: 0,
          bloodPressure: 0,
          temperature: 0,
          respirationRate: 0,
          capturedByNurseEmailId: '',
          isVitalSignsCaptured: false,
          vitalSignId: 0,
          appointmentId: 0,
          capturedByNurseName: '',
        };
        patientVitalSigns.patientId = result.data.patientId;
        patientVitalSigns.patientName = result.data.patientName;
        patientVitalSigns.height = result.data.height;
        patientVitalSigns.weight = result.data.weight;
        patientVitalSigns.bloodPressure = result.data.bloodPressure;
        patientVitalSigns.temperature = result.data.temperature;
        patientVitalSigns.respirationRate = result.data.respirationRate;
        patientVitalSigns.appointmentId = result.data.appointmentId;
        patientVitalSigns.capturedByNurseName = result.data.capturedByNurseName;
        patientVitalSigns.capturedByNurseEmailId =
          result.data.capturedByNurseEmailId;
        patientVitalSigns.isVitalSignsCaptured =
          result.data.isVitalSignsCaptured;
        patientVitalSigns.vitalSignId = 0;
        this.nurseService.addVitalSignsToPatientAppointment(patientVitalSigns)
          .subscribe((response) => {
            this.snackBar.open(response.message, undefined, { duration: 3000 });
            this.dataSourceAppointments.data = this.dataSourceAppointments.data.filter(
              (appointment) => { return appointment.appointmentId != result.data.appointmentId }
            )
          });
      }
    });
  }

  viewProfile() {
    const profileDialog = this.dialog.open(ViewPatientProfileByStaffComponent, { data: this.patientEmailId });
  }
}
