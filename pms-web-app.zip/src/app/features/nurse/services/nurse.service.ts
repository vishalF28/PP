import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';
import { PatientVitalSigns } from '../interfaces/patient-vital-signs.model';

@Injectable({
  providedIn: 'root'
})
export class NurseService {

  constructor(private httpService: HttpService) { }

  getPatientAppointmentsForCaptureVitalSigns() {
    return this.httpService.get(environment.appointmenturl + '/appointment/get-appointments-to-capture-vital-signs');
  }

  getPatientAppointmentsForManagement() {
    return this.httpService.get(environment.appointmenturl + '/appointment/get-upcoming-appointments');
  }

  addVitalSignsToPatientAppointment(patientVitalSign: PatientVitalSigns) {
    return this.httpService.post(environment.appointmenturl + '/vital-signs/save', patientVitalSign);
  }

  getPatientCount() {
    return this.httpService.get<number>(environment.adminbaseurl + '/admin/get-patient-count');
  }

  getTodaysAppointmentCount() {
    return this.httpService.get<number>(environment.appointmenturl + '/appointment/get-todays-appointment-count');
  }

  getCountOfPhysicianBySpeciality() {
    return this.httpService.get(environment.adminbaseurl + '/admin/get-physican-count-by-speciality');
  }

  getPatientVisitRatio() {
    return this.httpService.get(environment.appointmenturl + '/appointment/get-patient-visited-ratio-for-nurse');
  }


}
