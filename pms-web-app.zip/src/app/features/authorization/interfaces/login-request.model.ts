export interface LoginRequest {
    emailId: string;
    password: string;
}