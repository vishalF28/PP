export interface LoginResponse {
    title: string;
    role: string;
    firstName: string;
    lastName: string;
    isFirstTimeLogin: boolean;
    expiresIn: number;
    emailId: string;
    accessToken: string;
}