import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';
import { LoginRequest } from '../interfaces/login-request.model';
import { LoginResponse } from '../interfaces/login-response.model';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {

  private tokenTimer: any;
  private isAuthenticated: boolean = false;
  private authStatusListener = new Subject<boolean>();
  private firstName: string;
  private lastName: string;
  private role: string;
  private emailId: string;
  private title: string;

  getIsAuth() {
    return this.isAuthenticated;
  }

  getAuthStatusListener() {
    return this.authStatusListener.asObservable();
  }

  getFirstName() {
    return this.firstName;
  }

  getLastName() {
    return this.lastName;
  }

  getRole() {
    return this.role;
  }

  getEmail() {
    return this.emailId;
  }

  getTitle() {
    return this.title;
  }

  constructor(private httpService: HttpService, private router: Router,
    private snackBar: MatSnackBar) { }

  loginUser(loginviewmodel: any) {
    let loginRequest: LoginRequest = { emailId: loginviewmodel.emailId, password: loginviewmodel.password };
    this.httpService.post<LoginResponse>(environment.authbaseurl + '/authentication/login', loginRequest)
      .subscribe(
        (response) => {
          if (response.accessToken) {
            this.isAuthenticated = true;
            this.authStatusListener.next(true);
            this.firstName = response.firstName;
            this.lastName = response.lastName;
            this.emailId = response.emailId;
            this.role = response.role;
            this.title = response.title;
            const expiresIn = response.expires_in || 24 * 24 * 60;
            this.setAuthTimer(expiresIn);
            const now = new Date();
            const expirationInDate = new Date(now.getTime() + expiresIn * 1000);
            this.saveAuthorizationDataToLocalStorage(response.accessToken, expirationInDate, this.emailId,
              this.firstName, this.lastName, this.role, this.title);

            if (response.isFirstTimeLogin) {
              this.router.navigate(['/change-password']);
            }
            else {
              this.router.navigate(['/dashboard']);
            }
          } else {
            this.snackBar.open(response.message, undefined, { duration: 3000 })
          }
        }
      );
  }
  saveAuthorizationDataToLocalStorage(accessToken: any, expirationInDate: Date, emailId: string,
    firstName: string, lastName: string, role: string, title: string) {
    localStorage.setItem('accessToken', accessToken);
    localStorage.setItem('expirationInDate', expirationInDate.toString());
    localStorage.setItem('emailId', emailId);
    localStorage.setItem('firstName', firstName);
    localStorage.setItem('lastName', lastName);
    localStorage.setItem('title', title);
    localStorage.setItem('role', role);
  }

  setAuthTimer(expiresIn: any) {
    this.tokenTimer = setTimeout(() => { this.logout(); }, expiresIn * 1000);
  }

  fetchAuthorizationDataFromLocalStorage() {
    const accessToken = localStorage.getItem('accessToken');
    const expirationInDate = localStorage.getItem('expirationInDate');
    const emailId = localStorage.getItem('emailId');
    const firstName = localStorage.getItem('firstName');
    const lastName = localStorage.getItem('lastName');
    const role = localStorage.getItem('role');
    const title = localStorage.getItem('title');

    if (!accessToken || !expirationInDate) {
      return;
    }
    return {
      accessToken: accessToken, expirationInDate: new Date(expirationInDate),
      emailId: emailId, firstName: firstName, lastName: lastName,
      role: role, title: title
    };
  }

  clearAuthorizationDataFromLocalStorage() {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('expirationInDate');
    localStorage.removeItem('emailId');
    localStorage.removeItem('firstName');
    localStorage.removeItem('lastName');
    localStorage.removeItem('role');
    localStorage.removeItem('title');
  }

  logout() {
    this.isAuthenticated = false;
    this.emailId = null;
    this.authStatusListener.next(false);
    clearTimeout(this.tokenTimer);
    this.clearAuthorizationDataFromLocalStorage();
    this.router.navigate(['/login']);
  }

  autoAuthenticateUser() {
    const authInformation = this.fetchAuthorizationDataFromLocalStorage();
    if (!authInformation) {
      return;
    }
    const now = new Date();
    const expiresIn = authInformation.expirationInDate.getTime() - now.getTime();
    if (expiresIn > 0) {
      this.emailId = authInformation.emailId;
      this.firstName = authInformation.firstName;
      this.lastName = authInformation.lastName;
      this.role = authInformation.role;
      this.title = authInformation.title;
      this.setAuthTimer(expiresIn / 1000);
      this.isAuthenticated = true;
      this.httpService.get(environment.notesmessagesurl + '/notify').subscribe();
      this.authStatusListener.next(true);
    }
  }
}
