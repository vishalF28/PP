import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AuthorizationService } from '../../services/authorization.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginviewmodel: any = { emailId: '', password: '' };

  hidePassword: boolean = true;

  constructor(private authService: AuthorizationService, public loader: LoaderService) { }

  ngOnInit(): void {
  }

  loginUser(loginForm: NgForm) {
    this.authService.loginUser(this.loginviewmodel);
  }
}
