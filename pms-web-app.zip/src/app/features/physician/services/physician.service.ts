import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PhysicianService {


  constructor(private httpService: HttpService) { }

  getAppointmentsByPhysician(physicianEmailId: string) {
    return this.httpService.get(environment.appointmenturl + "/appointment/get-appointments-for-calender/" + physicianEmailId)
  }

  getAppointmentDetails(appointmentId: number) {
    return this.httpService.get(environment.appointmenturl + "/appointment/get-appointment/" + appointmentId);
  }

  rescheduleAppointment(currentAppointment) {
    return this.httpService.post(environment.appointmenturl + "/appointment/reschedule-appointment", currentAppointment);
  }

  deleteAppointment(appointmentId: number) {
    return this.httpService.put(environment.appointmenturl + "/appointment/delete-appointment/" + appointmentId, {});
  }

  getPatientCount() {
    return this.httpService.get<number>(environment.adminbaseurl + '/admin/get-patient-count');
  }

  getTodaysAppointmentCount(physicianEmailId: string) {
    return this.httpService.get<number>(environment.appointmenturl + '/appointment/get-todays-appointment-count-for-physician/' + physicianEmailId);
  }

  getWeeklyAppointmentData(physicianEmailId: string) {
    return this.httpService.get<number>(environment.appointmenturl + '/appointment/get-weekly-appointment/' + physicianEmailId);
  }

  getPatientTreatedGenderWise(physicianEmailId: string) {
    return this.httpService.get<number>(environment.appointmenturl + '/appointment/get-patient-treated-by-gender-wise/' + physicianEmailId);
  }
}
