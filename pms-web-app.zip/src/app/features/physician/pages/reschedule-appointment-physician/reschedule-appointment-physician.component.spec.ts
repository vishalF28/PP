import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RescheduleAppointmentPhysicianComponent } from './reschedule-appointment-physician.component';

describe('RescheduleAppointmentPhysicianComponent', () => {
  let component: RescheduleAppointmentPhysicianComponent;
  let fixture: ComponentFixture<RescheduleAppointmentPhysicianComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RescheduleAppointmentPhysicianComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RescheduleAppointmentPhysicianComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
