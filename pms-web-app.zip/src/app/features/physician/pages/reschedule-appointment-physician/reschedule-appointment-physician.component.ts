import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { TimingSlots } from 'src/app/shared/components/interfaces/timing-slots.model';
import { SchedulingAppointmentService } from 'src/app/shared/components/services/scheduling-appointment.service';
import { PhysicianService } from '../../services/physician.service';

@Component({
  selector: 'app-reschedule-appointment-physician',
  templateUrl: './reschedule-appointment-physician.component.html',
  styleUrls: ['./reschedule-appointment-physician.component.css']
})
export class RescheduleAppointmentPhysicianComponent implements OnInit {

  minDate = new Date();
  maxDate = new Date(this.minDate.getFullYear(), this.minDate.getMonth() + 3, this.minDate.getDay());
  role: string;
  timeSlotDataSet: any[];
  timeAvailableSlots: string[] = [];

  selectedTimeSlot: string = '';
  isTimeSlotSelected: boolean = false;

  isEdited: boolean = true;
  currentAppointment = {
    appointmentId: 0, dateOfAppointment: new Date(), patientId: 0, patientName: '', physicianId: 0,
    physicianName: '', physicianEmailId: '', timeOfAppointment: '', title: '', isDeleted: false,
    isRescheduled: false, description: '', isDateChanged: false
  }
  constructor(@Inject(MAT_DIALOG_DATA) private appointmentId: number, private physicianService: PhysicianService,
    private schedulingAppointmentService: SchedulingAppointmentService, private dialogRef: MatDialogRef<RescheduleAppointmentPhysicianComponent>,
    private authService: AuthorizationService, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.role = this.authService.getRole();
    this.physicianService.getAppointmentDetails(this.appointmentId).subscribe(response => {
      this.currentAppointment = response;
      this.currentAppointment.timeOfAppointment = TimingSlots[this.currentAppointment.timeOfAppointment];
    });
  }

  onDateSelect() {
    this.currentAppointment.isDateChanged = true;
    this.schedulingAppointmentService.getAvailableSlotsForPhysicianByDate(this.currentAppointment.physicianEmailId,
      this.currentAppointment.dateOfAppointment).subscribe(response => {
        this.timeSlotDataSet = response;
        this.timeAvailableSlots = [];
        this.timeSlotDataSet.forEach((timeslot) => {
          this.timeAvailableSlots.push(TimingSlots[timeslot]);
        });
      });
  }

  editAppointment() {
    const dateOfRescheduled = new Date(this.currentAppointment.dateOfAppointment);
    this.isEdited = false;
    this.schedulingAppointmentService.getAvailableSlotsForPhysicianByDate(this.currentAppointment.physicianEmailId,
      dateOfRescheduled).subscribe(response => {
        this.timeSlotDataSet = response;
        this.timeAvailableSlots = [];
        this.timeSlotDataSet.forEach((timeslot) => {
          this.timeAvailableSlots.push(TimingSlots[timeslot]);
        });
      });
  }

  deleteAppointment() {
    this.physicianService.deleteAppointment(this.currentAppointment.appointmentId).subscribe(response => {
      this.snackBar.open("Appointment deleted successfully.", undefined, { duration: 3000 });
      this.dialogRef.close({ currentAppointmentData: 'deleted' });
    });
  }

  setTimeSlot(timeslot: string) {
    this.selectedTimeSlot = timeslot;
    this.isTimeSlotSelected = true;
    this.currentAppointment.timeOfAppointment = timeslot;
  }

  rescheduleAppointment() {
    this.currentAppointment.timeOfAppointment = TimingSlots[this.currentAppointment.timeOfAppointment];
    this.physicianService.rescheduleAppointment(this.currentAppointment).subscribe(response => {
      this.snackBar.open("Appointment rescheduled successfully.", undefined, { duration: 3000 });
      this.dialogRef.close({ currentAppointmentData: this.currentAppointment });
    });
  }

  dialogClose() {
    this.dialogRef.close();
  }
}
