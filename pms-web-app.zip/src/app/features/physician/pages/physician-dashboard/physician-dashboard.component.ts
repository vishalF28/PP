import { Component, OnInit } from '@angular/core';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { PhysicianService } from '../../services/physician.service';

@Component({
  selector: 'app-physician-dashboard',
  templateUrl: './physician-dashboard.component.html',
  styleUrls: ['./physician-dashboard.component.css']
})
export class PhysicianDashboardComponent implements OnInit {

  appointmentData = [];

  patientDataByGender = [];

  todaysAppointmentCount: number = 0;

  patientCount: number = 0;

  constructor(private physicianService: PhysicianService, private authService: AuthorizationService,
    public loader: LoaderService) {
    Object.assign(this.appointmentData);
    Object.assign(this.patientDataByGender);
  }


  ngOnInit(): void {
    this.physicianService.getPatientCount().subscribe((data) => { this.patientCount = data });
    this.physicianService.getTodaysAppointmentCount(this.authService.getEmail()).subscribe((data) => { this.todaysAppointmentCount = data });
    this.physicianService.getWeeklyAppointmentData(this.authService.getEmail()).subscribe(
      (response) => {
        response.forEach(element => {
          this.appointmentData.push({ name: element.name, value: element.count });
        });
        this.appointmentData = [...this.appointmentData];
      }
    );
    this.physicianService.getPatientTreatedGenderWise(this.authService.getEmail()).subscribe(
      (response) => {
        response.forEach(element => {
          this.patientDataByGender.push({ name: element.name + "(" + element.count + ")", value: element.count });
        });
        this.patientDataByGender = [...this.patientDataByGender];
      }
    );
  }

  onSelect(event) {
    console.log(event);
  }

}
