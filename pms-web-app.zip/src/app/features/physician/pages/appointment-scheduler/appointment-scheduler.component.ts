import { ChangeDetectionStrategy, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CalendarEvent, CalendarEventAction, CalendarEventTimesChangedEvent, CalendarView } from 'angular-calendar';
import { subDays, startOfDay, addDays, endOfMonth, addHours, isSameDay, isSameMonth, endOfDay, setHours, setMinutes, parseISO } from 'date-fns';
import { Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PhysicianService } from '../../services/physician.service';
import { AuthorizationService } from 'src/app/features/authorization/services/authorization.service';
import { TimingSlots } from 'src/app/shared/components/interfaces/timing-slots.model';
import { MatDialog } from '@angular/material/dialog';
import { RescheduleAppointmentPhysicianComponent } from '../reschedule-appointment-physician/reschedule-appointment-physician.component';

const colors: any = {
  red: {
    primary: '#ad2121',
    secondary: '#FAE3E3',
  },
  blue: {
    primary: '#1e90ff',
    secondary: '#D1E8FF',
  },
  yellow: {
    primary: '#e3bc08',
    secondary: '#FDF1BA',
  },
};

@Component({
  selector: 'app-appointment-scheduler',
  templateUrl: './appointment-scheduler.component.html',
  styleUrls: ['./appointment-scheduler.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppointmentSchedulerComponent implements OnInit {

  @ViewChild('modalContent', { static: true }) modalContent: TemplateRef<any>;
  view: CalendarView = CalendarView.Month;
  CalendarView = CalendarView;


  refresh: Subject<any> = new Subject();

  events: CalendarEvent[] = [
  ];

  activeDayIsOpen: boolean = true;
  viewDate: Date = new Date();

  tempDate: Date = new Date();
  todaysDate: Date = new Date(this.tempDate.getFullYear(), this.tempDate.getMonth(), this.tempDate.getDate());


  constructor(private modal: NgbModal, private physicianService: PhysicianService,
    private authService: AuthorizationService, private dialog: MatDialog) { }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
      this.viewDate = date;
    }
  }


  handleEvent(event: CalendarEvent): void {
    const dialogRef = this.dialog.open(RescheduleAppointmentPhysicianComponent, { data: event.id });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (result.currentAppointmentData === 'deleted') {
          const arrayIndex: number = parseInt(event.id.toString());
          this.events = this.events.filter(tempEvent => tempEvent.id != event.id);
        }
        else if (result) {
          this.events.forEach(event => {
            const num: number = parseInt(event.id.toString());
            if (num === result.currentAppointmentData.appointmentId) {
              const timeslot = TimingSlots[result.currentAppointmentData.timeOfAppointment];
              const timeSlotValues: any[] = timeslot.split(" ");
              const startHourValues: any[] = timeSlotValues[0].split(":");
              let startHour: number = Number.parseInt(startHourValues[0]);
              const startMinute = startHourValues[1];
              if (timeSlotValues[1] === 'PM') {
                startHour = startHour + 12;
              }
              if (result.currentAppointmentData.isDateChanged)
                event.start = setHours(setMinutes(result.currentAppointmentData.dateOfAppointment, startMinute), startHour);
              else
                event.start = setHours(setMinutes(parseISO(result.currentAppointmentData.dateOfAppointment), startMinute), startHour);
            }
          });
        }
        this.refresh.next();
      }
    });
  }

  ngOnInit(): void {
    this.todaysDate.setHours(0, 0, 0, 0);
    this.physicianService.getAppointmentsByPhysician(this.authService.getEmail())
      .subscribe(response => {
        console.log(response)
        response.forEach(appointment => {
          const date = appointment.dateOfAppointment;
          const convertedDate = new Date(date);
          console.log(convertedDate.toString() >= this.todaysDate.toString())
          if (convertedDate >= this.todaysDate) {
            const timeslot = TimingSlots[appointment.timeOfAppointment];
            const timeSlotValues: any[] = timeslot.split(" ");
            const startHourValues: any[] = timeSlotValues[0].split(":");
            let startHour: number = Number.parseInt(startHourValues[0]);
            const startMinute = startHourValues[1];
            if (timeSlotValues[1] === 'PM') {
              startHour = startHour + 12;
            }
            const event: CalendarEvent = { title: '', start: null, color: null };
            event.id = appointment.appointmentId;
            event.title = appointment.title;
            event.start = setHours(setMinutes(parseISO(appointment.dateOfAppointment), startMinute), startHour);
            event.color = colors.yellow;
            this.events.push(event);
            this.refresh.next();
          }
        });
      });
  }

  setView(view: CalendarView) {
    this.view = view;
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }

}
