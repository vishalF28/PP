import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppointmentSchedulerComponent } from './pages/appointment-scheduler/appointment-scheduler.component';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/common/material/material.module';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { FlatpickrModule } from 'angularx-flatpickr';
import { RescheduleAppointmentPhysicianComponent } from './pages/reschedule-appointment-physician/reschedule-appointment-physician.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PhysicianDashboardComponent } from './pages/physician-dashboard/physician-dashboard.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';

@NgModule({
  declarations: [
    AppointmentSchedulerComponent,
    RescheduleAppointmentPhysicianComponent,
    PhysicianDashboardComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    MaterialModule,
    FlexLayoutModule,
    NgbModalModule,
    FlatpickrModule.forRoot(),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
    NgxChartsModule
  ],
  exports: [PhysicianDashboardComponent]
})
export class PhysicianModule { }
