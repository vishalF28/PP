export const environment = {
  production: true,
  authbaseurl: 'http://localhost:9999/authentication-service',
  adminbaseurl: 'http://localhost:9999/hospital-staff-service',
  patientbaseurl: 'http://localhost:9999/patient-service',
  appointmenturl: 'http://localhost:9999/scheduling-service',
  notesmessagesurl: 'http://localhost:9999/notes-service'
};
