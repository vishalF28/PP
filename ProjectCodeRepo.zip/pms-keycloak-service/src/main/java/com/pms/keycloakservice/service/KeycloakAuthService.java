/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.keycloakservice.service;

import org.springframework.stereotype.Service;

import com.pms.keycloakservice.model.ChangePasswordRequest;
import com.pms.keycloakservice.model.CreateUserRequest;
import com.pms.keycloakservice.model.LoginRequest;
import com.pms.keycloakservice.model.LoginResponse;


/**
 * The Interface KeycloakAuthService.
 */
@Service
public interface KeycloakAuthService {

	public LoginResponse keycloakLoginService(LoginRequest userRequest);

	public void keycloakChangePasswordService(ChangePasswordRequest changePasswordRequest);

	public void createKeycloakUser(CreateUserRequest createUserRequest);
	
}
