/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.keycloakservice.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * The Class KeyCloakCreateUserRequest.
 */
@Getter
@Setter
@ToString
public class KeyCloakCreateUserRequest {

	private String username;
	
	private boolean enabled;
	
	private boolean totp;
	
	private boolean emailVerified;
	
	private String firstName;
	
	private String lastName;
	
	private String email;
	
	private CredentialsCreateUserRequest[] credentials;
	
	private String[] realmRoles = { "offline_access", "uma_authorization" };

	public KeyCloakCreateUserRequest()
	{
		credentials = new CredentialsCreateUserRequest[1];
	}
}
