/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.keycloakservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pms.keycloakservice.model.ChangePasswordRequest;
import com.pms.keycloakservice.model.CreateUserRequest;
import com.pms.keycloakservice.model.LoginRequest;
import com.pms.keycloakservice.model.LoginResponse;
import com.pms.keycloakservice.service.KeycloakAuthService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @author OmkarK4
 *
 */
@RestController
@RequestMapping("/keycloak")
@Api(description = "Keycloak Authentication Controller")
public class KeycloakAuthenticationController {

	private KeycloakAuthService keycloakAuthService;
	
	public KeycloakAuthenticationController() {}
	
	@Autowired
	public KeycloakAuthenticationController(KeycloakAuthService keycloakAuthService) {
		this.keycloakAuthService = keycloakAuthService;
	}
	
	/**
	 * Gets the login details.
	 * @param inputUserRequest the input user request
	 * @return the login details
	 */
	@PostMapping("/login")
	@ApiOperation(value = "Login using Keycloak API")
	public ResponseEntity<LoginResponse> getLoginDetails(@RequestBody LoginRequest loginRequest) {
		LoginResponse loginResponse = keycloakAuthService.keycloakLoginService(loginRequest);
		System.out.println(loginResponse);
		return new ResponseEntity<>(loginResponse, HttpStatus.OK);
	}
	
	/**
	 * Change password.
	 *
	 * @param changePasswordRequest the change password request
	 * @return the change password response
	 */
	@PostMapping("/changepassword")
	@ApiOperation(value = "Change Password using Keycloak API")
	public ResponseEntity<String> changePassword(@RequestBody ChangePasswordRequest changePasswordRequest) {
		keycloakAuthService.keycloakChangePasswordService(changePasswordRequest);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	/**
	 * Creates the keycloak user.
	 *
	 * @param createUserRequest the create user request
	 * @return the creates the user response
	 */
	@PostMapping("/createuser")
	@ApiOperation(value = "Create User using Keycloak API")
	public ResponseEntity<String> createKeycloakUser(@RequestBody CreateUserRequest createUserRequest) {
		System.out.println("createUserRequest: "+createUserRequest);
		keycloakAuthService.createKeycloakUser(createUserRequest);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
}
