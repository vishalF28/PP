/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.keycloakservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class ChangePasswordRequest.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChangePasswordRequest {

	private String emailId;
		
	private String newPassword;
		
}
