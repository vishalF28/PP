/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.keycloakservice.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpClientErrorException.Unauthorized;
import org.springframework.web.client.RestTemplate;

import com.pms.keycloakservice.constants.MessageConstants;
import com.pms.keycloakservice.exception.InvalidCredentialsException;
import com.pms.keycloakservice.exception.UsernameAlreadyExistingException;
import com.pms.keycloakservice.model.ChangePasswordRequest;
import com.pms.keycloakservice.model.CreateUserRequest;
import com.pms.keycloakservice.model.CredentialsCreateUserRequest;
import com.pms.keycloakservice.model.GetRealmRoleIdResponse;
import com.pms.keycloakservice.model.KeyCloakChangePasswordRequest;
import com.pms.keycloakservice.model.KeyCloakCreateUserRequest;
import com.pms.keycloakservice.model.KeycloakResponse;
import com.pms.keycloakservice.model.LoginRequest;
import com.pms.keycloakservice.model.LoginResponse;
import com.pms.keycloakservice.model.UserDetails;
import com.pms.keycloakservice.model.UserRealmRoleMappingRequest;


/**
 * The Class KeycloakAuthServiceImpl.
 */
@Service
public class KeycloakAuthServiceImpl implements KeycloakAuthService {

	/** The obj rest template. */
	@Autowired
	private RestTemplate restTemplate;

	/** The env. */
	@Autowired
	private Environment env;


	/** The logger. */
	private static Logger logger = LogManager.getLogger(KeycloakAuthServiceImpl.class);

	/**
	 * Gets the login details service.
	 *
	 * @param userRequest the user request
	 * @return the login details service 
	 */
	@Override
	public LoginResponse keycloakLoginService(LoginRequest loginRequest) {

		logger.info("username: " + loginRequest.getEmailId());

		String uri = env.getProperty("keycloak.user.token");
		logger.info("uri for calling login service: " + uri);

		LoginResponse loginResponse = null;
		
		//Setting Header
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		// if you need to pass form parameters in request with headers.
		MultiValueMap<String, String> headerMap = new LinkedMultiValueMap<>();

		setHeaders(headerMap, loginRequest);

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(headerMap, headers);

		try {
			KeycloakResponse keycloakResponse = restTemplate.exchange(uri, HttpMethod.POST, request, KeycloakResponse.class).getBody();
			loginResponse = new LoginResponse();
			mapKeycloakResponseToUserResponse(keycloakResponse, loginResponse);
			logger.info("After successful call of login service");

		}
		catch(Unauthorized e) {
			throw new InvalidCredentialsException(e);
		}
		
		return loginResponse;
	}


	private void mapKeycloakResponseToUserResponse(KeycloakResponse keycloakResponse, LoginResponse loginResponse) {
		loginResponse.setAccessToken(keycloakResponse.getAccess_token());
		loginResponse.setExpiresIn(keycloakResponse.getExpires_in());
	}

	/**
	 * Sets the headers.
	 *
	 * @param headerMap the header map
	 * @param userRequest the user request
	 * @return the multi value map
	 */
	public MultiValueMap<String, String> setHeaders(MultiValueMap<String, String> headerMap, LoginRequest loginRequest) {
		headerMap.add("username", loginRequest.getEmailId());
		headerMap.add("password", loginRequest.getPassword());
		headerMap.add("client_id", env.getProperty("keycloak.clientId"));
		headerMap.add("grant_type", env.getProperty("keycloak.grantType"));
		headerMap.add("client_secret", env.getProperty("keycloak.clientSecret"));
		logger.info("username: " + loginRequest.getEmailId());
		logger.info("client_id: " + env.getProperty("keycloak.clientId"));
		logger.info("grant_type: " + env.getProperty("keycloak.grantType"));
		logger.info("client_secret: " + env.getProperty("keycloak.clientSecret"));
		return headerMap;
	}

	@Override
	public void keycloakChangePasswordService(ChangePasswordRequest changePasswordRequest) {
		
		LoginResponse loginResponse = getAdminDetails();
		
		UserDetails userDetails = getUserIdByUserName(changePasswordRequest.getEmailId(), loginResponse.getAccessToken());
		
		if(null!= userDetails) {
			ResponseEntity<String> changePasswordStatusResponse = changePassword(changePasswordRequest, userDetails.getId(), loginResponse.getAccessToken());
			if (HttpStatus.NO_CONTENT != changePasswordStatusResponse.getStatusCode()) {
				throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
			}
		}
	}


	
	private ResponseEntity<String> changePassword(ChangePasswordRequest changePasswordRequest, String userId, String accessToken) {
		final String CHANGE_PASSWORD_URI = env.getProperty("keycloak.changepassword")+ userId +"/reset-password";
		System.out.println(CHANGE_PASSWORD_URI);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		KeyCloakChangePasswordRequest updatePasswordRequest = new KeyCloakChangePasswordRequest();
		updatePasswordRequest.setTemporary(Boolean.FALSE);
		updatePasswordRequest.setValue(changePasswordRequest.getNewPassword());
		updatePasswordRequest.setType("passsword");
		setHeaderInterceptor(headers, accessToken);
		HttpEntity<KeyCloakChangePasswordRequest> entity = new HttpEntity<KeyCloakChangePasswordRequest>(updatePasswordRequest, headers);
		return restTemplate.exchange(CHANGE_PASSWORD_URI, HttpMethod.PUT, entity, String.class);  
	}


	private UserDetails getUserIdByUserName(String emailId, String accessToken) {
		HttpHeaders headers = new HttpHeaders();
        setHeaderInterceptor(headers, accessToken);
        HttpEntity<String> entity = new HttpEntity<String>(headers);
		return restTemplate.exchange(env.getProperty("keycloak.userid.url")+emailId, HttpMethod.GET, entity,new ParameterizedTypeReference<List<UserDetails>>() {}).getBody().get(0);
	}


	private void setHeaderInterceptor(HttpHeaders headers, String accessToken) {
		headers.set("Authorization", "Bearer " + accessToken);
	}


	private LoginResponse getAdminDetails() {
		final String URI_FOR_ADMIN_LOGIN = env.getProperty("keycloak.master.token.url");
		logger.info("uri for calling login service: " + URI_FOR_ADMIN_LOGIN);

		LoginResponse loginResponse = null;
		
		//Setting Header
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		// if you need to pass form parameters in request with headers.
		MultiValueMap<String, String> headerMap = new LinkedMultiValueMap<>();

		setAdminHeaders(headerMap);

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(headerMap, headers);

		try {
			KeycloakResponse keycloakResponse = restTemplate.exchange(URI_FOR_ADMIN_LOGIN, HttpMethod.POST, request, KeycloakResponse.class).getBody();
			loginResponse = new LoginResponse();
			mapKeycloakResponseToUserResponse(keycloakResponse, loginResponse);
			logger.info("After successful call of login service");

		}
		catch(Unauthorized e) {
			throw new InvalidCredentialsException(MessageConstants.INVALID_CREDENTIALS, e);
		}
		return loginResponse;
	}
	
	
	public MultiValueMap<String, String> setAdminHeaders(MultiValueMap<String, String> headerMap)
	{
		headerMap.add("username", env.getProperty("keycloak.admin.username"));
		headerMap.add("password", env.getProperty("keycloak.admin.password"));
		headerMap.add("client_id", env.getProperty("keycloak.admin.clientId"));
		headerMap.add("grant_type", env.getProperty("keycloak.grantType"));
		
		logger.info("username: " + env.getProperty("keycloak.admin.username"));
		logger.info("client_id: " + env.getProperty("keycloak.admin.clientId"));
		logger.info("grant_type: " + env.getProperty("keycloak.grantType"));
		
		return headerMap;
	}


	@Override
	public void createKeycloakUser(CreateUserRequest createUserRequest) {
		KeyCloakCreateUserRequest keyCloakCreateUserRequest = new KeyCloakCreateUserRequest();
		mapKeyCloakUserRequest(keyCloakCreateUserRequest, createUserRequest);
		
		LoginResponse loginResponse = getAdminDetails();
		
		System.out.println("loginResponse: "+loginResponse);
		GetRealmRoleIdResponse getRealmRoleIdResponse = null;
		UserDetails userDetails = null;

		UserRealmRoleMappingRequest userRealmRoleMappingRequest = null;
		
		ResponseEntity<String> createUserResponse = createUser(keyCloakCreateUserRequest, loginResponse.getAccessToken());
		System.out.println("createUserResponse"+ createUserResponse);
		if(HttpStatus.CREATED == createUserResponse.getStatusCode())
		{

			getRealmRoleIdResponse = getRealmRoleIdFromRoleName(createUserRequest.getRole(), loginResponse.getAccessToken());
			System.out.println("getRealmRoleIdResponse"+ getRealmRoleIdResponse);
			
			userDetails = getUserIdByUserName(createUserRequest.getEmailId(), loginResponse.getAccessToken());
			System.out.println("userDetails"+ userDetails);
			
			if(null!= userDetails) 
			{
				userRealmRoleMappingRequest = new UserRealmRoleMappingRequest();
				mapUserRealmMapping(userRealmRoleMappingRequest, getRealmRoleIdResponse);
				System.out.println("after mapping roles userRealmRoleMappingRequest: "+userRealmRoleMappingRequest);
				ResponseEntity<String> userRealmRoleMappingResponse = mapRoles(userRealmRoleMappingRequest,
						userDetails.getId(), loginResponse.getAccessToken());
				System.out.println("userRealmRoleMappingResponse"+ userRealmRoleMappingResponse);
				
				if (HttpStatus.NO_CONTENT != userRealmRoleMappingResponse.getStatusCode()) {
					throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
				}
			}
		}
		else
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}
	}
	
	public void mapUserRealmMapping(UserRealmRoleMappingRequest userRealmRoleMappingRequest,
			GetRealmRoleIdResponse getRealmRoleIdResponse) {

		userRealmRoleMappingRequest.setId(getRealmRoleIdResponse.getId());
		userRealmRoleMappingRequest.setName(getRealmRoleIdResponse.getName());
		userRealmRoleMappingRequest.setDescription(getRealmRoleIdResponse.getDescription());
		userRealmRoleMappingRequest.setContainerId(getRealmRoleIdResponse.getContainerId());
		userRealmRoleMappingRequest.setClientRole(getRealmRoleIdResponse.isClientRole());
		userRealmRoleMappingRequest.setComposite(getRealmRoleIdResponse.isComposite());
	}


	/**
	 * Map key cloak user request.
	 *
	 * @param keyCloakCreateUserRequest the key cloak create user request
	 * @param createUserRequest the create user request
	 */
	public void mapKeyCloakUserRequest(KeyCloakCreateUserRequest keyCloakCreateUserRequest,
			CreateUserRequest createUserRequest) {
		keyCloakCreateUserRequest.setEmail(createUserRequest.getEmailId());
		keyCloakCreateUserRequest.setUsername(createUserRequest.getUserName());
		keyCloakCreateUserRequest.setFirstName(createUserRequest.getFirstName());
		keyCloakCreateUserRequest.setLastName(createUserRequest.getLastName());
		keyCloakCreateUserRequest.setEnabled(true);
		CredentialsCreateUserRequest credentialsCreateUserRequest = new CredentialsCreateUserRequest();
		credentialsCreateUserRequest.setType("password");
		credentialsCreateUserRequest.setTemporary(false);
		credentialsCreateUserRequest.setValue(createUserRequest.getPassword());
		keyCloakCreateUserRequest.getCredentials()[0] = credentialsCreateUserRequest;
	}
	
	/**
	 * Creates the user.
	 *
	 * @param keyCloakCreateUserRequest the key cloak create user request
	 * @param accessToken the access token
	 * @return the creates the user response
	 */
	public ResponseEntity<String> createUser(KeyCloakCreateUserRequest keyCloakCreateUserRequest, String accessToken) {

		String userAPIUrl = env.getProperty("keycloak.createUser");

		logger.info("userAPIUrl>>>" + userAPIUrl);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		setHeaderInterceptor(headers, accessToken);

		HttpEntity<KeyCloakCreateUserRequest> entity = new HttpEntity<KeyCloakCreateUserRequest>(
				keyCloakCreateUserRequest, headers);
		try 
		{
			return restTemplate.exchange(userAPIUrl, HttpMethod.POST, entity, String.class);
		}
		catch(HttpClientErrorException e)
		{
			if(HttpStatus.CONFLICT == e.getStatusCode())
				throw new UsernameAlreadyExistingException(MessageConstants.USERNAME_ALREADY_FOUND);
			else
				throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}
		catch (Exception e) {
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}
	}
	
	/**
	 * Gets the realm role id from role name.
	 *
	 * @param roleName the role name
	 * @param accessToken the access token
	 * @return the realm role id from role name
	 */
	public GetRealmRoleIdResponse getRealmRoleIdFromRoleName(String roleName, String accessToken) {

		String userAPIUrl = env.getProperty("keycloak.getRoleId") + roleName;

		logger.info("userAPIUrl of getRealmIdFromRealmName: " + userAPIUrl);
		
		HttpHeaders headers = new HttpHeaders();

        setHeaderInterceptor(headers, accessToken);
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        GetRealmRoleIdResponse getRealmRoleIdResponse = null;
        try
        {
        	getRealmRoleIdResponse = restTemplate.exchange(
					userAPIUrl, HttpMethod.GET, entity, GetRealmRoleIdResponse.class).getBody();
			logger.info("objGetRealmRoleIdResponse: " + getRealmRoleIdResponse);
        }
        catch (Exception e) 
		{
        	throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}
		return getRealmRoleIdResponse;
	}
	
	/**
	 * Map roles.
	 *
	 * @param objUserRealmRoleMappingRequest the obj user realm role mapping request
	 * @param userId the user id
	 * @param accessToken the access token
	 * @return the user realm role mapping response
	 */
	public ResponseEntity<String> mapRoles(UserRealmRoleMappingRequest objUserRealmRoleMappingRequest,
			String userId, String accessToken) {

		String userAPIUrl = env.getProperty("keycloak.createUser") + userId + "/role-mappings/realm";

		List<UserRealmRoleMappingRequest> userRealmRoleMappingRequests = new ArrayList<UserRealmRoleMappingRequest>();
		userRealmRoleMappingRequests.add(objUserRealmRoleMappingRequest);

		logger.info("userAPIUrl>>>" + userAPIUrl);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		setHeaderInterceptor(headers, accessToken);

		HttpEntity<List<UserRealmRoleMappingRequest>> entity = new HttpEntity<List<UserRealmRoleMappingRequest>>(
				userRealmRoleMappingRequests, headers);
		try 
		{
			return restTemplate.exchange(userAPIUrl, HttpMethod.POST, entity, String.class);
		} 
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}
	}
}
