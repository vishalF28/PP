/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.keycloakservice.constants;

public class MessageConstants {

	public static final String INVALID_CREDENTIALS = "Invalid Credentials";

	public static final String INTERNAL_SERVER_ERORR = "Some error occured. Please contact system administrator.";

	public static final String USERNAME_ALREADY_FOUND = "Email ID exists. Please register using a different Email ID or login";
	

}
