/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.keycloakservice.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class UserRealmRoleMappingRequest.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class UserRealmRoleMappingRequest {

	private String id;
	
	private String name;
	
	private String description;
	
	private boolean composite;
	
	private boolean clientRole;
	
	private String containerId;
}
