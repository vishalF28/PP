/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.keycloakservice.exception;

public class UsernameAlreadyExistingException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UsernameAlreadyExistingException() {
		super();
	}

	public UsernameAlreadyExistingException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public UsernameAlreadyExistingException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public UsernameAlreadyExistingException(String arg0) {
		super(arg0);
	}

	public UsernameAlreadyExistingException(Throwable arg0) {
		super(arg0);
	}
}
