package com.pms.schedulingservice.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.schedulingservice.constants.MessageConstants;
import com.pms.schedulingservice.entity.DrugData;
import com.pms.schedulingservice.repository.DrugDataRepository;

// TODO: Auto-generated Javadoc
/**
 * The Class DrugDataServiceImpl.
 */
@Service
public class DrugDataServiceImpl implements DrugDataService {

	/** The drug data repository. */
	@Autowired
	DrugDataRepository drugDataRepository;

	/**
	 * Gets the all drug data.
	 *
	 * @return the all drug data
	 */
	@Override
	public List<DrugData> getAllDrugData() {
		// TODO Auto-generated method stub
		return drugDataRepository.findAll();
	}

	/**
	 * Gets the drug data by id.
	 *
	 * @param drugDataId the drug data id
	 * @return the drug data by id
	 */
	@Override
	public Optional<DrugData> getDrugDataById(Long drugDataId) {
		// TODO Auto-generated method stub
		return drugDataRepository.findById(drugDataId);
	}

	/**
	 * Gets the drug data by name.
	 *
	 * @param drugDataName the drug data name
	 * @return the drug data by name
	 */
	@Override
	public Optional<DrugData> getDrugDataByName(String drugDataName) {
		// TODO Auto-generated method stub
		return drugDataRepository.findByDrugName(drugDataName);
	}

	/**
	 * Save drug data.
	 *
	 * @param drugData the drug data
	 * @return the drug data
	 */
	@Override
	public DrugData saveDrugData(DrugData drugData) {

		return drugDataRepository.save(drugData);

	}

	/**
	 * Delete drug data.
	 *
	 * @param drugData the drug data
	 */
	@Override
	public String deleteDrugData(DrugData drugData) {
		drugDataRepository.delete(drugData);
		return MessageConstants.DRUG_DELETED_SUCCESS;
	}

	/**
	 * Update drug data.
	 *
	 * @param drugData the drug data
	 * @return the drug data
	 */
	@Override
	public DrugData updateDrugData(DrugData drugData) {
		return drugDataRepository.save(drugData);

	}

	@Override
	public List<DrugData> getNewlyAddedDrugs() {
		return drugDataRepository.findAll().stream().filter(drugData->drugData.getIsNewlyAdded()).collect(Collectors.toList());
	}

}
