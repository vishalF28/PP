package com.pms.schedulingservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pms.schedulingservice.entity.VitalSigns;

@Repository
public interface VitalSignsRespository extends JpaRepository<VitalSigns, Long>{

}
