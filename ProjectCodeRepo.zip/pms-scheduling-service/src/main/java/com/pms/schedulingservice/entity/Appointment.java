package com.pms.schedulingservice.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.pms.schedulingservice.enums.TimingSlots;

import lombok.Data;

@Data
@Entity
@Table(name = "appointment_details", schema="pms_hospital")
@JsonIdentityInfo(generator=ObjectIdGenerators.PropertyGenerator.class, property="appointmentId")
public class Appointment {
	
	@Id
	@Column(name = "appointment_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "appointment_details_seq_generator")
	@SequenceGenerator(name="appointment_details_seq_generator", sequenceName = "pms_hospital.appointment_details_seq", allocationSize=1)
	private Long appointmentId;
	
	@Column(name = "title")
	private String title; 
	
	@Column(name = "description")
	private String description; 
	
	@Column(name = "physician_id")
	private Long physicianId;
	
	@Column(name = "physician_email_id")
	private String physicianEmailId; 
	
	@Column(name = "patient_id")
	private Long patientId;
	
	@Column(name = "patient_email_id")
	private String patientEmailId;
    
	@Column(name = "date_of_appointment")
	private Date dateOfAppointment; 
    
	@Column(name="time_of_appointment")
	@Enumerated(EnumType.STRING)
	private TimingSlots timeOfAppointment;
	
	@Column(name="is_visited")
	private Boolean isVisited = false;
	
	@Column(name="is_rescheduled")
	private Boolean isRescheduled = false;
	
	@Column(name="is_deleted")
	private Boolean isDeleted = false;
	
	@Column(name="patient_name")
	private String patientName;
	
	@Column(name="physician_name")
	private String physicianName;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@JoinTable(name = "patient_diagnosis", joinColumns = @JoinColumn(name = "appointment_id"), inverseJoinColumns = @JoinColumn(name = "diagnosis_id"), schema = "pms_patient")
	private Set<Diagnosis> diagnosis;

	@Fetch(value = FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "appointment_id")
    private Set<PatientDrugMapping> patientDrugData;

	@ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@JoinTable(name = "patient_procedure", joinColumns = @JoinColumn(name = "appointment_id"), inverseJoinColumns = @JoinColumn(name = "procedure_id"), schema = "pms_patient")
	private Set<Procedure> procedure;
	
	@OneToOne(mappedBy = "appointmentId",cascade = {CascadeType.MERGE, CascadeType.PERSIST} )
	private VitalSigns vitalSigns;
	
	@Column(name = "ready_for_scheduling")
	private Boolean readyForScheduling;
	
	@Column(name = "data_collection_booked")
	private Boolean dataCollectionAppointmentBooked;
	
}
