package com.pms.schedulingservice.feignclient;

import java.util.List;
import java.util.Set;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pms.schedulingservice.model.Patient;


@FeignClient(name = "patient-service", url = "http://localhost:9094",fallback = PatientFeignClientFallBack.class)
public interface PatientFeignClient {

	@GetMapping("patient/get-patients-profiles-by-id")
	public ResponseEntity<List<Patient>> getPatientProfileForPhysicianDashboard(@RequestParam Set<Long> patientIdSet);
}
