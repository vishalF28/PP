package com.pms.schedulingservice.model;

import com.pms.schedulingservice.enums.Gender;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Patient {

	private Long patientId;
 
	private Long userId;
	
	private Gender gender;

}
