package com.pms.schedulingservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@ToString
@Getter(value = AccessLevel.PUBLIC)
@Setter(value = AccessLevel.PUBLIC)
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "pms_diagnosis", schema = "pms_master")
public class Diagnosis extends Auditable<String> {

	@Id
	@Column(name = "diagnosis_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_diagnosis_seq_generator")
	@SequenceGenerator(name="pms_diagnosis_seq_generator", sequenceName = "pms_master.pms_diagnosis_seq", allocationSize=1)
	private Long diagnosisId;

	@Column(name = "diagnosis_code")
	private String diagnosisCode;

	@Column(name = "is_deprecated")
	private boolean isDeprecated=false;

	@Column(name = "diagnosis_description")
	private String diagnosisDescription;
	
	@Column(name="is_newly_added")
	private Boolean isNewlyAdded=false;

}
