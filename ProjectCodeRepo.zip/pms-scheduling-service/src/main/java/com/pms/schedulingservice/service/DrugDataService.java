package com.pms.schedulingservice.service;

import java.util.List;
import java.util.Optional;

import com.pms.schedulingservice.entity.DrugData;


// TODO: Auto-generated Javadoc
/**
 * The Interface DrugDataService.
 */
public interface DrugDataService {
	
	/**
	 * Gets the all drug data.
	 *
	 * @return the all drug data
	 */
	List<DrugData> getAllDrugData();
    
    /**
     * Gets the drug data by id.
     *
     * @param drugDataId the drug data id
     * @return the drug data by id
     */
    Optional<DrugData> getDrugDataById(Long drugDataId);
	
	/**
	 * Gets the drug data by name.
	 *
	 * @param drugName the drug name
	 * @return the drug data by name
	 */
	Optional<DrugData> getDrugDataByName(String drugName);
	
	/**
	 * Save drug data.
	 *
	 * @param drugData the drug data
	 * @return the drug data
	 */
	DrugData saveDrugData(DrugData drugData);
	
	/**
	 * Delete drug data.
	 *
	 * @param drugData the drug data
	 */
	String deleteDrugData(DrugData drugData);
	
	/**
	 * Update drug data.
	 *
	 * @param drugData the drug data
	 * @return the drug data
	 */
	DrugData updateDrugData(DrugData drugData);

	List<DrugData> getNewlyAddedDrugs();

}
