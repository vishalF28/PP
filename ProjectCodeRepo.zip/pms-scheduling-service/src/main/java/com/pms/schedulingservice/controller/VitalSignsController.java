package com.pms.schedulingservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pms.schedulingservice.model.GenericSuccessResponse;
import com.pms.schedulingservice.model.VitalSignsModel;
import com.pms.schedulingservice.service.VitalSignsService;

@RestController
@RequestMapping("/vital-signs")
public class VitalSignsController {

	private VitalSignsService vitalSignsService;
	
	public VitalSignsController() {
		
	}
	
	@Autowired
	public VitalSignsController(VitalSignsService vitalSignsService) {
		this.vitalSignsService = vitalSignsService;
	}
	
	@PostMapping("/save")
	public ResponseEntity<GenericSuccessResponse> addVitalSignsToPatientVisit(@RequestBody VitalSignsModel patientVitalSign) {
		String message = vitalSignsService.saveVitalSignsForPatientVisit(patientVitalSign);
		GenericSuccessResponse response = new GenericSuccessResponse(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
}
