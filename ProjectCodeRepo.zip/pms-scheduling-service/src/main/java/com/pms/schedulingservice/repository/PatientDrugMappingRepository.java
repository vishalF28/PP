package com.pms.schedulingservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.pms.schedulingservice.entity.PatientDrugMapping;

public interface PatientDrugMappingRepository extends JpaRepository<PatientDrugMapping, Long> {

	@Modifying(clearAutomatically=true, flushAutomatically=true)
	@Query(value = "DELETE FROM pms_patient.patient_drug_data WHERE appointment_id =?1 AND drug_id = ?2", nativeQuery = true)
	void deleteByAppointmentIdAndDrugId(Long appointmentId, Long drugId);

}
