
package com.pms.schedulingservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@NoArgsConstructor
@Getter(value = AccessLevel.PUBLIC)
@Setter(value = AccessLevel.PUBLIC)
@AllArgsConstructor
@Entity
@ToString
@Table(name = "pms_drug_data", schema = "pms_master")
public class DrugData extends Auditable<String>{

	@Id
	@Column(name = "drug_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_drug_data_generator")
	@SequenceGenerator(name="pms_drug_data_generator", sequenceName = "pms_master.pms_drug_data_seq", allocationSize=1)
	private Long drugId;

	@Column(name = "drug_name")
	private String drugName;
	
	@Column(name = "drug_generic_name")
	private String drugGenericName;
	
	@Column(name = "drug_manufacturer_name")
	private String drugManufacturerName;
	
	@Column(name = "drug_form")
	private String drugForm;
	
	@Column(name = "drug_strength")
	private String drugStrength;	

    @Column(name = "drug_description")
	private String  drugDescription;
	
	@Column(name="is_newly_added")
	private Boolean isNewlyAdded;

}
