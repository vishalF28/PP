package com.pms.schedulingservice.controller;

import java.io.ByteArrayInputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pms.schedulingservice.entity.Appointment;
import com.pms.schedulingservice.entity.Diagnosis;
import com.pms.schedulingservice.entity.PatientDrugMapping;
import com.pms.schedulingservice.entity.Procedure;
import com.pms.schedulingservice.enums.TimingSlots;
import com.pms.schedulingservice.model.PhysicianDashboardGraph;
import com.pms.schedulingservice.model.RescheduleAppointment;
import com.pms.schedulingservice.service.AppointmentService;

@RestController
@RequestMapping("/appointment")
public class AppointmentController {

	private AppointmentService appointmentService;

	public AppointmentController() {
	}

	@Autowired
	public AppointmentController(AppointmentService appointmentService) {
		this.appointmentService = appointmentService;
	}

	@GetMapping("/{physicianEmailId}/{appointmentDate}")
	public List<TimingSlots> getAvailableSlotsForPhysicianByDate(@PathVariable String physicianEmailId,@PathVariable Date appointmentDate) {
		List<TimingSlots> timingSlots = appointmentService.getAvailableSlotsForPhysicianByDate(physicianEmailId, appointmentDate);
		return timingSlots;
	}

	@PostMapping("/add-new-appointment")
	public ResponseEntity<Appointment> addNewAppointment(@RequestBody Appointment appointment) {
		Appointment savedAppointment = appointmentService.addNewAppointment(appointment);
		return new ResponseEntity<Appointment>(savedAppointment, HttpStatus.OK);
	}

	@GetMapping("/get-upcoming-patient-appointments/{patientEmailId}")
	public ResponseEntity<List<Appointment>> getUpcomingPatientAppointments(@PathVariable String patientEmailId) {
		List<Appointment> upcomingAppointments = appointmentService.getUpcomingPatientAppointments(patientEmailId);
		return new ResponseEntity<List<Appointment>>(upcomingAppointments, HttpStatus.OK);
	}

	@GetMapping("/get-patient-appointments-history/{patientEmailId}")
	public ResponseEntity<List<Appointment>> getPatientAppointmentsHistory(@PathVariable String patientEmailId) {
		List<Appointment> appointmentsHistory = appointmentService.getPatientAppointmentsHistory(patientEmailId);
		return new ResponseEntity<List<Appointment>>(appointmentsHistory, HttpStatus.OK);
	}


	@GetMapping("/get-upcoming-appointments/{physicianEmailId}")
	public ResponseEntity<List<Appointment>> getUpcomingAppointmentsForPhysician(@PathVariable String physicianEmailId) {
		List<Appointment> upcomingAppointments = appointmentService.getUpcomingPhysicianAppointments(physicianEmailId);
		return new ResponseEntity<List<Appointment>>(upcomingAppointments, HttpStatus.OK);
	}

	@GetMapping("/get-appointments-for-calender/{physicianEmailId}")
	public ResponseEntity<List<Appointment>> getAppointmentsForPhysicianCalender(@PathVariable String physicianEmailId) {
		List<Appointment> upcomingAppointments = appointmentService.getAppointmentsForPhysicianCalender(physicianEmailId);
		return new ResponseEntity<List<Appointment>>(upcomingAppointments, HttpStatus.OK);
	}

	@GetMapping("/get-upcoming-appointments")
	public ResponseEntity<List<Appointment>> getUpcomingAppointments() {
		List<Appointment> upcomingAppointments = appointmentService.getUpcomingAppointments();
		return new ResponseEntity<List<Appointment>>(upcomingAppointments, HttpStatus.OK);
	}


	@GetMapping("physician/get-appointment-details/{appointmentId}")
	public ResponseEntity<Appointment> getAppointmentDetails(@PathVariable Long appointmentId) {

		return new ResponseEntity<Appointment>(appointmentService. getAppointmentDetails(appointmentId), HttpStatus.OK);
	}

	@PutMapping("physician/save-appointment-details/{appointmentId}")
	public ResponseEntity<Appointment> updateAppointmentDetails(@RequestBody Object vitalSigns,@PathVariable Long appointmentId ) {
		System.out.println(vitalSigns);
		return new ResponseEntity<Appointment>(appointmentService.updateAppointmentDetails(vitalSigns, appointmentId), HttpStatus.OK);
	}
	@PutMapping("physician/add-patient-diagnosis/{appointmentId}")
	public ResponseEntity<Object> addPatientDiagnosis(@RequestBody Diagnosis diagnosis, @PathVariable Long appointmentId) {

		if(appointmentService.addPatientDiagnosis(diagnosis,appointmentId))
			return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
		else 
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@PutMapping("physician/add-patient-procedure/{appointmentId}")
	public ResponseEntity<Object> addPatientProcedure(@RequestBody Procedure procedure, @PathVariable Long appointmentId) {

		if(appointmentService.addPatientProcedure(procedure,appointmentId))
			return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
		else 
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@PutMapping("physician/add-patient-drug/{appointmentId}")
	public ResponseEntity<Object> addPatientDrug(@RequestBody PatientDrugMapping drugData, @PathVariable Long appointmentId) {

		if(appointmentService.addPatientDrug(drugData,appointmentId))
			return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);
		else 
			return new ResponseEntity<Object>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@DeleteMapping("physician/delete-patient-diagnosis/{appointmentId}/{diagnosisId}")
	public ResponseEntity<Object> deletePatientDiagnosis( @PathVariable Long appointmentId, @PathVariable Long diagnosisId) {

		appointmentService.deletePatientDiagnosis(diagnosisId,appointmentId);
		return new ResponseEntity<Object>(HttpStatus.OK);

	}
	@DeleteMapping("physician/delete-patient-procedure/{appointmentId}/{procedureId}")
	public ResponseEntity<Object> deletePatientProcedure( @PathVariable Long appointmentId,@PathVariable Long procedureId) {

		appointmentService.deletePatientProcedure(procedureId,appointmentId);
		return new ResponseEntity<Object>(HttpStatus.NO_CONTENT);

	}

	@DeleteMapping("physician/delete-patient-drug/{patientDrugMappingId}")
	public ResponseEntity<PatientDrugMapping> deletePatientDrug(@PathVariable Long patientDrugMappingId) {
		appointmentService.deletePatientDrug(patientDrugMappingId);
		return new ResponseEntity<PatientDrugMapping>(HttpStatus.NO_CONTENT);
	}

	@GetMapping("/get-upcoming-physician-appointments/{physicianEmailId}")
	public ResponseEntity<List<Appointment>> getUpcomingPhysicianAppointments(@PathVariable String physicianEmailId) {
		List<Appointment> upcomingAppointments = appointmentService.getUpcomingPatientAppointmentsForPhysician(physicianEmailId);
		return new ResponseEntity<List<Appointment>>(upcomingAppointments, HttpStatus.OK);
	}

	@PutMapping("/delete-appointment/{appointmentId}")
	public ResponseEntity<Appointment> deleteAppointment(@PathVariable Long appointmentId) {
		return new ResponseEntity<Appointment>(appointmentService.deleteAppointment(appointmentId), HttpStatus.OK);
	}


	@GetMapping("/get-appointment/{appointmentId}")
	public ResponseEntity<Appointment> getAppointment(@PathVariable Long appointmentId) {
		Appointment appointment = appointmentService.getAppointment(appointmentId);
		return new ResponseEntity<Appointment>(appointment, HttpStatus.OK);
	}

	@PostMapping("/reschedule-appointment")
	public ResponseEntity<Appointment> rescheduleAppointment(@RequestBody RescheduleAppointment rescheduleAppointment) {
		Appointment savedAppointment = appointmentService.rescheduleAppointment(rescheduleAppointment);
		return new ResponseEntity<Appointment>(savedAppointment, HttpStatus.OK);
	}

	@DeleteMapping("physician/delete-patient-drug/{appointmentId}/drug/{drugId}")
	public ResponseEntity<PatientDrugMapping> deletePatientDrugByDrugId(@PathVariable Long appointmentId, @PathVariable Long drugId) {
		appointmentService.deletePatientDrugById(appointmentId, drugId);
		return new ResponseEntity<PatientDrugMapping>(HttpStatus.NO_CONTENT);
	}

	@GetMapping("/get-todays-appointment-count")
	public ResponseEntity<Long> getTodaysAppointmentCount() {
		return new ResponseEntity<Long>(appointmentService.getTodaysAppointmentCount(), HttpStatus.OK);
	}

	@GetMapping("/get-todays-appointment-count-for-physician/{phyisicanEmailId}")
	public ResponseEntity<Long> getTodaysAppointmentCountByPhysician(@PathVariable String phyisicanEmailId) {
		return new ResponseEntity<Long>(appointmentService.getTodaysAppointmentCountByPhysician(phyisicanEmailId), HttpStatus.OK);
	}

	@GetMapping("/get-appointments-to-capture-vital-signs")
	public ResponseEntity<List<Appointment>> getAppointmentsToCaptureVitalSigns() {
		List<Appointment> upcomingAppointments = appointmentService.getAppointmentsToCaptureVitalSigns();
		return new ResponseEntity<List<Appointment>>(upcomingAppointments, HttpStatus.OK);
	}

	@GetMapping("/get-weekly-appointment/{phyisicanEmailId}")
	public ResponseEntity<List<PhysicianDashboardGraph>> getWeeklyAppointmentCount(@PathVariable String phyisicanEmailId) {
		List<PhysicianDashboardGraph> graphData = appointmentService.getWeeklyAppointmentCount(phyisicanEmailId);
		return new ResponseEntity<List<PhysicianDashboardGraph>>(graphData, HttpStatus.OK);
	}
	
	@GetMapping("/get-patient-treated-by-gender-wise/{phyisicanEmailId}")
	public ResponseEntity<List<PhysicianDashboardGraph>> getPatientTreatedByGenderWise(@PathVariable String phyisicanEmailId) {
		List<PhysicianDashboardGraph> graphData = appointmentService.getPatientTreatedByGenderWise(phyisicanEmailId);
		return new ResponseEntity<List<PhysicianDashboardGraph>>(graphData, HttpStatus.OK);
	}
	
	@GetMapping("/get-patient-visited-ratio-for-nurse")
	public ResponseEntity<Map<String, Long>> getPatientVisitedRatioForNurse() {
		return new ResponseEntity<Map<String,Long>>(appointmentService.getPatientVisitedRatioForNurse(), HttpStatus.OK);
	}
		

	@RequestMapping(value = "/get-appointment-report/{appointmentId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> getAppointmentReportById(@PathVariable(value="appointmentId") Long appointmentId) {
		ByteArrayInputStream bis = appointmentService.getAppintmentReportById(appointmentId);	
		HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=AppointmentReport.pdf");
        
		return ResponseEntity
                .ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(bis));
	}

}
