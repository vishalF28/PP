package com.pms.schedulingservice.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="vital_signs", schema = "pms_hospital")
public class VitalSigns {
	
	@Id
	@Column(name="vital_sign_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "vital_signs_generator")
	@SequenceGenerator(name="vital_signs_generator", sequenceName = "pms_hospital.vital_signs_seq", allocationSize=1)
	private Long vitalSignId;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="appointment_id")
	private Appointment appointmentId;
	
	@Column(name="height")
	private Long height;
	
	@Column(name="weight")
    private Long weight;
    
	@Column(name="blood_pressure")
    private String bloodPressure;
    
	@Column(name="temperature")
    private Float temperature;
    
	@Column(name="respiration_rate")
    private Long respirationRate;
    
	@Column(name="captured_by_nurse_email_id")
    private String capturedByNurseEmailId;
    
	@Column(name="captured_by_nurse_name")
    private String capturedByNurseName;
    
	@Column(name="is_vital_signs_captured")
    private Boolean isVitalSignsCaptured;

}
