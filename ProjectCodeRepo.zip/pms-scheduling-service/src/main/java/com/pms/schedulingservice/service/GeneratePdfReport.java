package com.pms.schedulingservice.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.pms.schedulingservice.entity.Appointment;
import com.pms.schedulingservice.entity.Diagnosis;
import com.pms.schedulingservice.entity.PatientDrugMapping;
import com.pms.schedulingservice.entity.Procedure;

public class GeneratePdfReport {

    public static ByteArrayInputStream appointmentReport(Appointment appointment) {

        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {

            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);
            table.setWidths(new int[]{6, 6, 6, 6, 6, 6});

            Font headFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD);

            PdfPCell hcell;
            hcell = new PdfPCell(new Phrase("Appointment Id", headFont));
            hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(hcell);

            hcell = new PdfPCell(new Phrase("Title", headFont));
            hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(hcell);

            hcell = new PdfPCell(new Phrase("Description", headFont));
            hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(hcell);
            
            hcell = new PdfPCell(new Phrase("Physician Name", headFont));
            hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(hcell);
            
            hcell = new PdfPCell(new Phrase("Patient Name", headFont));
            hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(hcell);
            
            hcell = new PdfPCell(new Phrase("Date of Appointment", headFont));
            hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(hcell);

            PdfPCell cell;

            cell = new PdfPCell(new Phrase(appointment.getAppointmentId().toString()));
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase(appointment.getTitle()));
            cell.setPaddingLeft(5);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);

            cell = new PdfPCell(new Phrase(appointment.getDescription()));
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPaddingRight(5);
            table.addCell(cell);
            
            cell = new PdfPCell(new Phrase(appointment.getPhysicianName()));
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPaddingRight(5);
            table.addCell(cell);
            
            cell = new PdfPCell(new Phrase(appointment.getPatientName()));
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPaddingRight(5);
            table.addCell(cell);
            
            SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
            String dateOfAppointment = format.format(appointment.getDateOfAppointment());
            cell = new PdfPCell(new Phrase(dateOfAppointment));
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPaddingRight(5);
            table.addCell(cell);

            //	Start: Diagnosis
            PdfPTable tableDiagnosis = new PdfPTable(2);
            tableDiagnosis.setWidthPercentage(100);
            tableDiagnosis.setWidths(new int[]{1, 1});

            PdfPCell hcellDiagnosis;

            hcellDiagnosis = new PdfPCell(new Phrase("Diagnosis Code", headFont));
            hcellDiagnosis.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableDiagnosis.addCell(hcellDiagnosis);

            hcellDiagnosis = new PdfPCell(new Phrase("Diagnosis Description", headFont));
            hcellDiagnosis.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableDiagnosis.addCell(hcellDiagnosis);

            for (Diagnosis diagnosis : appointment.getDiagnosis()) {

                PdfPCell cellDiagnosis;

                cellDiagnosis = new PdfPCell(new Phrase(diagnosis.getDiagnosisCode().toString()));
                cellDiagnosis.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cellDiagnosis.setHorizontalAlignment(Element.ALIGN_CENTER);
                tableDiagnosis.addCell(cellDiagnosis);

                cellDiagnosis = new PdfPCell(new Phrase(diagnosis.getDiagnosisDescription()));
                cellDiagnosis.setPaddingLeft(5);
                cellDiagnosis.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cellDiagnosis.setHorizontalAlignment(Element.ALIGN_CENTER);
                tableDiagnosis.addCell(cellDiagnosis);
            }
            
            //	End: Diagnosis
            
            //	Start: Procedure
            PdfPTable tableProcedure = new PdfPTable(2);
            tableProcedure.setWidthPercentage(100);
            tableProcedure.setWidths(new int[]{1, 1});

            PdfPCell hcellProcedure;

            hcellProcedure = new PdfPCell(new Phrase("Procedure Code", headFont));
            hcellProcedure.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableProcedure.addCell(hcellProcedure);

            hcellProcedure = new PdfPCell(new Phrase("Procedure Description", headFont));
            hcellProcedure.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableProcedure.addCell(hcellProcedure);

            for (Procedure procedure : appointment.getProcedure()) {

                PdfPCell cellProcedure;

                cellProcedure = new PdfPCell(new Phrase(procedure.getProcedureCode().toString()));
                cellProcedure.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cellProcedure.setHorizontalAlignment(Element.ALIGN_CENTER);
                tableProcedure.addCell(cellProcedure);

                cellProcedure = new PdfPCell(new Phrase(procedure.getProcedureDescription()));
                cellProcedure.setPaddingLeft(5);
                cellProcedure.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cellProcedure.setHorizontalAlignment(Element.ALIGN_CENTER);
                tableProcedure.addCell(cellProcedure);
            }
            
            //	End: Procedure
            
            //	Start: VitalSigns
            PdfPTable tableVitalSigns = new PdfPTable(5);
            tableVitalSigns.setWidthPercentage(100);
            tableVitalSigns.setWidths(new int[]{5,5,5,5,5});

            PdfPCell hcelltableVitalSigns;

            hcelltableVitalSigns = new PdfPCell(new Phrase("Height(Cm)", headFont));
            hcelltableVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(hcelltableVitalSigns);

            hcelltableVitalSigns = new PdfPCell(new Phrase("Weight(Kg)", headFont));
            hcelltableVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(hcelltableVitalSigns);

            hcelltableVitalSigns = new PdfPCell(new Phrase("Blood Pressure(mm/Hg)", headFont));
            hcelltableVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(hcelltableVitalSigns);

            hcelltableVitalSigns = new PdfPCell(new Phrase("Temperature(Fahrenheit)", headFont));
            hcelltableVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(hcelltableVitalSigns);

            hcelltableVitalSigns = new PdfPCell(new Phrase("Respiration rate(BPM)", headFont));
            hcelltableVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(hcelltableVitalSigns);

            PdfPCell cellVitalSigns;

            cellVitalSigns = new PdfPCell(new Phrase(appointment.getVitalSigns().getHeight().toString()));
            cellVitalSigns.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cellVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(cellVitalSigns);

            cellVitalSigns = new PdfPCell(new Phrase(appointment.getVitalSigns().getWeight().toString()));
            cellVitalSigns.setPaddingLeft(5);
            cellVitalSigns.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cellVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(cellVitalSigns);

            cellVitalSigns = new PdfPCell(new Phrase(appointment.getVitalSigns().getBloodPressure().toString()));
            cellVitalSigns.setPaddingLeft(5);
            cellVitalSigns.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cellVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(cellVitalSigns);

            cellVitalSigns = new PdfPCell(new Phrase(appointment.getVitalSigns().getTemperature().toString()));
            cellVitalSigns.setPaddingLeft(5);
            cellVitalSigns.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cellVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(cellVitalSigns);

            cellVitalSigns = new PdfPCell(new Phrase(appointment.getVitalSigns().getRespirationRate().toString()));
            cellVitalSigns.setPaddingLeft(5);
            cellVitalSigns.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cellVitalSigns.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableVitalSigns.addCell(cellVitalSigns);
            
            //	End: VitalSigns
            
            
            //	Start: Drug Data
            PdfPTable tableDrugData = new PdfPTable(5);
            tableDrugData.setWidthPercentage(100);
            tableDrugData.setWidths(new int[]{5,5,5,5,5});

            PdfPCell hcelltableDrugData;

            hcelltableDrugData = new PdfPCell(new Phrase("Drug Name", headFont));
            hcelltableDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableDrugData.addCell(hcelltableDrugData);

            hcelltableDrugData = new PdfPCell(new Phrase("Drug Manufacturer Name", headFont));
            hcelltableDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableDrugData.addCell(hcelltableDrugData);

            hcelltableDrugData = new PdfPCell(new Phrase("Drug Form", headFont));
            hcelltableDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableDrugData.addCell(hcelltableDrugData);

            hcelltableDrugData = new PdfPCell(new Phrase("Drug Strength", headFont));
            hcelltableDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableDrugData.addCell(hcelltableDrugData);

            hcelltableDrugData = new PdfPCell(new Phrase("Drug Dosage", headFont));
            hcelltableDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
            tableDrugData.addCell(hcelltableDrugData);

            for(PatientDrugMapping drugData: appointment.getPatientDrugData())
            {
	            PdfPCell cellDrugData;
	
	            cellDrugData = new PdfPCell(new Phrase(drugData.getDrug().getDrugName().toString()));
	            cellDrugData.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            cellDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
	            tableDrugData.addCell(cellDrugData);
	
	            cellDrugData = new PdfPCell(new Phrase(drugData.getDrug().getDrugManufacturerName().toString()));
	            cellDrugData.setPaddingLeft(5);
	            cellDrugData.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            cellDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
	            tableDrugData.addCell(cellDrugData);
	
	            cellDrugData = new PdfPCell(new Phrase(drugData.getDrug().getDrugForm().toString()));
	            cellDrugData.setPaddingLeft(5);
	            cellDrugData.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            cellDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
	            tableDrugData.addCell(cellDrugData);
	
	            cellDrugData = new PdfPCell(new Phrase(drugData.getDrug().getDrugStrength().toString()));
	            cellDrugData.setPaddingLeft(5);
	            cellDrugData.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            cellDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
	            tableDrugData.addCell(cellDrugData);
	
	            cellDrugData = new PdfPCell(new Phrase(drugData.getDrugDosage().toString()));
	            cellDrugData.setPaddingLeft(5);
	            cellDrugData.setVerticalAlignment(Element.ALIGN_MIDDLE);
	            cellDrugData.setHorizontalAlignment(Element.ALIGN_CENTER);
	            tableDrugData.addCell(cellDrugData);
	
	            
	        }
            //	End: Drug Data
            PdfWriter.getInstance(document, out);
            document.open();
            document.add(table);
            
            document.add( new Paragraph( "\n \n" ) );
            document.add( new Paragraph( "Vital Signs:" ) );
            document.add( new Paragraph( "\n" ) );
            document.add(tableVitalSigns);

            
            document.add( new Paragraph( "\n \n" ) );
            document.add( new Paragraph( "Diagnosis Details:" ) );
            document.add( new Paragraph( "\n" ) );
            document.add(tableDiagnosis);

            document.add( new Paragraph( "\n \n" ) );
            document.add( new Paragraph( "Procedure Details:" ) );
            document.add( new Paragraph( "\n" ) );
            document.add(tableProcedure);


            document.add( new Paragraph( "\n \n" ) );
            document.add( new Paragraph( "Drug Details:" ) );
            document.add( new Paragraph( "\n" ) );
            document.add(tableDrugData);
            document.close();

        } catch (DocumentException ex) {

            ex.printStackTrace();
        }

        return new ByteArrayInputStream(out.toByteArray());
    }
}