package com.pms.schedulingservice.service;

import java.util.List;
import java.util.Optional;

import com.pms.schedulingservice.entity.Procedure;


// TODO: Auto-generated Javadoc
/**
 * The Interface ProcedureService.
 */
public interface ProcedureService {
	
	/**
	 * Gets the all procedure.
	 *
	 * @return the all procedure
	 */
	List<Procedure> getAllProcedure();
    
    /**
     * Gets the procedure by id.
     *
     * @param procedureId the procedure id
     * @return the procedure by id
     */
    Optional<Procedure> getProcedureById(Long procedureId);
	
	/**
	 * Gets the procedure by code.
	 *
	 * @param procedureCode the procedure code
	 * @return the procedure by code
	 */
	Optional<Procedure> getProcedureByCode(String procedureCode);
	
	/**
	 * Save procedure.
	 *
	 * @param procedure the procedure
	 * @return the procedure
	 */
	Procedure saveProcedure(Procedure procedure);
	
	/**
	 * Delete procedure.
	 *
	 * @param procedure the procedure
	 */
	String deleteProcedure(Procedure procedure);
	
	/**
	 * Update procedure.
	 *
	 * @param procedure the procedure
	 * @return the procedure
	 */
	Procedure updateProcedure(Procedure procedure);

	List<Procedure> getNewlyAddedProcedures();

}
