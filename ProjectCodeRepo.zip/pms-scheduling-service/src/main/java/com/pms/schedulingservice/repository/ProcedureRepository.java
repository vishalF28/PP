package com.pms.schedulingservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pms.schedulingservice.entity.Procedure;

// TODO: Auto-generated Javadoc
/**
 * The Interface ProcedureRepository.
 *
 * @author SatpalC
 */
@Repository
public interface ProcedureRepository extends JpaRepository<Procedure, Long> {

/**
 * Find all.
 *
 * @return the list
 */
public List<Procedure> findAll();

/**
 * Find by id.
 *
 * @param procedureId the procedure id
 * @return the optional
 */
public Optional<Procedure> findById(Long procedureId);

/**
 * Find by procedure code.
 *
 * @param diagnosisCode the diagnosis code
 * @return the optional
 */
public Optional<Procedure> findByProcedureCode(String diagnosisCode);

	
}
