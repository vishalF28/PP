package com.pms.schedulingservice.service;

import java.io.ByteArrayInputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.pms.schedulingservice.entity.Appointment;
import com.pms.schedulingservice.entity.Diagnosis;
import com.pms.schedulingservice.entity.PatientDrugMapping;
import com.pms.schedulingservice.entity.Procedure;
import com.pms.schedulingservice.enums.TimingSlots;
import com.pms.schedulingservice.model.PhysicianDashboardGraph;
import com.pms.schedulingservice.model.RescheduleAppointment;

public interface AppointmentService {

	public Appointment addNewAppointment(Appointment appointment);

	public List<TimingSlots> getAvailableSlotsForPhysicianByDate(String physicianEmailId, Date appointmentDate);

	public List<Appointment> getUpcomingPatientAppointments(String patientEmailId);

	public List<Appointment> getPatientAppointmentsHistory(String patientEmailId);
	
	public List<Appointment> getUpcomingPhysicianAppointments(String physicianEmailId);

	public Appointment getAppointmentDetails(Long appointmentId);

	public Appointment updateAppointmentDetails(Object viatlSigns, Long appointmentId);

	public List<Appointment> getUpcomingPatientAppointmentsForPhysician(String physicianEmailId);

	public Appointment getAppointment(Long appointmentId);

	public Appointment rescheduleAppointment(RescheduleAppointment rescheduleAppointment);

	public Appointment deleteAppointment(Long appointmentId);

	public boolean addPatientDiagnosis(Diagnosis diagnosis, Long appointmentId);

	public boolean addPatientProcedure(Procedure procedure, Long appointmentId);

	public boolean addPatientDrug(PatientDrugMapping drugData, Long appointmentId);

	public void deletePatientDiagnosis(Long diagnosisId, Long appointmentId);

	public void deletePatientProcedure(Long procedureId, Long appointmentId);

	public void deletePatientDrug(Long patientDrugMappingId);

	public void deletePatientDrugById(Long appointmentId, Long drugId);

	public List<Appointment> getUpcomingAppointments();

	public Long getTodaysAppointmentCount();

	public List<Appointment> getAppointmentsForPhysicianCalender(String physicianEmailId);

	public Long getTodaysAppointmentCountByPhysician(String phyisicanEmailId);

	public List<Appointment> getAppointmentsToCaptureVitalSigns();

	public List<PhysicianDashboardGraph> getWeeklyAppointmentCount(String phyisicanEmailId);

	public List<PhysicianDashboardGraph> getPatientTreatedByGenderWise(String phyisicanEmailId);

	public Map<String, Long> getPatientVisitedRatioForNurse();

	public void scheduleDataCollectionAppointment();

	public ByteArrayInputStream getAppintmentReportById(Long appointmentId);

}
