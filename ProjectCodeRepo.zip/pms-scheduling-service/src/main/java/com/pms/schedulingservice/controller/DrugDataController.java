/**
 * 
 */
package com.pms.schedulingservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.schedulingservice.entity.DrugData;
import com.pms.schedulingservice.model.GenericSuccessResponse;
import com.pms.schedulingservice.service.DrugDataService;

/**
 * The Class DrugDataController.
 *
 * @author SatpalC
 */
@RestController
@RequestMapping("/drug")
public class DrugDataController {

	/** The drug data service. */
	@Autowired
	DrugDataService drugDataService;

	/**
	 * Gets the all drug data.
	 *
	 * @return the all drug data
	 */
	@GetMapping("/getall")
	public ResponseEntity<List<DrugData>> getAllDrugData() {
		return new ResponseEntity<List<DrugData>>(drugDataService.getAllDrugData(), HttpStatus.OK);
	}

	/**
	 * Gets the drug data by id.
	 *
	 * @param DrugDataId the drug data id
	 * @return the drug data by id
	 */
	@GetMapping("getById")
	public ResponseEntity<DrugData> getDrugDataById(@RequestParam Long drugDataId) {
		return new ResponseEntity<DrugData>(drugDataService.getDrugDataById(drugDataId).get(), HttpStatus.OK);
	}

	/**
	 * Gets the drug data by code.
	 *
	 * @param DrugDataCode the drug data code
	 * @return the drug data by code
	 */
	@GetMapping("getByType")
	public ResponseEntity<DrugData> getDrugDataByCode(@RequestParam String drugDataCode) {
		return new ResponseEntity<DrugData>(drugDataService.getDrugDataByName(drugDataCode).get(), HttpStatus.OK);
	}

	/**
	 * Save drug data.
	 *
	 * @param DrugData the drug data
	 * @return the drug data
	 */
	@PostMapping("/save")
	public ResponseEntity<DrugData> saveDrugData(@RequestBody DrugData drugData) {

		return new ResponseEntity<DrugData>(drugDataService.saveDrugData(drugData), HttpStatus.OK);
	}

	/**
	 * Delete drug data.
	 *
	 * @param DrugData the drug data
	 */
	@DeleteMapping("/delete")
	public ResponseEntity<GenericSuccessResponse> deleteDrugData(@RequestBody DrugData drugData) {

		String message = drugDataService.deleteDrugData(drugData);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}

	/**
	 * Update drug data.
	 *
	 * @param DrugData the drug data
	 */
	@PutMapping("/update")
	public ResponseEntity<DrugData> updateDrugData(@RequestBody DrugData drugData) {

		return new ResponseEntity<DrugData>(drugDataService.updateDrugData(drugData), HttpStatus.OK);
	}
	
	@GetMapping("get-newly-added-drug")
	public ResponseEntity<List<DrugData>> getNewlyAddedDrugData(){
		return new ResponseEntity<List<DrugData>>(drugDataService.getNewlyAddedDrugs(),HttpStatus.OK);
	}

}
