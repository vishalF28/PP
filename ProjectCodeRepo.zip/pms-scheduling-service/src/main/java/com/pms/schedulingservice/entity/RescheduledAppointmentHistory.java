package com.pms.schedulingservice.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.pms.schedulingservice.enums.TimingSlots;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "rescheduled_appointment_history", schema = "pms_hospital")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RescheduledAppointmentHistory {

	@Id
	@Column(name = "rescheduled_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rescheduled_appointment_history_generator")
	@SequenceGenerator(name="rescheduled_appointment_history_generator", sequenceName = "pms_hospital.rescheduled_appointment_history_seq", allocationSize=1)
	private Long rescheduledId;

	@Column(name = "appointment_id")
	private Long appointmentId;
	
	@Column(name = "title")
	private String title; 
	
	@Column(name = "description")
	private String description; 
	
	@Column(name = "physician_id")
	private Long physicianId;
	
	@Column(name = "physician_email_id")
	private String physicianEmailId; 
	
	@Column(name = "patient_id")
	private Long patientId;
	
	@Column(name = "patient_email_id")
	private String patientEmailId;
    
	@Column(name = "date_of_appointment")
	private Date dateOfAppointment; 
    
	@Column(name="time_of_appointment")
	@Enumerated(EnumType.STRING)
	private TimingSlots timeOfAppointment;
	
	@Column(name="is_visited")
	private Boolean isVisited = false;
	
	@Column(name="is_rescheduled")
	private Boolean isRescheduled = false;
	
	@Column(name="is_deleted")
	private Boolean isDeleted = false;
	
	@Column(name="patient_name")
	private String patientName;
	
	@Column(name="physician_name")
	private String physicianName;
}
