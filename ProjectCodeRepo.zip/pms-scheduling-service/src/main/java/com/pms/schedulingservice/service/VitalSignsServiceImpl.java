package com.pms.schedulingservice.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.schedulingservice.constants.MessageConstants;
import com.pms.schedulingservice.entity.Appointment;
import com.pms.schedulingservice.entity.VitalSigns;
import com.pms.schedulingservice.model.VitalSignsModel;
import com.pms.schedulingservice.repository.AppointmentRespository;
import com.pms.schedulingservice.repository.VitalSignsRespository;

@Service
public class VitalSignsServiceImpl implements VitalSignsService{
	
	private VitalSignsRespository vitalSignsRespository;
	
	private AppointmentRespository appointmentRespository;
	
	public VitalSignsServiceImpl() {
		
	}
	
	@Autowired
	public VitalSignsServiceImpl(VitalSignsRespository vitalSignsRespository, AppointmentRespository appointmentRespository) {
		this.vitalSignsRespository = vitalSignsRespository;
		this.appointmentRespository = appointmentRespository;
	}

	@Override
	public String saveVitalSignsForPatientVisit(VitalSignsModel vitalSignsModel) {
		try {
			Appointment appointment =appointmentRespository.findById(vitalSignsModel.getAppointmentId()).get();
			VitalSigns vitalSigns = new VitalSigns();
			BeanUtils.copyProperties(vitalSignsModel, vitalSigns);
			vitalSigns.setAppointmentId(appointment);
			vitalSigns.setIsVitalSignsCaptured(Boolean.TRUE);
			vitalSignsRespository.save(vitalSigns);
		}
		catch(Exception e) {
			throw new RuntimeException(MessageConstants.FAILED_TO_SAVE_VITAL_SIGNS);
		}
 		return MessageConstants.SAVE_VITAL_SIGNS_SUCCESS;
	}

}
