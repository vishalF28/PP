package com.pms.schedulingservice.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.pms.schedulingservice.service.AppointmentService;

@Component
public class SchedulerConfig {

	AppointmentService appointmentService;
	
	public SchedulerConfig() {
		
	}
	
	@Autowired
	public SchedulerConfig(AppointmentService appointmentService) {
		this.appointmentService = appointmentService;
	}

	@Scheduled(cron = "0 * * * * ?")
	   public void cronJobSch() {

	      appointmentService.scheduleDataCollectionAppointment();
	}
}
