package com.pms.schedulingservice.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.pms.schedulingservice.entity.Appointment;

public interface AppointmentRespository extends JpaRepository<Appointment,Long>{

	List<Appointment> findAppointmentByPhysicianEmailIdAndDateOfAppointment(String physicianEmailId,
			Date appointmentDate);

	List<Appointment> findAppointmentByPatientEmailId(String patientEmailId);

	List<Appointment> findAppointmentByPhysicianEmailId(String physicianEmailId);

	@Modifying(clearAutomatically=true, flushAutomatically=true)
	@Query(value="DELETE FROM pms_patient.patient_diagnosis WHERE appointment_id=?1 and diagnosis_id=?2", nativeQuery=true)
	void deletePatientDiagnosis(Long appointment_id,Long diagnosis_id);
	
	@Modifying(clearAutomatically=true, flushAutomatically=true)
	@Query(value="DELETE FROM pms_patient.patient_procedure WHERE appointment_id=?1 and procedure_id=?2", nativeQuery=true)
	void deletePatientProcedure(Long appointment_id,Long procedure_id);

	@Query(value = "SELECT COUNT(appointment_id) FROM pms_hospital.appointment_details WHERE DATE_TRUNC('day', date_of_appointment)=DATE_TRUNC('day', now())", nativeQuery = true)
	Long countAppointmentByDateOfAppointment(Date date);

	@Query(value = "SELECT COUNT(appointment_id) FROM pms_hospital.appointment_details WHERE DATE_TRUNC('day', date_of_appointment)=DATE_TRUNC('day', now()) AND physician_email_id = ?", nativeQuery = true)
	Long getTodaysAppointmentCountByPhysician(String phyisicanEmailId);

	@Query(value = "SELECT COUNT(appointment_id) FROM pms_hospital.appointment_details WHERE to_char(date_of_appointment,'DD-MM-YYYY') = to_char(to_date(?2, 'DD-MM-YYYY'),'DD-MM-YYYY') AND physician_email_id = ?1", nativeQuery = true)
	Long getAppointmentCountByPhysicianAndDate(String phyisicanEmailId, String strDate);

	List<Appointment> findByDateOfAppointmentBetween(Date startDate, Date currentDate);

	@Modifying
	@Query(value = "UPDATE pms_hospital.appointment_details set ready_for_scheduling=true where date_of_appointment < now()", nativeQuery = true)
	void scheduleDataCollectionAppointment();

	Appointment findByAppointmentId(Long appointmentId);
	
}
