
package com.pms.schedulingservice.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter(value = AccessLevel.PUBLIC)
@Setter(value = AccessLevel.PUBLIC)
@NoArgsConstructor
@DynamicUpdate
@ToString
@AllArgsConstructor
@Table(name = "patient_drug_data", schema = "pms_patient")
public class PatientDrugMapping extends Auditable<String> implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "patient_drug_data_generator")
	@SequenceGenerator(name="patient_drug_data_generator", sequenceName = "pms_patient.patient_drug_data_seq", allocationSize=1)
	@Column(name="patient_drug_mapping_id")
	private Long patientDrugMappingId;

	@Column(name = "appointment_id")
	private Long appointmentId;

	@ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinColumn(name = "drug_id")
	private DrugData drug;

	@Column(name = "drug_dosage")
	private String drugDosage;

}
