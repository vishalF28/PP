package com.pms.schedulingservice.model;

import java.util.Date;

import com.pms.schedulingservice.enums.TimingSlots;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RescheduleAppointment {

	private Long appointmentId;
	
	private Date dateOfAppointment;
	
	private TimingSlots timeOfAppointment;
}
