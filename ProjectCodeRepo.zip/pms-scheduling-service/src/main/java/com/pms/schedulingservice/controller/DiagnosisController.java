package com.pms.schedulingservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.schedulingservice.entity.Diagnosis;
import com.pms.schedulingservice.model.GenericSuccessResponse;
import com.pms.schedulingservice.service.DiagnosisService;

/**
 * The Class DiagnosisServiceController.
 */
@RestController
@RequestMapping("/diagnosis")
public class DiagnosisController {

	/** The diagnosis service. */
	@Autowired
	DiagnosisService diagnosisService;

	/**
	 * Gets the all diagnosis.
	 *
	 * @return the all diagnosis
	 */
	@GetMapping("/getall")
	public ResponseEntity<List<Diagnosis>> getAllDiagnosis() {
		return new ResponseEntity<List<Diagnosis>>(diagnosisService.getAllDiagnosis(), HttpStatus.OK);
	}

	/**
	 * Gets the diagnosis by id.
	 *
	 * @param diagnosisId the diagnosis id
	 * @return the diagnosis by id
	 */
	@GetMapping("getById")
	public ResponseEntity<Diagnosis> getDiagnosisById(@RequestParam Long diagnosisId) {
		return new ResponseEntity<Diagnosis>(diagnosisService.getDiagnosisById(diagnosisId).get(), HttpStatus.OK);
		
	}

	/**
	 * Gets the diagnosis by code.
	 *
	 * @param diagnosisCode the diagnosis code
	 * @return the diagnosis by code
	 */
	@GetMapping("getByCode")
	public ResponseEntity<Diagnosis> getDiagnosisByCode(@RequestParam String diagnosisCode) {
		return new ResponseEntity<Diagnosis>(diagnosisService.getDiagnosisByCode(diagnosisCode).get(), HttpStatus.OK);
	}

	/**
	 * Save diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 * @return the diagnosis
	 */
	@PostMapping("/save")
	public ResponseEntity<Diagnosis> saveDiagnosis(@RequestBody Diagnosis diagnosis) {

		return new ResponseEntity<Diagnosis>(diagnosisService.saveDiagnosis(diagnosis), HttpStatus.OK);
	}

	/**
	 * Delete diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 */
	@DeleteMapping("/delete")
	public ResponseEntity<GenericSuccessResponse> deleteDiagnosis(@RequestBody Diagnosis diagnosis) {

		String message = diagnosisService.deleteDiagnosis(diagnosis);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}

	/**
	 * Update diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 */
	@PutMapping("/update")
	public ResponseEntity<Diagnosis> updateDiagnosis(@RequestBody Diagnosis diagnosis) {

		return new ResponseEntity<Diagnosis>(diagnosisService.updateDiagnosis(diagnosis), HttpStatus.OK);
	}
	
	
	@GetMapping("/get-newly-added-diagnosis")
	public ResponseEntity<List<Diagnosis>> getNewlyAddedDiagnosis(){
		return new ResponseEntity<List<Diagnosis>>(diagnosisService.getNewlyAddedAllergies(),HttpStatus.OK);
	}

}
