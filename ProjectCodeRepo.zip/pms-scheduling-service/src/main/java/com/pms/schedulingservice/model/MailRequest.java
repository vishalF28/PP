package com.pms.schedulingservice.model;

import java.util.Date;

import com.pms.schedulingservice.enums.TimingSlots;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MailRequest {


	private String emailId;

	private String defaultPassword;

	private Long appointmentId;
	
	private Date dateOfAppointment;
	
	private TimingSlots timeOfAppointment;
	
	private String physicianName;
	
	private String patientName;
	
	private String physicianEmailId; 
	
	private String patientEmailId;
}
