package com.pms.schedulingservice.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.schedulingservice.constants.MessageConstants;
import com.pms.schedulingservice.entity.Procedure;
import com.pms.schedulingservice.repository.ProcedureRepository;

/**
 * @author SatpalC
*
 * The Class ProcedureServiceImpl.
 */
@Service
public class ProcedureServiceImpl implements ProcedureService {

	/** The procedure repository. */
	@Autowired
	ProcedureRepository procedureRepository;

	/**
	 * Gets the all procedure.
	 *
	 * @return the all procedure
	 */
	@Override
	public List<Procedure> getAllProcedure() {
		// TODO Auto-generated method stub
		return procedureRepository.findAll();
	}

	/**
	 * Gets the procedure by id.
	 *
	 * @param procedureId the procedure id
	 * @return the procedure by id
	 */
	@Override
	public Optional<Procedure> getProcedureById(Long procedureId) {
		// TODO Auto-generated method stub
		return procedureRepository.findById(procedureId);
	}

	/**
	 * Gets the procedure by code.
	 *
	 * @param procedureCode the procedure code
	 * @return the procedure by code
	 */
	@Override
	public Optional<Procedure> getProcedureByCode(String procedureCode) {
		// TODO Auto-generated method stub
		return procedureRepository.findByProcedureCode(procedureCode);
	}

	/**
	 * Save procedure.
	 *
	 * @param procedure the procedure
	 * @return the procedure
	 */
	@Override
	public Procedure saveProcedure(Procedure procedure) {

		return procedureRepository.save(procedure);

	}

	/**
	 * Delete procedure.
	 *
	 * @param procedure the procedure
	 */
	@Override
	public String deleteProcedure(Procedure procedure) {
		procedureRepository.delete(procedure);
		return MessageConstants.PROCEDURE_DELETED_SUCCESS;
	}

	/**
	 * Update procedure.
	 *
	 * @param procedure the procedure
	 * @return the procedure
	 */
	@Override
	public Procedure updateProcedure(Procedure procedure) {
		return procedureRepository.save(procedure);

	}

	@Override
	public List<Procedure> getNewlyAddedProcedures() {
		return procedureRepository.findAll().stream().filter(procedure->procedure.getIsNewlyAdded()).collect(Collectors.toList());
	}

}
