package com.pms.schedulingservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pms.schedulingservice.entity.DrugData;

// TODO: Auto-generated Javadoc
/**
 * The Interface DrugDataRepository.
 *
 * @author SatpalC
 */
@Repository
public interface DrugDataRepository extends JpaRepository<DrugData, Long> {

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<DrugData> findAll();

	/**
	 * Find by id.
	 *
	 * @param drugDataId the drug data id
	 * @return the optional
	 */
	public Optional<DrugData> findById(Long drugDataId);

	/**
	 * Find by drug name.
	 *
	 * @param drugName the drug name
	 * @return the optional
	 */
	public Optional<DrugData> findByDrugName(String drugName);
	

}
