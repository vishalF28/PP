/**
 * 
 */
package com.pms.schedulingservice.service;

import java.util.List;
import java.util.Optional;

import com.pms.schedulingservice.entity.Diagnosis;


// TODO: Auto-generated Javadoc
/**
 * The Interface DiagnosisService.
 *
 * @author SatpalC
 */
public interface DiagnosisService {

	/**
	 * Gets the all diagnosis.
	 *
	 * @return the all diagnosis
	 */
	List<Diagnosis> getAllDiagnosis();
    
    /**
     * Gets the diagnosis by id.
     *
     * @param diagnosisId the diagnosis id
     * @return the diagnosis by id
     */
    Optional<Diagnosis> getDiagnosisById(Long diagnosisId);
	
	/**
	 * Gets the diagnosis by code.
	 *
	 * @param diagnosisCode the diagnosis code
	 * @return the diagnosis by code
	 */
	Optional<Diagnosis> getDiagnosisByCode(String diagnosisCode);
	
	/**
	 * Save diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 * @return the diagnosis
	 */
	Diagnosis saveDiagnosis(Diagnosis diagnosis);
	
	/**
	 * Delete diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 */
	String deleteDiagnosis(Diagnosis diagnosis);
	
	/**
	 * Update diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 * @return the diagnosis
	 */
	Diagnosis updateDiagnosis(Diagnosis diagnosis);

	List<Diagnosis> getNewlyAddedAllergies();

	
	
}
