/**
 * 
 */
package com.pms.schedulingservice.config;
import java.util.Optional;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

// TODO: Auto-generated Javadoc
/**
 * The Class JpaAuditingConfiguration.
 */
@Configuration
@EnableJpaAuditing(auditorAwareRef = "auditorProvider")
public class JpaAuditingConfiguration {
	/** The logger. */
	//private static Logger logger = LogManager.getLogger(JpaAuditingConfiguration.class);
    
    /**
     * Auditor provider.
     *
     * @return the auditor aware
     */
    @Bean
    public AuditorAware<String> auditorProvider() {

    	 /*
        if you are using spring security, you can get the currently logged username with following code segment.
       
        SecurityContextHolder.getContext().getAuthentication().getName()
       
       */

    
    return ()-> Optional.ofNullable("satpal");
    }
}