package com.pms.schedulingservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pms.schedulingservice.entity.RescheduledAppointmentHistory;

@Repository
public interface RescheduledAppoinmentRepository extends JpaRepository<RescheduledAppointmentHistory, Long>{

}
