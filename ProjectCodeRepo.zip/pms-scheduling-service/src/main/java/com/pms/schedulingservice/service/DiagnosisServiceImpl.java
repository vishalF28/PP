package com.pms.schedulingservice.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.schedulingservice.constants.MessageConstants;
import com.pms.schedulingservice.entity.Diagnosis;
import com.pms.schedulingservice.repository.DiagnosisRepository;


/**
 * The Class DiagnosisServiceImpl.
 */
@Service
public class DiagnosisServiceImpl implements DiagnosisService {

	/** The diagnosis repository. */
	@Autowired
	DiagnosisRepository diagnosisRepository;

	/**
	 * Gets the all diagnosis.
	 *
	 * @return the all diagnosis
	 */
	@Override
	public List<Diagnosis> getAllDiagnosis() {
		// TODO Auto-generated method stub
		return diagnosisRepository.findAll();
	}

	/**
	 * Gets the diagnosis by id.
	 *
	 * @param DiagnosisId the diagnosis id
	 * @return the diagnosis by id
	 */
	@Override
	public Optional<Diagnosis> getDiagnosisById(Long DiagnosisId) {
		// TODO Auto-generated method stub
		return diagnosisRepository.findById(DiagnosisId);
	}

	/**
	 * Gets the diagnosis by code.
	 *
	 * @param diagnosisCode the diagnosis code
	 * @return the diagnosis by code
	 */
	@Override
	public Optional<Diagnosis> getDiagnosisByCode(String diagnosisCode) {
		// TODO Auto-generated method stub
		return diagnosisRepository.findByDiagnosisCode(diagnosisCode);
	}

	/**
	 * Save diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 * @return the diagnosis
	 */
	@Override
	public Diagnosis saveDiagnosis(Diagnosis diagnosis) {
		
		return diagnosisRepository.save(diagnosis);
		
	}

	/**
	 * Delete diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 */
	@Override
	public String deleteDiagnosis(Diagnosis diagnosis) {
		diagnosisRepository.delete(diagnosis);
		return MessageConstants.DIAGNOSIS_DELETED_SUCCESS;
	}

	/**
	 * Update diagnosis.
	 *
	 * @param diagnosis the diagnosis
	 * @return the diagnosis
	 */
	@Override
	public Diagnosis updateDiagnosis(Diagnosis diagnosis) {
		return	diagnosisRepository.save(diagnosis);
		
	}

	@Override
	public List<Diagnosis> getNewlyAddedAllergies() {
		return diagnosisRepository.findAll().stream().filter(diagnosis->diagnosis.getIsNewlyAdded()).collect(Collectors.toList());
	}
	





}
