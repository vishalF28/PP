package com.pms.schedulingservice.exception;

public class AppointmentSlotAlreadyTakenException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AppointmentSlotAlreadyTakenException() {
		super();
	}

	public AppointmentSlotAlreadyTakenException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AppointmentSlotAlreadyTakenException(String message, Throwable cause) {
		super(message, cause);
	}

	public AppointmentSlotAlreadyTakenException(String message) {
		super(message);
	}

	public AppointmentSlotAlreadyTakenException(Throwable cause) {
		super(cause);
	}
	
	

}
