package com.pms.schedulingservice.model;

import com.pms.schedulingservice.enums.TimingSlots;

import lombok.Data;

@Data
public class AvailableTimingSlots {
	
	private TimingSlots timingSlots;

}
