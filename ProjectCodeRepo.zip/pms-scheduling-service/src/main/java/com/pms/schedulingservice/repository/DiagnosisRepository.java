package com.pms.schedulingservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pms.schedulingservice.entity.Diagnosis;

// TODO: Auto-generated Javadoc
/**
 * The Interface DiagnosisRepository.
 */
@Repository
public interface DiagnosisRepository extends JpaRepository<Diagnosis, Long> {

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<Diagnosis> findAll();
	
	/**
	 * Find by diagnosis code.
	 *
	 * @param diagnosisCode the diagnosis code
	 * @return the optional
	 */
	public Optional<Diagnosis> findByDiagnosisCode(String diagnosisCode);
	
	/**
	 * Find by diagnosis id.
	 *
	 * @param diagnosisId the diagnosis id
	 * @return the optional
	 */
	public Optional<Diagnosis> findByDiagnosisId(Long diagnosisId);
	
	
}
