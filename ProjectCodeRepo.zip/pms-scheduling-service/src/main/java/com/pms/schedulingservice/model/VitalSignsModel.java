package com.pms.schedulingservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VitalSignsModel {

	private Long vitalSignId;
	
	private Long appointmentId;
	
	private Long height;
	
    private Long weight;
    
    private String bloodPressure;
    
    private Float temperature;
    
    private Long respirationRate;
    
    private String capturedByNurseEmailId;
    
    private String capturedByNurseName;
    
    private Boolean isVitalSignsCaptured;
}
