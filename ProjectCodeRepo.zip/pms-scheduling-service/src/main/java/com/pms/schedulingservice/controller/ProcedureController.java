/**
 * 
 */
package com.pms.schedulingservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.schedulingservice.entity.Procedure;
import com.pms.schedulingservice.model.GenericSuccessResponse;
import com.pms.schedulingservice.service.ProcedureService;

import io.swagger.annotations.Api;

/**
 * The Class ProcedureController.
 *
 * @author SatpalC
 */
@Api
@RestController
@RequestMapping("/procedure")
public class ProcedureController {

	/** The procedure service. */
	@Autowired
	ProcedureService procedureService;

	/**
	 * Gets the all procedure.
	 *
	 * @return the all procedure
	 */
	@GetMapping("/getall")
	public ResponseEntity<List<Procedure>> getAllProcedure() {
		return new ResponseEntity<List<Procedure>>(procedureService.getAllProcedure(), HttpStatus.OK);
	}

	/**
	 * Gets the procedure by id.
	 *
	 * @param ProcedureId the procedure id
	 * @return the procedure by id
	 */
	@GetMapping("getById")
	public ResponseEntity<Procedure> getProcedureById(@RequestParam Long procedureId) {
		return new ResponseEntity<Procedure>(procedureService.getProcedureById(procedureId).get(), HttpStatus.OK);
	}

	/**
	 * Gets the procedure by code.
	 *
	 * @param ProcedureCode the procedure code
	 * @return the procedure by code
	 */
	@GetMapping("getByType")
	public ResponseEntity<Procedure> getProcedureByCode(@RequestParam String procedureCode) {
		return new ResponseEntity<Procedure>(procedureService.getProcedureByCode(procedureCode).get(), HttpStatus.OK);
	}

	/**
	 * Save procedure.
	 *
	 * @param Procedure the procedure
	 * @return the procedure
	 */
	@PostMapping("/save")
	public ResponseEntity<Procedure> saveProcedure(@RequestBody Procedure procedure) {

		return new ResponseEntity<Procedure>(procedureService.saveProcedure(procedure), HttpStatus.OK);
	}

	/**
	 * Delete procedure.
	 *
	 * @param Procedure the procedure
	 */
	@DeleteMapping("/delete")
	public ResponseEntity<GenericSuccessResponse> deleteProcedure(@RequestBody Procedure procedure) {

		String message = procedureService.deleteProcedure(procedure);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}

	/**
	 * Update procedure.
	 *
	 * @param Procedure the procedure
	 */
	@PutMapping("/update")
	public ResponseEntity<Procedure> updateProcedure(@RequestBody Procedure procedure) {

		return new ResponseEntity<Procedure>(procedureService.updateProcedure(procedure), HttpStatus.OK);
	}
	
	@GetMapping("get-newly-added-procedures")
	public ResponseEntity<List<Procedure>> getNewlyAddedProcedure(){
		return new ResponseEntity<List<Procedure>>(procedureService.getNewlyAddedProcedures(), HttpStatus.OK);
	}

}
