package com.pms.schedulingservice.service;

import com.pms.schedulingservice.model.VitalSignsModel;

public interface VitalSignsService {

	public String saveVitalSignsForPatientVisit(VitalSignsModel patientVitalSign);

}
