
package com.pms.schedulingservice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// TODO: Auto-generated Javadoc

@Getter(value = AccessLevel.PUBLIC)
@Setter(value = AccessLevel.PUBLIC)
@NoArgsConstructor
@ToString
@AllArgsConstructor
@Entity
@Table(name = "pms_procedure", schema = "pms_master")
public class Procedure extends Auditable<String> implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "procedure_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_procedure_generator")
	@SequenceGenerator(name="pms_procedure_generator", sequenceName = "pms_master.pms_procedure_seq", allocationSize=1)
	private Long procedureId;
    
	@Column(name = "procedure_code")
    private String procedureCode;
	
	@Column(name = "procedure_description")
	private String procedureDescription;
	
	@Column(name = "procedure_is_deprecated")
	private boolean procedureIsDeprecated;
	
	@Column(name="is_newly_added")
	private Boolean isNewlyAdded;

}
