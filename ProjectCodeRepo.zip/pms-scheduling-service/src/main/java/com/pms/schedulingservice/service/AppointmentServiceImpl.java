package com.pms.schedulingservice.service;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.pms.schedulingservice.constants.MessageConstants;
import com.pms.schedulingservice.entity.Appointment;
import com.pms.schedulingservice.entity.Diagnosis;
import com.pms.schedulingservice.entity.PatientDrugMapping;
import com.pms.schedulingservice.entity.Procedure;
import com.pms.schedulingservice.entity.RescheduledAppointmentHistory;
import com.pms.schedulingservice.enums.Gender;
import com.pms.schedulingservice.enums.TimingSlots;
import com.pms.schedulingservice.exception.AppointmentSlotAlreadyTakenException;
import com.pms.schedulingservice.feignclient.PatientFeignClient;
import com.pms.schedulingservice.model.MailRequest;
import com.pms.schedulingservice.model.Patient;
import com.pms.schedulingservice.model.PhysicianDashboardGraph;
import com.pms.schedulingservice.model.RescheduleAppointment;
import com.pms.schedulingservice.repository.AppointmentRespository;
import com.pms.schedulingservice.repository.PatientDrugMappingRepository;
import com.pms.schedulingservice.repository.RescheduledAppoinmentRepository;

import reactor.core.publisher.Mono;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	private AppointmentRespository appointmentRespository;

	private RescheduledAppoinmentRepository rescheduledAppoinmentRepository;

	private PatientDrugMappingRepository patientDrugMappingRepository;

	private PatientFeignClient patientFeignClient;
	
	private WebClient webClient;

	@Autowired
	public AppointmentServiceImpl(PatientDrugMappingRepository patientDrugMappingRepository,
			AppointmentRespository appointmentRespository,
			RescheduledAppoinmentRepository rescheduledAppoinmentRepository,
			PatientFeignClient patientFeignClient, WebClient webClient) {
		this.patientDrugMappingRepository = patientDrugMappingRepository;
		this.appointmentRespository = appointmentRespository;
		this.rescheduledAppoinmentRepository = rescheduledAppoinmentRepository;
		this.patientFeignClient = patientFeignClient;
		this.webClient = webClient;
	}

	@Override
	public Appointment addNewAppointment(Appointment appointment) {
		Appointment savedAppointment = new Appointment();
		List<TimingSlots> availableSlotsForPhysician = getAvailableSlotsForPhysicianByDate(appointment.getPhysicianEmailId(), appointment.getDateOfAppointment());
		try {

			appointment.setTimeOfAppointment(TimingSlots.valueOf(appointment.getTimeOfAppointment().toString()));
			if(!availableSlotsForPhysician.contains(appointment.getTimeOfAppointment()))
			{
				throw new AppointmentSlotAlreadyTakenException();
			}
			if(null == appointment.getDataCollectionAppointmentBooked() || !appointment.getDataCollectionAppointmentBooked())
			{
				appointment.setDataCollectionAppointmentBooked(false);
			}
			appointment.setReadyForScheduling(false);
			savedAppointment = appointmentRespository.save(appointment);
			
			MailRequest appointmentConfirmationMailRequest = new MailRequest();
			appointmentConfirmationMailRequest.setAppointmentId(savedAppointment.getAppointmentId());
			appointmentConfirmationMailRequest.setDateOfAppointment(savedAppointment.getDateOfAppointment());
			appointmentConfirmationMailRequest.setTimeOfAppointment(savedAppointment.getTimeOfAppointment());
			appointmentConfirmationMailRequest.setPatientName(savedAppointment.getPatientName());
			appointmentConfirmationMailRequest.setPhysicianName(savedAppointment.getPhysicianName());
			appointmentConfirmationMailRequest.setPhysicianEmailId(savedAppointment.getPhysicianEmailId());
			appointmentConfirmationMailRequest.setPatientEmailId(savedAppointment.getPatientEmailId());
			appointmentConfirmationMail(appointmentConfirmationMailRequest);

		} catch (Exception e) {
			if(!(e instanceof AppointmentSlotAlreadyTakenException))
				throw new RuntimeException(MessageConstants.FAILED_TO_ADD_NEW_APPOINTMENT);
			else
				throw new AppointmentSlotAlreadyTakenException(MessageConstants.APPOINTMENT_SLOT_ALREADY_TAKEN);
		}
		return savedAppointment;
	}

	@Override
	public List<TimingSlots> getAvailableSlotsForPhysicianByDate(String physicianEmailId, Date appointmentDate) {

		List<TimingSlots> availableTimeSlots = new ArrayList<>(Arrays.asList(TimingSlots.values()));
		try
		{
			List<TimingSlots> toBeDisabledTimingSlots = new ArrayList<TimingSlots>();
			if(findIfTodaysDateIsSameAsAppointmentDate(appointmentDate)) {
				toBeDisabledTimingSlots = findDisabledTimeSlots();
			}
			try {
				List<Appointment> bookedAppointment = appointmentRespository
						.findAppointmentByPhysicianEmailIdAndDateOfAppointment(physicianEmailId, appointmentDate);
				List<TimingSlots> bookedTimeSlot = new ArrayList<>();
				for (Appointment appointment : bookedAppointment) {
					bookedTimeSlot.add(appointment.getTimeOfAppointment());
				}
				Set<TimingSlots> toBeRemovedTimingSots = new HashSet<TimingSlots>(toBeDisabledTimingSlots);
				toBeRemovedTimingSots.addAll(bookedTimeSlot);
				availableTimeSlots.removeAll(toBeRemovedTimingSots);
			} catch (Exception e) {
				throw new RuntimeException(MessageConstants.FAILED_TO_LOAD_AVAILABLE_SLOTS);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return availableTimeSlots;
	}

	@Override
	public List<Appointment> getUpcomingPatientAppointments(String patientEmailId) {
		List<Appointment> appointments = appointmentRespository.findAppointmentByPatientEmailId(patientEmailId).stream()
				.filter(appointment -> (!appointment.getIsVisited())).collect(Collectors.toList());
		return appointments;
	}

	@Override
	public List<Appointment> getPatientAppointmentsHistory(String patientEmailId) {
		return appointmentRespository.findAppointmentByPatientEmailId(patientEmailId).stream()
				.filter(appointment -> (appointment.getIsVisited())).collect(Collectors.toList());
	}

	public List<Appointment> getUpcomingPhysicianAppointments(String physicianEmailId) {
		List<Appointment> appointments = appointmentRespository.findAppointmentByPhysicianEmailId(physicianEmailId).stream()
				.filter(appointment -> (!appointment.getIsVisited() && (!appointment.getIsDeleted()) 
						&& (null != appointment.getVitalSigns() && appointment.getVitalSigns().getIsVitalSignsCaptured())))
				.collect(Collectors.toList());
		return appointments;
	}

	@Override
	public Appointment getAppointmentDetails(Long appointmentId) {
		Appointment appointment = appointmentRespository.findById(appointmentId).get();
		Set<PatientDrugMapping> patientdrugMappings = appointment.getPatientDrugData();
		appointment.setPatientDrugData(patientdrugMappings);
		return appointment;
	}

	@Override
	public Appointment updateAppointmentDetails(Object vitalSigns, Long appointmentId) {
		Appointment appointmentDetails = appointmentRespository.findById(appointmentId).get();
		appointmentDetails.setIsVisited(Boolean.TRUE);
		appointmentRespository.save(appointmentDetails);
		return appointmentDetails;

	}

	public List<Appointment> getUpcomingPatientAppointmentsForPhysician(String physicianEmailId) {
		return appointmentRespository.findAppointmentByPhysicianEmailId(physicianEmailId).stream()
				.filter(appointment -> (!appointment.getIsVisited() && (!appointment.getIsDeleted()) &&
						(null != appointment.getVitalSigns() && !appointment.getVitalSigns().getIsVitalSignsCaptured())		
						))
				.collect(Collectors.toList());
	}

	@Override
	public Appointment getAppointment(Long appointmentId) {
		return appointmentRespository.findById(appointmentId).get();
	}

	@Override
	public Appointment rescheduleAppointment(RescheduleAppointment rescheduleAppointment) {
		Appointment oldAppointment = appointmentRespository.findById(rescheduleAppointment.getAppointmentId()).get();
		oldAppointment.setIsRescheduled(Boolean.TRUE);
		RescheduledAppointmentHistory rescheduledAppointmentHistory = new RescheduledAppointmentHistory();
		BeanUtils.copyProperties(oldAppointment, rescheduledAppointmentHistory);
		BeanUtils.copyProperties(rescheduleAppointment, oldAppointment);
		try {
			appointmentRespository.save(oldAppointment);
			rescheduledAppoinmentRepository.save(rescheduledAppointmentHistory);
			
			MailRequest appointmentRescheduleMailRequest = new MailRequest();
			appointmentRescheduleMailRequest.setAppointmentId(oldAppointment.getAppointmentId());
			appointmentRescheduleMailRequest.setDateOfAppointment(oldAppointment.getDateOfAppointment());
			appointmentRescheduleMailRequest.setTimeOfAppointment(oldAppointment.getTimeOfAppointment());
			appointmentRescheduleMailRequest.setPatientName(oldAppointment.getPatientName());
			appointmentRescheduleMailRequest.setPhysicianName(oldAppointment.getPhysicianName());
			appointmentRescheduleMailRequest.setPhysicianEmailId(oldAppointment.getPhysicianEmailId());
			appointmentRescheduleMailRequest.setPatientEmailId(oldAppointment.getPatientEmailId());
			appointmentRescheduleMail(appointmentRescheduleMailRequest);

		} catch (Exception e) {
			throw new RuntimeException(MessageConstants.RESCHUEDULED_APPOINTMNENT_FAILURE);
		}
		return oldAppointment;
	}

	@Override
	public Appointment deleteAppointment(Long appointmentId) {
		Appointment oldAppointment = appointmentRespository.findById(appointmentId).get();
		oldAppointment.setIsDeleted(Boolean.TRUE);
		
		MailRequest appointmentDeleteMailRequest = new MailRequest();
		appointmentDeleteMailRequest.setAppointmentId(oldAppointment.getAppointmentId());
		appointmentDeleteMailRequest.setDateOfAppointment(oldAppointment.getDateOfAppointment());
		appointmentDeleteMailRequest.setTimeOfAppointment(oldAppointment.getTimeOfAppointment());
		appointmentDeleteMailRequest.setPatientName(oldAppointment.getPatientName());
		appointmentDeleteMailRequest.setPhysicianName(oldAppointment.getPhysicianName());
		appointmentDeleteMailRequest.setPhysicianEmailId(oldAppointment.getPhysicianEmailId());
		appointmentDeleteMailRequest.setPatientEmailId(oldAppointment.getPatientEmailId());
		appointmentDeletionMail(appointmentDeleteMailRequest);

		return appointmentRespository.save(oldAppointment);
	}

	@Override
	public boolean addPatientDiagnosis(Diagnosis diagnosis, Long appointmentId) {
		System.out.println("add diagnosiss " + diagnosis);
		Appointment appointmentDetails = appointmentRespository.findById(appointmentId).get();
		Set<Diagnosis> patientDiagnosis = appointmentDetails.getDiagnosis();
		patientDiagnosis.add(diagnosis);
		appointmentDetails.setDiagnosis(patientDiagnosis);
		return Optional.ofNullable(appointmentRespository.save(appointmentDetails)).isPresent();

	}

	@Override
	public boolean addPatientProcedure(Procedure procedure, Long appointmentId) {
		Appointment appointmentDetails = appointmentRespository.findById(appointmentId).get();
		Set<Procedure> patientProcedure = appointmentDetails.getProcedure();
		patientProcedure.add(procedure);
		appointmentDetails.setProcedure(patientProcedure);
		return Optional.ofNullable(appointmentRespository.save(appointmentDetails)).isPresent();
	}

	@Override
	public boolean addPatientDrug(PatientDrugMapping patientDrugData, Long appointmentId) {
		Appointment appointmentDetails = appointmentRespository.findById(appointmentId).get();
		try {

			Set<PatientDrugMapping> patientDrugMappings = appointmentDetails.getPatientDrugData();
			patientDrugMappings.add(patientDrugData);
			appointmentDetails.setPatientDrugData(patientDrugMappings);
			return Optional.ofNullable(appointmentRespository.save(appointmentDetails)).isPresent();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);
		}

	}

	@Transactional
	@Override
	public void deletePatientDiagnosis(Long diagnosisId, Long appointmentId) {

		appointmentRespository.deletePatientDiagnosis(appointmentId, diagnosisId);

	}
	@Transactional
	@Override
	public void deletePatientProcedure(Long procedureId, Long appointmentId) {

		appointmentRespository.deletePatientProcedure(appointmentId, procedureId);

	}
	@Transactional
	@Override
	public void deletePatientDrug(Long patientDrugMappingId) {
		patientDrugMappingRepository.deleteById(patientDrugMappingId);
	}

	private boolean findIfTodaysDateIsSameAsAppointmentDate(Date appointmentDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		return sdf.format(new Date()).equals(sdf.format(appointmentDate));
	}

	private List<TimingSlots> findDisabledTimeSlots() {
		List<TimingSlots> disableTimingSlots = null;
		LocalTime locallTime = LocalTime.now();
		String strLocalTime = locallTime.toString();
		String[] timeArray = strLocalTime.split(":");
		Integer timeHour = Integer.parseInt(timeArray[0]);
		Integer timeMinute = Integer.parseInt(timeArray[1]);
		if(timeHour == 13 || timeHour == 14)
		{
			disableTimingSlots = TimingSlots.findTimingSlotsForBreak();
			return disableTimingSlots;
		}
		else if(timeHour >= 20)
		{
			disableTimingSlots = TimingSlots.findTimingSlotsForEOD();
			return disableTimingSlots;
		}
		else
		{
			String maxTimeSlot = findTimeSlotBasedOnTime(timeHour, timeMinute);
			disableTimingSlots = TimingSlots.findTimingSlotsForRegularTime(maxTimeSlot);
			return disableTimingSlots;
		}
	}

	private String findTimeSlotBasedOnTime(Integer timeHour, Integer timeMinute) {
		String currentTimeSlot = "";
		if(timeHour < 12)
		{
			if(timeMinute <30)
			{
				currentTimeSlot = timeHour + ":00 AM To " + timeHour + ":30 AM";
			}
			else
			{
				if((timeHour + 1) == 12)
				{
					currentTimeSlot = timeHour + ":30 AM To " + (timeHour + 1) + ":00 PM";
				}
				else
				{
					currentTimeSlot = timeHour + ":30 AM To " + (timeHour + 1) + ":00 AM";
				}
			}
		}
		else if(timeHour == 12)
		{
			if(timeMinute <30)
			{
				currentTimeSlot = timeHour + ":00 PM To " + timeHour + ":30 PM";
			}
			else
			{
				currentTimeSlot = timeHour + ":30 PM To 1:00 PM";
			}
		}
		else
		{
			if(timeMinute <30)
			{
				currentTimeSlot = (timeHour-12) + ":00 PM To " + (timeHour-12) + ":30 PM";
			}
			else
			{
				currentTimeSlot = (timeHour-12) + ":30 PM To " + (timeHour-12+1) + ":00 PM";
			}
		}
		return currentTimeSlot;
	}

	@Override
	@Transactional
	public void deletePatientDrugById(Long appointmentId, Long drugId) {
		patientDrugMappingRepository.deleteByAppointmentIdAndDrugId(appointmentId, drugId);
	}

	@Override
	public List<Appointment> getUpcomingAppointments() {
		return appointmentRespository.findAll().stream()
				.filter(appointment -> (!appointment.getIsVisited() && (!appointment.getIsDeleted()) 
						&& ((null == appointment.getVitalSigns()) || 
								(null != appointment.getVitalSigns() && !appointment.getVitalSigns().getIsVitalSignsCaptured()))
						)
						)
				.collect(Collectors.toList());
	}

	@Override
	public Long getTodaysAppointmentCount() {
		return appointmentRespository.countAppointmentByDateOfAppointment(new Date());
	}

	@Override
	public List<Appointment> getAppointmentsForPhysicianCalender(String physicianEmailId) {
		List<Appointment> appointments = appointmentRespository.findAppointmentByPhysicianEmailId(physicianEmailId).stream()
				.filter(appointment -> (!appointment.getIsVisited() && (!appointment.getIsDeleted())))
				.collect(Collectors.toList());
		return appointments;
	}

	@Override
	public Long getTodaysAppointmentCountByPhysician(String phyisicanEmailId) {
		return appointmentRespository.getTodaysAppointmentCountByPhysician(phyisicanEmailId);
	}

	@Override
	public List<Appointment> getAppointmentsToCaptureVitalSigns() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		return appointmentRespository.findAll().stream()
				.filter(appointment -> (!appointment.getIsVisited() && !appointment.getIsDeleted() && 
						(null == appointment.getVitalSigns() || 
						(null != appointment.getVitalSigns() && !appointment.getVitalSigns().getIsVitalSignsCaptured())) &&
						sdf.format(new Date()).equals(sdf.format(appointment.getDateOfAppointment()))))
				.collect(Collectors.toList());
	}

	@Override
	public List<PhysicianDashboardGraph> getWeeklyAppointmentCount(String phyisicanEmailId) {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-YYYY");
		Calendar c = Calendar.getInstance();
		int count = 7;
		List<PhysicianDashboardGraph> graph = new ArrayList<>();
		while(count!=0) {
			c.setTime(date);
			c.add(Calendar.DATE, 1);
			date = c.getTime();
			String strDate= formatter.format(date);
			Long appointmentCount = appointmentRespository.getAppointmentCountByPhysicianAndDate(phyisicanEmailId, strDate);
			graph.add(new PhysicianDashboardGraph(strDate, appointmentCount));
			count--;
		}
		return graph;
	}

	@Override
	public List<PhysicianDashboardGraph> getPatientTreatedByGenderWise(String phyisicanEmailId) {
		List<Appointment> appointments = appointmentRespository.findAppointmentByPhysicianEmailId(phyisicanEmailId);
		Set<Long> patientIds = new HashSet<>();
		for (Appointment appointment : appointments) {
			patientIds.add(appointment.getPatientId());
		}
		List<Patient> patients = patientFeignClient.getPatientProfileForPhysicianDashboard(patientIds).getBody();

		Long maleCount=0L, femaleCount=0L, othersCount=0L;

		for (Patient patient : patients) {
			if(patient.getGender().equals(Gender.MALE)) {
				maleCount++;
			}
			else if(patient.getGender().equals(Gender.FEMALE)) {
				femaleCount++;
			}
			else if(patient.getGender().equals(Gender.OTHER)) {
				othersCount++;
			}
		}

		List<PhysicianDashboardGraph> graph = new ArrayList<>();
		graph.add(new PhysicianDashboardGraph("Male", maleCount));
		graph.add(new PhysicianDashboardGraph("Female", femaleCount));
		graph.add(new PhysicianDashboardGraph("Others", othersCount));

		return graph;
	}

	@Override
	public Map<String, Long> getPatientVisitedRatioForNurse() {
		@SuppressWarnings("deprecation")
		int currentYear = new Date().getYear();
		@SuppressWarnings("deprecation")
		Date startDate = new Date(currentYear, 1, 1);
		Date currentDate = new Date();
		Map<String, Long> graphData = new HashMap<>();
		graphData.put("Visited",0L);
		graphData.put("Unvisited", 0L);
		try {
			List<Appointment> appointments = appointmentRespository.findByDateOfAppointmentBetween(startDate, currentDate).stream().collect(Collectors.toList()); 
			for(Appointment appointment: appointments) {
				if(appointment.getIsVisited()) {
					graphData.put("Visited", graphData.get("Visited")+1);
				}
				else {
					graphData.put("Unvisited", graphData.get("Unvisited")+1);
				}
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return graphData;
	}

	@Transactional
	@Override
	public void scheduleDataCollectionAppointment() {
		appointmentRespository.scheduleDataCollectionAppointment();
	}
	private String appointmentConfirmationMail(MailRequest appointmentConfirmationMailRequest) {
		webClient.post().uri("/sendmail/appointment-confirmation").body(Mono.just(appointmentConfirmationMailRequest), MailRequest.class)
		.exchange().doOnError(error -> error.printStackTrace()).subscribe();

		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String appointmentRescheduleMail(MailRequest appointmentRescheduleMailRequest) {
		webClient.post().uri("/sendmail/appointment-reschedule").body(Mono.just(appointmentRescheduleMailRequest), MailRequest.class)
		.exchange().doOnError(error -> error.printStackTrace()).subscribe();

		return MessageConstants.MAIL_SENT_SUCCESS;
	}
	
	private String appointmentDeletionMail(MailRequest appointmentDeleteMailRequest) {
		webClient.post().uri("/sendmail/appointment-delete").body(Mono.just(appointmentDeleteMailRequest), MailRequest.class)
		.exchange().doOnError(error -> error.printStackTrace()).subscribe();

		return MessageConstants.MAIL_SENT_SUCCESS;
	}
	
	@Override
	public ByteArrayInputStream getAppintmentReportById(Long appointmentId) {
		
		Appointment appointment =  appointmentRespository.findByAppointmentId(appointmentId);
		
		return GeneratePdfReport.appointmentReport(appointment);
	}

}
