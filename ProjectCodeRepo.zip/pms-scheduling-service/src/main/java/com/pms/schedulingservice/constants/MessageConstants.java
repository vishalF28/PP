package com.pms.schedulingservice.constants;

public class MessageConstants {

	
	public static final String INTERNAL_SERVER_ERROR = "Some error occured. Please contact system administrator.";

	public static final String FAILED_TO_ADD_NEW_APPOINTMENT = "Failed to add new appointment.";

	public static final String FAILED_TO_LOAD_AVAILABLE_SLOTS = "Fail to load available slots for physician.";
	
	public static final String DIAGNOSIS_DELETED_SUCCESS = "Diagnosis deleted successfully.";

	public static final String DRUG_DELETED_SUCCESS = "Drug deleted successfully.";

	public static final String PROCEDURE_DELETED_SUCCESS = "Procedure deleted successfully.";

	public static final String SAVE_VITAL_SIGNS_SUCCESS = "Vital Signs Added Successfully";

	public static final String FAILED_TO_SAVE_VITAL_SIGNS = "Failed to save vital signs";

	public static final String RESCHUEDULED_APPOINTMNENT_FAILURE = "Failed to Reschedule appointment";

	public static final String APPOINTMENT_SLOT_ALREADY_TAKEN = "Appointment Slot already taken. Please try again.";

	public static final String MAIL_SENT_SUCCESS = "Mail sent successfully.";

}
