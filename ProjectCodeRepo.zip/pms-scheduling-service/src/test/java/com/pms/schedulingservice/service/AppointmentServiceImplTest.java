/**
 * 
 */
package com.pms.schedulingservice.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author SatpalC
 *
 */
class AppointmentServiceImplTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#AppointmentServiceImpl(com.pms.schedulingservice.repository.PatientDrugMappingRepository, com.pms.schedulingservice.repository.AppointmentRespository, com.pms.schedulingservice.repository.RescheduledAppoinmentRepository, com.pms.schedulingservice.feignclient.PatientFeignClient)}.
	 */
	@Test
	void testAppointmentServiceImpl() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#addNewAppointment(com.pms.schedulingservice.entity.Appointment)}.
	 */
	@Test
	void testAddNewAppointment() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getAvailableSlotsForPhysicianByDate(java.lang.String, java.util.Date)}.
	 */
	@Test
	void testGetAvailableSlotsForPhysicianByDate() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getUpcomingPatientAppointments(java.lang.String)}.
	 */
	@Test
	void testGetUpcomingPatientAppointments() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getPatientAppointmentsHistory(java.lang.String)}.
	 */
	@Test
	void testGetPatientAppointmentsHistory() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getUpcomingPhysicianAppointments(java.lang.String)}.
	 */
	@Test
	void testGetUpcomingPhysicianAppointments() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getAppointmentDetails(java.lang.Long)}.
	 */
	@Test
	void testGetAppointmentDetails() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#updateAppointmentDetails(java.lang.Object, java.lang.Long)}.
	 */
	@Test
	void testUpdateAppointmentDetails() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getUpcomingPatientAppointmentsForPhysician(java.lang.String)}.
	 */
	@Test
	void testGetUpcomingPatientAppointmentsForPhysician() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getAppointment(java.lang.Long)}.
	 */
	@Test
	void testGetAppointment() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#rescheduleAppointment(com.pms.schedulingservice.model.RescheduleAppointment)}.
	 */
	@Test
	void testRescheduleAppointment() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#deleteAppointment(java.lang.Long)}.
	 */
	@Test
	void testDeleteAppointment() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#addPatientDiagnosis(com.pms.schedulingservice.entity.Diagnosis, java.lang.Long)}.
	 */
	@Test
	void testAddPatientDiagnosis() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#addPatientProcedure(com.pms.schedulingservice.entity.Procedure, java.lang.Long)}.
	 */
	@Test
	void testAddPatientProcedure() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#addPatientDrug(com.pms.schedulingservice.entity.PatientDrugMapping, java.lang.Long)}.
	 */
	@Test
	void testAddPatientDrug() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#deletePatientDiagnosis(java.lang.Long, java.lang.Long)}.
	 */
	@Test
	void testDeletePatientDiagnosis() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#deletePatientProcedure(java.lang.Long, java.lang.Long)}.
	 */
	@Test
	void testDeletePatientProcedure() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#deletePatientDrug(java.lang.Long)}.
	 */
	@Test
	void testDeletePatientDrug() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#deletePatientDrugById(java.lang.Long, java.lang.Long)}.
	 */
	@Test
	void testDeletePatientDrugById() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getUpcomingAppointments()}.
	 */
	@Test
	void testGetUpcomingAppointments() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getTodaysAppointmentCount()}.
	 */
	@Test
	void testGetTodaysAppointmentCount() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getAppointmentsForPhysicianCalender(java.lang.String)}.
	 */
	@Test
	void testGetAppointmentsForPhysicianCalender() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getTodaysAppointmentCountByPhysician(java.lang.String)}.
	 */
	@Test
	void testGetTodaysAppointmentCountByPhysician() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getAppointmentsToCaptureVitalSigns()}.
	 */
	@Test
	void testGetAppointmentsToCaptureVitalSigns() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getWeeklyAppointmentCount(java.lang.String)}.
	 */
	@Test
	void testGetWeeklyAppointmentCount() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getPatientTreatedByGenderWise(java.lang.String)}.
	 */
	@Test
	void testGetPatientTreatedByGenderWise() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.AppointmentServiceImpl#getPatientVisitedRatioForNurse()}.
	 */
	@Test
	void testGetPatientVisitedRatioForNurse() {
		fail("Not yet implemented"); // TODO
	}

}
