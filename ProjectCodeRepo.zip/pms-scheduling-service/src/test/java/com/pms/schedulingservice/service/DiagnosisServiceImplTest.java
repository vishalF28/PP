/**
 * 
 */
package com.pms.schedulingservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.pms.schedulingservice.entity.Diagnosis;
import com.pms.schedulingservice.repository.DiagnosisRepository;

/**
 * @author SatpalC
 *
 */
class DiagnosisServiceImplTest {

	@Mock
	DiagnosisRepository diagnosisRepository;
	@InjectMocks
	DiagnosisServiceImpl diagnosisServiceImpl;

	Diagnosis diagnosis;
	List<Diagnosis> diagnosisList;

	

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		diagnosis = new Diagnosis();
		diagnosis.setDiagnosisId(1L);
		diagnosis.setDiagnosisCode("DGCODE");
		diagnosis.setDiagnosisDescription("DIAGNOSIS DESCRIPTION");
		diagnosis.setIsNewlyAdded(false);
		diagnosis.setDeprecated(false);

	}

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#getAllDiagnosis()}.
	 */
	@Test
	@DisplayName("get all diagnosis response should not be null")
	void testGetAllDiagnosis() {

		diagnosisList = new ArrayList<>();
		diagnosisList.add(diagnosis);
		when(diagnosisRepository.findAll()).thenReturn(diagnosisList);

		List<Diagnosis> returnDiagnosisList = diagnosisServiceImpl.getAllDiagnosis();

		assertNotNull(returnDiagnosisList);

	}

	

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#getDiagnosisById(java.lang.Long)}.
	 */
	@Test
	void testGetDiagnosisById_return_diagnosis_not_null() {
		when(diagnosisRepository.findById(anyLong())).thenReturn(Optional.of(diagnosis));

		Diagnosis returnedDiagnosis=diagnosisServiceImpl.getDiagnosisById(1L).get();
		
		assertNotNull(returnedDiagnosis);
	}
	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#getDiagnosisById(java.lang.Long)}.
	 */
	@Test
	void testGetDiagnosisById_return_same_diagnosis() {
		when(diagnosisRepository.findById(anyLong())).thenReturn(Optional.of(diagnosis));

		Diagnosis returnedDiagnosis=diagnosisServiceImpl.getDiagnosisById(1L).get();
		
		assertEquals(diagnosis.getDiagnosisId(), returnedDiagnosis.getDiagnosisId());
	}
	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#getDiagnosisByCode(java.lang.String)}.
	 */
	@Test
	void testGetDiagnosisByCode_return_same_diagnosis() {
		when(diagnosisRepository.findByDiagnosisCode(anyString())).thenReturn(Optional.of(diagnosis));

		Diagnosis returnedDiagnosis=diagnosisServiceImpl.getDiagnosisByCode("DGCODE").get();
		
		assertEquals(diagnosis.getDiagnosisCode(), returnedDiagnosis.getDiagnosisCode());
	}
	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#getDiagnosisByCode(java.lang.String)}.
	 */
	@Test
	void testGetDiagnosisByCode_return_Object_not_null() {
		when(diagnosisRepository.findByDiagnosisCode(anyString())).thenReturn(Optional.of(diagnosis));

		Diagnosis returnedDiagnosis=diagnosisServiceImpl.getDiagnosisByCode("DGCODE").get();
		
		assertNotNull(returnedDiagnosis);
	}
	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#saveDiagnosis(com.pms.schedulingservice.entity.Diagnosis)}.
	 */
	@Test
	void testSaveDiagnosis_return_diagnosis_not_null() {
		when(diagnosisRepository.save(any())).thenReturn(diagnosis);
        Diagnosis returnedDiagnosis=diagnosisServiceImpl.saveDiagnosis(diagnosis);
		
		assertNotNull(returnedDiagnosis);
	}
	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#saveDiagnosis(com.pms.schedulingservice.entity.Diagnosis)}.
	 */
	@Test
	void testSaveDiagnosis_return_same_diagnosis() {
		when(diagnosisRepository.save(any())).thenReturn(diagnosis);
        Diagnosis returnedDiagnosis=diagnosisServiceImpl.saveDiagnosis(diagnosis);
		
        assertEquals(diagnosis.getDiagnosisCode(), returnedDiagnosis.getDiagnosisCode());
	}
	

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#updateDiagnosis(com.pms.schedulingservice.entity.Diagnosis)}.
	 */
	@Test
	void testUpdateDiagnosis_return_same_diagnosis() {
		
		when(diagnosisRepository.save(any())).thenReturn(diagnosis);
        Diagnosis returnedDiagnosis=diagnosisServiceImpl.updateDiagnosis(diagnosis);
		
        assertEquals(diagnosis.getDiagnosisCode(), returnedDiagnosis.getDiagnosisCode());
		
	}

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DiagnosisServiceImpl#updateDiagnosis(com.pms.schedulingservice.entity.Diagnosis)}.
	 */
	@Test
	void testUpdateDiagnosis_return_diagnosis_not_null() {
		
		when(diagnosisRepository.save(any())).thenReturn(diagnosis);
        Diagnosis returnedDiagnosis=diagnosisServiceImpl.updateDiagnosis(diagnosis);
		
       assertNotNull(returnedDiagnosis);
		
	}

}
