/**
 * 
 */
package com.pms.schedulingservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.pms.schedulingservice.entity.Procedure;
import com.pms.schedulingservice.repository.ProcedureRepository;

/**
 * @author SatpalC
 *
 */
class ProcedureServiceImplTest {

	@Mock
	ProcedureRepository procedureRepository;
	@InjectMocks
	ProcedureServiceImpl procedureServiceImpl;
	Procedure procedure;
	List<Procedure> procedureList;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		
		
		 procedure= new Procedure();
		 procedure.setProcedureId(1L);
		 procedure.setIsNewlyAdded(false);
		 procedure.setProcedureCode("pcode");
		 procedure.setProcedureDescription("pro description");
		 procedure.setProcedureIsDeprecated(false);
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.ProcedureServiceImpl#getAllProcedure()}.
	 */
	@Test
	void testGetAllProcedure() {
		procedureList = new ArrayList<>();
		procedureList.add(procedure);
		when(procedureRepository.findAll()).thenReturn(procedureList);

		List<Procedure> returnProcedureList = procedureServiceImpl.getAllProcedure();

		assertNotNull(returnProcedureList);
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.ProcedureServiceImpl#getProcedureById(java.lang.Long)}.
	 */
	@Test
	void testGetProcedureById__return_procedure_notNull() {
		when(procedureRepository.findById(anyLong())).thenReturn(Optional.of(procedure));

		Procedure returnedprocedure=procedureServiceImpl.getProcedureById(1L).get();
		
		assertNotNull(returnedprocedure);
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.ProcedureServiceImpl#getProcedureByCode(java.lang.String)}.
	 */
	@Test
	void testGetProcedureByCode() {
		when(procedureRepository.findByProcedureCode(anyString())).thenReturn(Optional.of(procedure));

		Procedure returnedProcedure=procedureServiceImpl.getProcedureByCode("pcode").get();
		
		assertEquals(procedure.getProcedureCode(), returnedProcedure.getProcedureCode());
	}

	/**
	 * Test method for {@link com.pms.schedulingservice.service.ProcedureServiceImpl#saveProcedure(com.pms.schedulingservice.entity.Procedure)}.
	 */
	@Test
	void testSaveProcedure() {
		when(procedureRepository.save(any())).thenReturn(procedure);
		Procedure returnedProcedure=procedureServiceImpl.saveProcedure(procedure);
		assertNotNull(returnedProcedure);
	}

	

	/**
	 * Test method for {@link com.pms.schedulingservice.service.ProcedureServiceImpl#updateProcedure(com.pms.schedulingservice.entity.Procedure)}.
	 */
	@Test
	void testUpdateProcedure() {
		when(procedureRepository.save(any())).thenReturn(procedure);
		Procedure returnedProcedure=procedureServiceImpl.updateProcedure(procedure);
		assertNotNull(returnedProcedure);
	}
	

	
}
