/**
 * 
 */
package com.pms.schedulingservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.pms.schedulingservice.entity.DrugData;
import com.pms.schedulingservice.repository.DrugDataRepository;

/**
 * @author SatpalC
 *
 */
class DrugDataServiceImplTest {

	@Mock
	DrugDataRepository drugDataRepository;
	@InjectMocks
	DrugDataServiceImpl drugDataServiceImpl;
	DrugData drugData;
	List<DrugData> drugDataList;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		drugData = new DrugData();
		drugData.setDrugId(1L);
		drugData.setDrugDescription("drug description");
		drugData.setDrugForm("drug form");
		drugData.setDrugGenericName("drug gen name");
		drugData.setDrugManufacturerName("drug mfg name");
		drugData.setDrugName("drug name");
		drugData.setDrugStrength("drug strength");
		drugData.setIsNewlyAdded(false);

	}

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DrugDataServiceImpl#getAllDrugData()}.
	 */
	@Test
	@DisplayName("get all drugdata response should not be null")
	void testGetAllDrugData() {
		drugDataList = new ArrayList<>();
		drugDataList.add(drugData);
		when(drugDataRepository.findAll()).thenReturn(drugDataList);

		List<DrugData> returnDrugDataList = drugDataServiceImpl.getAllDrugData();

		assertNotNull(returnDrugDataList);
	}

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DrugDataServiceImpl#getDrugDataById(java.lang.Long)}.
	 */
	@Test
	void testGetDrugDataById() {
		when(drugDataRepository.findById(anyLong())).thenReturn(Optional.of(drugData));

		DrugData returnedDrugData = drugDataServiceImpl.getDrugDataById(1L).get();

		assertEquals(drugData.getDrugId(), returnedDrugData.getDrugId());
	}

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DrugDataServiceImpl#getDrugDataByName(java.lang.String)}.
	 */
	@Test
	void testGetDrugDataByName() {
		when(drugDataRepository.findByDrugName(anyString())).thenReturn(Optional.of(drugData));

		DrugData returnedDrugData = drugDataServiceImpl.getDrugDataByName("drug name").get();

		assertEquals(drugData.getDrugName(), returnedDrugData.getDrugName());
	}

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DrugDataServiceImpl#saveDrugData(com.pms.schedulingservice.entity.DrugData)}.
	 */
	@Test
	void testSaveDrugData() {
		when(drugDataRepository.save(any())).thenReturn(drugData);
		DrugData returnedDrugData = drugDataServiceImpl.saveDrugData(drugData);

		assertNotNull(returnedDrugData);
	}

	/**
	 * Test method for
	 * {@link com.pms.schedulingservice.service.DrugDataServiceImpl#updateDrugData(com.pms.schedulingservice.entity.DrugData)}.
	 */
	@Test
	void testUpdateDrugData() {
		when(drugDataRepository.save(any())).thenReturn(drugData);
		DrugData returnedDrugData = drugDataServiceImpl.updateDrugData(drugData);

		assertNotNull(returnedDrugData);
	}

}
