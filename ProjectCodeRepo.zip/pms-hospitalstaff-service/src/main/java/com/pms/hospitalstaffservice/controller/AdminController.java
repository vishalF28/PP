package com.pms.hospitalstaffservice.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.hospitalstaffservice.model.GenericSuccessResponse;
import com.pms.hospitalstaffservice.model.HospitalStaffSignupRequest;
import com.pms.hospitalstaffservice.model.UserProfile;
import com.pms.hospitalstaffservice.service.AdminService;

@RestController
@RequestMapping("admin")
public class AdminController {

	private AdminService adminService;
	
	@Autowired
	public AdminController(AdminService adminService) {

		this.adminService = adminService;
	}
	
	@PostMapping("/create-hospitalstaff-profile")
	public ResponseEntity<GenericSuccessResponse> createHospitalStaffProfile(@RequestBody HospitalStaffSignupRequest hospitalStaffSignupRequest) {

		String message = adminService.createHospitalStaffProfile(hospitalStaffSignupRequest);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@GetMapping("/get-all-staff")
	public ResponseEntity<List<UserProfile>> getAllHospitalStaff() {
		return new ResponseEntity<List<UserProfile>>(adminService.getAllHospitalStaff(), HttpStatus.OK);
	}
	
	@GetMapping("/get-all-patient")
	public ResponseEntity<List<UserProfile>> getAllPatients() {
		return new ResponseEntity<List<UserProfile>>(adminService.getAllPatients(), HttpStatus.OK);
	}
	
	@PutMapping("/update-hospital-staff-status")
	public ResponseEntity<GenericSuccessResponse> updateUserStatus(@RequestParam String emailId, @RequestParam boolean status){
		String message = adminService.updateUserStatus(emailId, status);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@PutMapping("/update-patient-status")
	public ResponseEntity<GenericSuccessResponse> updatePatientStatus(@RequestParam String emailId, @RequestParam boolean status){
		String message = adminService.updatePatientStatus(emailId, status);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@GetMapping("/profile/{emailId}")
	public ResponseEntity<UserProfile> getAdminProfileDetails(@PathVariable String emailId) {
		adminService.getAdminProfileDetails(emailId);
		return new ResponseEntity<UserProfile>(adminService.getAdminProfileDetails(emailId), HttpStatus.OK);
	}
	
	@GetMapping("/get-count-by-role")
    public ResponseEntity<Long> getCountByRole(@RequestParam String role) {
        return new ResponseEntity<Long>(adminService.getCountByRole(role), HttpStatus.OK);
    }
	
	@GetMapping("/get-patient-count")
    public ResponseEntity<Long> getPatientCount() {
        return new ResponseEntity<Long>(adminService.getPatientCount(), HttpStatus.OK);
    }
	
	@GetMapping("/get-new-patient-count")
	public ResponseEntity<Long> getNewPatientCount() {
		return new ResponseEntity<Long>(adminService.getNewPatientCount(), HttpStatus.OK);
	}
	
	@PutMapping("/update-admin-profile")
	public ResponseEntity<GenericSuccessResponse> updateProfile(@RequestBody UserProfile userProfile) {
		String message = adminService.updateProfile(userProfile);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);	
	}
	
	@GetMapping("/get-all-physicians")
	public ResponseEntity<List<UserProfile>> getAllPhysicians() {
		return new ResponseEntity<List<UserProfile>>(adminService.getAllPhysicians(), HttpStatus.OK);
	}
	
	@GetMapping("/get-physican-count-by-speciality")
	public ResponseEntity<Map<String, Long>> getPhysicianCountBySpeiciality() {
		return new ResponseEntity<Map<String, Long>>(adminService.getPhysicianCountBySpeiciality(), HttpStatus.OK);
	}
	
	@GetMapping("/get-nurse-count-by-speciality")
	public ResponseEntity<Map<String, Long>> getNurseCountBySpeiciality() {
		return new ResponseEntity<Map<String, Long>>(adminService.getNurseCountBySpeiciality(), HttpStatus.OK);
	}
	
	@GetMapping("/get-all-physicians-and-nurses")
	public ResponseEntity<List<UserProfile>> getAllPhysiciansAndNurses() {
		return new ResponseEntity<List<UserProfile>>(adminService.getAllPhysiciansAndNurses(), HttpStatus.OK);
	}
}
