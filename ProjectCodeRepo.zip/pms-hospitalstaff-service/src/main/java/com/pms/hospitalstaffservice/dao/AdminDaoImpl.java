package com.pms.hospitalstaffservice.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pms.hospitalstaffservice.entity.HospitalStaff;
import com.pms.hospitalstaffservice.enums.Roles;
import com.pms.hospitalstaffservice.feignclient.PatientFeignClient;
import com.pms.hospitalstaffservice.model.Patient;
import com.pms.hospitalstaffservice.model.UserProfile;
import com.pms.hospitalstaffservice.repository.AdminRepository;

@Repository
public class AdminDaoImpl implements AdminDao{

	private AdminRepository adminRepository;

	private PatientFeignClient patientFeignClient;
	
	public AdminDaoImpl() {
	}
	
	@Autowired
	public AdminDaoImpl(AdminRepository adminRepository, PatientFeignClient patientFeignClient) {
		this.adminRepository =adminRepository;
		this.patientFeignClient = patientFeignClient;
	}
	
	@Override
	public HospitalStaff save(HospitalStaff hospitalStaff) {
		return adminRepository.save(hospitalStaff);
	}

	@Override
	public List<UserProfile> getAllHospitalStaff() {
		List<HospitalStaff> hospitalStaffs = adminRepository.findAll();
		List<UserProfile> staffs = new ArrayList<>();

		hospitalStaffs.stream().forEach(user -> {
			UserProfile profile = new UserProfile();
			BeanUtils.copyProperties(user, profile);
			profile.setFullName(user.getTitle() + " " + user.getFirstName() + " " + user.getLastName());
			staffs.add(profile);
		});
		return staffs;
	}

	@Override
	public List<UserProfile> getAllPatients() {
		List<Patient> patientList = patientFeignClient.getAllPatients().getBody();
		List<UserProfile> staffs = new ArrayList<>();
		patientList.stream().forEach(user -> {
			UserProfile profile = new UserProfile();
			BeanUtils.copyProperties(user, profile);
			profile.setFullName(user.getTitle() + " " + user.getFirstName() + " " + user.getLastName());
			staffs.add(profile);
		});
		return staffs;
	}

	@Override
	public void updateUserStatus(String emailId, boolean status) {
		HospitalStaff hospitalStaff = adminRepository.findByEmailId(emailId);
		Optional.of(hospitalStaff).ifPresent(user -> {
			user.setIsActive(status);
			adminRepository.save(user);
		});
	}

	@Override
	public UserProfile getAdminProfileDetails(String emailId) {
		System.out.println(emailId);
		UserProfile userProfile = new UserProfile();
		try {
		HospitalStaff hospitalStaff = adminRepository.findByEmailId(emailId);
		System.out.println(hospitalStaff);
		BeanUtils.copyProperties(hospitalStaff, userProfile);
		System.out.println(userProfile);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return userProfile;
	}

	@Override
	public Long getCountByRole(String role) {
		return adminRepository.countByRole(Roles.valueOf(role));
	}

	@Override
	public HospitalStaff updateProfile(HospitalStaff hospitalStaff) {
		return adminRepository.save(hospitalStaff);
	}

	@Override
	public HospitalStaff getHospitalStaffDetailById(String emailId) {
		return adminRepository.findByEmailId(emailId);
	}

	@Override
	public Map<String, Long> getPhysicianCountBySpeiciality() {
		List<HospitalStaff> hospitalStaffs = adminRepository.findByRole(Roles.PHYSICIAN);
		System.out.println(hospitalStaffs);
		Map<String, Long> specialityCount = new HashMap<>();
		for (HospitalStaff hospitalStaff : hospitalStaffs) {
			if(specialityCount.containsKey(hospitalStaff.getSpeciality())){
				Long count = specialityCount.get(hospitalStaff.getSpeciality());
				specialityCount.put(hospitalStaff.getSpeciality(), count+1);
			}
			else {
				specialityCount.put(hospitalStaff.getSpeciality(), 1L);
			}
		}
		
		return specialityCount;
	}

	@Override
	public Map<String, Long> getNurseCountBySpeiciality() {
		List<HospitalStaff> hospitalStaffs = adminRepository.findByRole(Roles.NURSE);
		Map<String, Long> specialityCount = new HashMap<>();
		for (HospitalStaff hospitalStaff : hospitalStaffs) {
			if(specialityCount.containsKey(hospitalStaff.getSpeciality())){
				Long count = specialityCount.get(hospitalStaff.getSpeciality());
				specialityCount.put(hospitalStaff.getSpeciality(), count+1);
			}
			else {
				specialityCount.put(hospitalStaff.getSpeciality(), 1L);
			}
		}
		return specialityCount;
	}

}
