package com.pms.hospitalstaffservice.feignclient;

import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

@Component public class AuthenticationFeignClientFallBack implements FallbackFactory<AuthenticationFeignClient>{

	@Override public AuthenticationFeignClient create(Throwable cause) { return null; }


}
