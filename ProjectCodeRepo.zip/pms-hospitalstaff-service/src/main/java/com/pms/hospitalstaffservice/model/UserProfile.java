
package com.pms.hospitalstaffservice.model;

import java.util.Date;

import com.pms.hospitalstaffservice.enums.Roles;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class UserProfile {
	
	private Long userId;
	
	private String title;
	
	private String firstName;
	
	private String lastName;
	
	private Date birthDate;

	private String contact;

	private String fullName;
	
	private String emailId;

	private Boolean isActive;
	
	private Roles role;
	
	private String speciality;

}
