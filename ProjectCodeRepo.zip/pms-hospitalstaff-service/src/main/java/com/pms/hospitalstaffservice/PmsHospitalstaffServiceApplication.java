package com.pms.hospitalstaffservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
public class PmsHospitalstaffServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PmsHospitalstaffServiceApplication.class, args);
	}

}
