package com.pms.hospitalstaffservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pms.hospitalstaffservice.entity.HospitalStaff;
import com.pms.hospitalstaffservice.enums.Roles;

@Repository
public interface AdminRepository extends JpaRepository<HospitalStaff, Long>{

	public HospitalStaff findByEmailId(String emailId);
	
	public Long countByRole(Roles role);

	public List<HospitalStaff> findByRole(Roles role);
}
