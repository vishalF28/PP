package com.pms.hospitalstaffservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DashboardGraph {
	
	private String name;
	
	private Long count;
}
