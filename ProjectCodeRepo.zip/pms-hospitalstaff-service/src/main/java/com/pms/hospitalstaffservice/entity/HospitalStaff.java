package com.pms.hospitalstaffservice.entity;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import com.pms.hospitalstaffservice.enums.Gender;
import com.pms.hospitalstaffservice.enums.Roles;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@Entity
@DynamicUpdate
@Table(name = "pms_hospital_staff", schema = "pms_authorization")
public class HospitalStaff extends Auditable<String> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "staff_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "hospital_staff_seq_generator")
	@SequenceGenerator(name="hospital_staff_seq_generator", sequenceName = "pms_authorization.pms_hospital_staff_seq", allocationSize=1)
	private Long staffId;
	
	@Column(name = "user_id")
	private Long userId;

	@Column(name="title")
	private String title;

	@Column(name = "birth_date")
	private Date birthDate;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Enumerated(EnumType.STRING)
	private Roles role;

	@Column(name="contact")
	private String contact;
	
	@Column(name="speciality")
	private String speciality;
	
	@Column(name="gender")
	@Enumerated(EnumType.STRING)
	private Gender gender;

}