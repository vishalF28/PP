package com.pms.hospitalstaffservice.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Patient implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long patientId;
 
	private Long userId;
	
	private String title;

	private Date birthDate;

	private String emailId;

	private String firstName;

	private String lastName;

	private String contact;
	
	private Boolean isActive;

}
