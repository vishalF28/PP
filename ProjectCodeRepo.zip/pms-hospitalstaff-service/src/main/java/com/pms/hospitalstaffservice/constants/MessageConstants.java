package com.pms.hospitalstaffservice.constants;

public class MessageConstants {

	public static final String PATIENT_PROFILE_SAVE_SUCCESS = "Patient profile details saved successfully";
	
	public static final String INTERNAL_SERVER_ERROR = "Some error occured. Please contact system administrator.";

	public static final String ALLERGY_DELETED_SUCCESS = "Allergy deleted successfully";

	public static final String DIAGNOSIS_DELETED_SUCCESS = "Diagnosis deleted successfully";

	public static final String DRUG_DELETED_SUCCESS = "Drug deleted successfully";

	public static final String PROCEDURE_DELETED_SUCCESS = "Procedure deleted successfully";

	public static final String HOSPITAL_STAFF_PROFILE_SAVE_SUCCESS = "User profile details saved successfully";

	public static final String ADMIN_PROFILE_UPDATE_SUCCESS = "Admin profile updated.";

}
