package com.pms.hospitalstaffservice.feignclient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pms.hospitalstaffservice.model.GenericSuccessResponse;
import com.pms.hospitalstaffservice.model.Patient;


@FeignClient(name = "patient-service", url = "http://localhost:9094",fallback = PatientFeignClientFallBack.class)
public interface PatientFeignClient {

	@RequestMapping("patient/get-patients")
	public ResponseEntity<List<Patient>> getAllPatients();
	
	@PutMapping("patient/update-patient-status")
	public ResponseEntity<GenericSuccessResponse> updatePatientStatus(@RequestParam("emailId") String emailId, 
			@RequestParam("status") boolean status);

	@GetMapping("patient/get-patient-count")
	public ResponseEntity<Long> getPatientCount();
	
	@GetMapping("patient/get-new-patient-count")
	public ResponseEntity<Long> getNewPatientCount();
}
