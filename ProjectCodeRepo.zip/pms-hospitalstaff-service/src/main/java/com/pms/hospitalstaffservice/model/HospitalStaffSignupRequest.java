package com.pms.hospitalstaffservice.model;

import java.sql.Date;

import com.pms.hospitalstaffservice.enums.Roles;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HospitalStaffSignupRequest {

	private Long userId;

	private String title;

	private String username;

	private String firstName;

	private String lastName;

	private String emailId;

	private Date birthDate;

	private String contact;
	
	private Roles role;
	
	private String speciality;
	
	private String gender;

}
