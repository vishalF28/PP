package com.pms.hospitalstaffservice.service;

import java.util.List;
import java.util.Map;

import com.pms.hospitalstaffservice.model.HospitalStaffSignupRequest;
import com.pms.hospitalstaffservice.model.UserProfile;

public interface AdminService {

	public String createHospitalStaffProfile(HospitalStaffSignupRequest hospitalStaffSignupRequest);

	public List<UserProfile> getAllHospitalStaff();

	public List<UserProfile> getAllPatients();

	public String updateUserStatus(String emailId, boolean status);

	public String updatePatientStatus(String emailId, boolean status);

	public UserProfile getAdminProfileDetails(String emailId);

	public Long getCountByRole(String role);

	public Long getPatientCount();

	public Long getNewPatientCount();

	public String updateProfile(UserProfile userProfile);

	public List<UserProfile> getAllPhysicians();

	public Map<String, Long> getPhysicianCountBySpeiciality();

	public Map<String, Long> getNurseCountBySpeiciality();

	public List<UserProfile> getAllPhysiciansAndNurses();

}
