package com.pms.hospitalstaffservice.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.pms.hospitalstaffservice.model.GenericSuccessResponse;
import com.pms.hospitalstaffservice.model.UserProfile;


@FeignClient(name = "authentication-service", url = "http://localhost:9091",fallback = AuthenticationFeignClientFallBack.class)
public interface AuthenticationFeignClient {

	@PutMapping("authentication/update-user-status")
	public ResponseEntity<GenericSuccessResponse> updateUserStatus(@RequestParam("emailId") String emailId,
			@RequestParam("status") boolean status);

	@PostMapping("authentication/update-user-profile")
	public ResponseEntity<GenericSuccessResponse> updateUserProfile(@RequestBody UserProfile userProfile);
}
