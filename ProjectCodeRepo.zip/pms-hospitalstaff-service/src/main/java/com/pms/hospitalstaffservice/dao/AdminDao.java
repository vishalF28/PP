package com.pms.hospitalstaffservice.dao;

import java.util.List;
import java.util.Map;

import com.pms.hospitalstaffservice.entity.HospitalStaff;
import com.pms.hospitalstaffservice.model.UserProfile;

public interface AdminDao {

	public HospitalStaff save(HospitalStaff hospitalStaff);

	public List<UserProfile> getAllHospitalStaff();

	public List<UserProfile> getAllPatients();

	public void updateUserStatus(String emailId, boolean status);

	public UserProfile getAdminProfileDetails(String emailId);

	public Long getCountByRole(String role);

	public HospitalStaff updateProfile(HospitalStaff hospitalStaff);

	public HospitalStaff getHospitalStaffDetailById(String emailId);

	public Map<String, Long> getPhysicianCountBySpeiciality();

	public Map<String, Long> getNurseCountBySpeiciality();

}
