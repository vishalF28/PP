package com.pms.hospitalstaffservice.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import com.pms.hospitalstaffservice.constants.MessageConstants;
import com.pms.hospitalstaffservice.dao.AdminDao;
import com.pms.hospitalstaffservice.entity.HospitalStaff;
import com.pms.hospitalstaffservice.enums.Gender;
import com.pms.hospitalstaffservice.enums.Roles;
import com.pms.hospitalstaffservice.feignclient.AuthenticationFeignClient;
import com.pms.hospitalstaffservice.feignclient.PatientFeignClient;
import com.pms.hospitalstaffservice.model.GenericSuccessResponse;
import com.pms.hospitalstaffservice.model.HospitalStaffSignupRequest;
import com.pms.hospitalstaffservice.model.MailRequest;
import com.pms.hospitalstaffservice.model.UserProfile;
import reactor.core.publisher.Mono;

@Service
public class AdminServiceImpl implements AdminService{

	AdminDao adminDao;
	
	AuthenticationFeignClient authenticationFeignClient;
	
	PatientFeignClient patientFeignClient;
	
	private WebClient webClient;
	
	public AdminServiceImpl() {
	}
	
	@Autowired
	public AdminServiceImpl(AdminDao adminDao, AuthenticationFeignClient authenticationFeignClient, 
			PatientFeignClient patientFeignClient, WebClient webClient) {
		this.adminDao = adminDao;
		this.authenticationFeignClient = authenticationFeignClient;
		this.patientFeignClient = patientFeignClient;
		this.webClient = webClient;
	}
	
	@Override
	public String createHospitalStaffProfile(HospitalStaffSignupRequest hospitalStaffSignupRequest) {
		HospitalStaff hospitalStaff = new HospitalStaff();
		
		BeanUtils.copyProperties(hospitalStaffSignupRequest, hospitalStaff);    
        try
        {
        	hospitalStaff.setGender(Gender.valueOf(hospitalStaffSignupRequest.getGender()));
        	hospitalStaff.setIsActive(true);
        	adminDao.save(hospitalStaff);
        }
        catch (Exception e) 
        {
        	throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);
        }
		return MessageConstants.HOSPITAL_STAFF_PROFILE_SAVE_SUCCESS;
	}

	@Override
	public List<UserProfile> getAllHospitalStaff() {

		try
		{
			return adminDao.getAllHospitalStaff();
		}
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);		
		}
	}

	@Override
	public List<UserProfile> getAllPatients() {
		try
		{
			return adminDao.getAllPatients();
		}
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);		
		}
	}

	@Override
	public String updateUserStatus(String emailId, boolean status) {
		MailRequest accountStatusMailRequest = null;
		try
		{
			adminDao.updateUserStatus(emailId, status);
			accountStatusMailRequest = new MailRequest();
			accountStatusMailRequest.setEmailId(emailId);
			ResponseEntity<GenericSuccessResponse> response = authenticationFeignClient.updateUserStatus(emailId, status);
			if(status)
			{
				sendAccountActivationMail(accountStatusMailRequest);
			}
			else
			{
				sendAccountDeactivationMail(accountStatusMailRequest);
			}
			return response.getBody().getMessage();
		}
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);		
		}
	}

	@Override
	public String updatePatientStatus(String emailId, boolean status) {
		MailRequest accountStatusMailRequest = null;
		try
		{
			patientFeignClient.updatePatientStatus(emailId, status);
			accountStatusMailRequest = new MailRequest();
			accountStatusMailRequest.setEmailId(emailId);
			ResponseEntity<GenericSuccessResponse> response = authenticationFeignClient.updateUserStatus(emailId, status);
			if(status)
			{
				sendAccountActivationMail(accountStatusMailRequest);
			}
			else
			{
				sendAccountDeactivationMail(accountStatusMailRequest);
			}
			return response.getBody().getMessage();
		}
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);		
		}
	}

	@Override
	public UserProfile getAdminProfileDetails(String emailId) {
		return adminDao.getAdminProfileDetails(emailId);
	}

	@Override
	public Long getCountByRole(String role) {
		return adminDao.getCountByRole(role);
	}

	@Override
	public Long getPatientCount() {
		Long patientCount = 0L;
		try
		{
		 	patientCount= patientFeignClient.getPatientCount().getBody();
		}
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);		
		}
		return patientCount;
	}

	@Override
	public Long getNewPatientCount() {
		Long newPatientCount = 0L;
		try
		{
			newPatientCount= patientFeignClient.getNewPatientCount().getBody();
		}
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);		
		}
		return newPatientCount;
	}

	@Override
	public String updateProfile(UserProfile userProfile) {
		HospitalStaff hospitalStaff = adminDao.getHospitalStaffDetailById(userProfile.getEmailId());
		BeanUtils.copyProperties(userProfile, hospitalStaff);
		try {
			hospitalStaff = adminDao.updateProfile(hospitalStaff);
			authenticationFeignClient.updateUserProfile(userProfile);
		} catch (Exception e) {
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);	
		}
		return MessageConstants.ADMIN_PROFILE_UPDATE_SUCCESS;
	}

	@Override
	public List<UserProfile> getAllPhysicians() {
		try
		{
			return adminDao.getAllHospitalStaff().stream().filter(user -> user.getRole().name().equalsIgnoreCase(Roles.PHYSICIAN.name())).collect(Collectors.toList());
		}
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);		
		}
	}
	
	private void sendAccountActivationMail(MailRequest accountStatusMailRequest) {
		webClient.post()
        .uri("/sendmail/account-activation-mail")
        .body(Mono.just(accountStatusMailRequest), MailRequest.class)
        .exchange()
        .doOnError(error -> error.printStackTrace())
        .subscribe();
	}
	
	private void sendAccountDeactivationMail(MailRequest accountStatusMailRequest) {
		webClient.post()
        .uri("/sendmail/account-deactivation-mail")
        .body(Mono.just(accountStatusMailRequest), MailRequest.class)
        .exchange()
        .doOnError(error -> error.printStackTrace())
        .subscribe();
	}

	@Override
	public Map<String, Long> getPhysicianCountBySpeiciality() {
		return adminDao.getPhysicianCountBySpeiciality();
	}

	@Override
	public Map<String, Long> getNurseCountBySpeiciality() {
		return adminDao.getNurseCountBySpeiciality();
	}

	@Override
	public List<UserProfile> getAllPhysiciansAndNurses() {
		try
		{
			return adminDao.getAllHospitalStaff().stream().filter(user -> user.getRole().name().equalsIgnoreCase(Roles.PHYSICIAN.name()) || user.getRole().name().equalsIgnoreCase(Roles.NURSE.name())).collect(Collectors.toList());
		}
		catch (Exception e) 
		{
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);		
		}
	}


}
