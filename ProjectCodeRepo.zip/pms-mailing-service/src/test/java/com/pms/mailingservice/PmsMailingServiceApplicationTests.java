package com.pms.mailingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmsMailingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
