package com.pms.mailingservice.service;

import java.io.File;
import java.nio.file.Files;
import java.text.SimpleDateFormat;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.pms.mailingservice.constants.MessageConstants;
import com.pms.mailingservice.exception.MailNotSentException;
import com.pms.mailingservice.model.MailRequest;

/**
 * @author SatpalC The Class EmailServiceImpl.
 */

@Service
public class EmailServiceImpl implements EmailService {

	private JavaMailSender mailSender;

	/**
	 * Instantiates a new email service impl.
	 *
	 * @param mailSender the mail sender
	 */
	@Autowired
	public EmailServiceImpl(JavaMailSender mailSender) {
		super();
		this.mailSender = mailSender;
}

	@Override
	public String forgotPasswordSendMail(MailRequest mailRequest) {
		String toEmailId = mailRequest.getEmailId();
		String defaultPassword = mailRequest.getDefaultPassword();
		String subject = "PMS One Time Password";
		String content = "";
		File file;
		try 
		{
			file = ResourceUtils.getFile("classpath:html/ForgetPasswordEmailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));

			content = content.replace("#defaultPassword", defaultPassword);

			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	@Override
	public void sendMail(String subject, String body, String toEmail) throws MessagingException {
		MimeMessage mimeMessage = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, "utf-8");
		helper.setText(body, true); // Use this or above line.
		helper.setTo(toEmail);
		helper.setSubject(subject);
		mailSender.send(mimeMessage);
	}

	@Override
	public String patientWelcomeSendMail(MailRequest mailRequest) {
		String toEmailId = mailRequest.getEmailId();
		String subject = "Welcome to PMS";
		String content = "";
		File file;
		try {
			file = ResourceUtils.getFile("classpath:html/PatientWelcomeMailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));

			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	@Override
	public String providerWelcomeSendMail(MailRequest mailRequest) {
		String toEmailId = mailRequest.getEmailId();
		String defaultPassword = mailRequest.getDefaultPassword();
		String subject = "PMS One Time Password";
		String content = "";
		File file;
		try {
			file = ResourceUtils.getFile("classpath:html/ProviderWelcomeMailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));
			content = content.toString().replace("#defaultPassword", defaultPassword);

			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	@Override
	public String sendAccountActivationMail(MailRequest mailRequest) {
		String toEmailId = mailRequest.getEmailId();
		String subject = "PMS Account Activated Successfully";
		String content = "";
		File file;
		try {
			file = ResourceUtils.getFile("classpath:html/AccountActivationMailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));

			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	@Override
	public String sendAccountDeactivationMail(MailRequest mailRequest) {
		String toEmailId = mailRequest.getEmailId();
		String subject = "PMS Account Deactivated";
		String content = "";
		File file;
		try {
			file = ResourceUtils.getFile("classpath:html/AccountDeactivationMailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));

			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	@Override
	public String appointmentConfirmationMail(MailRequest mailRequest) {
		sendAppointmentConfirmationToPatient(mailRequest);
		sendAppointmentConfirmationToPhysician(mailRequest);
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String sendAppointmentConfirmationToPhysician(MailRequest mailRequest) {
		String toEmailId = mailRequest.getPhysicianEmailId();
		String subject = "PMS Appointment Confirmed";
		String content = "";
		File file;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDateOfAppointment = formatter.format(mailRequest.getDateOfAppointment());
		try {
			file = ResourceUtils.getFile("classpath:html/PhysicianAppointmentConfirmationEmailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));
			content = content.toString().replace("#appointmentId", mailRequest.getAppointmentId().toString());
			content = content.toString().replace("#dateOfAppointment", strDateOfAppointment);
			content = content.toString().replace("#timeOfAppointment", mailRequest.getTimeOfAppointment().getValue());
			content = content.toString().replace("#patientName", mailRequest.getPatientName());
			
			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String sendAppointmentConfirmationToPatient(MailRequest mailRequest) {
		String toEmailId = mailRequest.getPatientEmailId();
		String subject = "PMS Appointment Confirmed";
		String content = "";
		File file;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDateOfAppointment = formatter.format(mailRequest.getDateOfAppointment());
		try {
			file = ResourceUtils.getFile("classpath:html/PatientAppointmentConfirmationEmailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));
			content = content.toString().replace("#appointmentId", mailRequest.getAppointmentId().toString());
			content = content.toString().replace("#dateOfAppointment", strDateOfAppointment);
			content = content.toString().replace("#timeOfAppointment", mailRequest.getTimeOfAppointment().getValue());
			content = content.toString().replace("#physicianName", mailRequest.getPhysicianName());
			
			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	@Override
	public String appointmentRescheduleMail(MailRequest mailRequest) {
		sendAppointmentRescheduleMailToPatient(mailRequest);
		sendAppointmentRescheduleMailToPhysician(mailRequest);
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String sendAppointmentRescheduleMailToPhysician(MailRequest mailRequest) {
		String toEmailId = mailRequest.getPhysicianEmailId();
		String subject = "PMS Appointment Rescheduled";
		String content = "";
		File file;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDateOfAppointment = formatter.format(mailRequest.getDateOfAppointment());
		try {
			file = ResourceUtils.getFile("classpath:html/PhysicianAppointmentRescheduleEmailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));
			content = content.toString().replace("#appointmentId", mailRequest.getAppointmentId().toString());
			content = content.toString().replace("#dateOfAppointment", strDateOfAppointment);
			content = content.toString().replace("#timeOfAppointment", mailRequest.getTimeOfAppointment().getValue());
			content = content.toString().replace("#patientName", mailRequest.getPatientName());
			
			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String sendAppointmentRescheduleMailToPatient(MailRequest mailRequest) {
		String toEmailId = mailRequest.getPatientEmailId();
		String subject = "PMS Appointment Rescheduled";
		String content = "";
		File file;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDateOfAppointment = formatter.format(mailRequest.getDateOfAppointment());
		try {
			file = ResourceUtils.getFile("classpath:html/PatientAppointmentRescheduleEmailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));
			content = content.toString().replace("#appointmentId", mailRequest.getAppointmentId().toString());
			content = content.toString().replace("#dateOfAppointment", strDateOfAppointment);
			content = content.toString().replace("#timeOfAppointment", mailRequest.getTimeOfAppointment().getValue());
			content = content.toString().replace("#physicianName", mailRequest.getPhysicianName());
			
			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	@Override
	public String appointmentDeletionMail(MailRequest mailRequest) {
		sendAppointmentDeletionMailToPatient(mailRequest);
		sendAppointmentDeletionMailToPhysician(mailRequest);
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String sendAppointmentDeletionMailToPhysician(MailRequest mailRequest) {
		String toEmailId = mailRequest.getPhysicianEmailId();
		String subject = "PMS Appointment Cancelled";
		String content = "";
		File file;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDateOfAppointment = formatter.format(mailRequest.getDateOfAppointment());
		try {
			file = ResourceUtils.getFile("classpath:html/PhysicianAppointmentDeletionEmailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));
			content = content.toString().replace("#appointmentId", mailRequest.getAppointmentId().toString());
			content = content.toString().replace("#dateOfAppointment", strDateOfAppointment);
			content = content.toString().replace("#timeOfAppointment", mailRequest.getTimeOfAppointment().getValue());
			content = content.toString().replace("#patientName", mailRequest.getPatientName());
			
			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String sendAppointmentDeletionMailToPatient(MailRequest mailRequest) {
		String toEmailId = mailRequest.getPatientEmailId();
		String subject = "PMS Appointment Cancelled";
		String content = "";
		File file;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDateOfAppointment = formatter.format(mailRequest.getDateOfAppointment());
		try {
			file = ResourceUtils.getFile("classpath:html/PatientAppointmentDeletionEmailTemplate.html");
			// Read File Content
			content = new String(Files.readAllBytes(file.toPath()));
			content = content.toString().replace("#appointmentId", mailRequest.getAppointmentId().toString());
			content = content.toString().replace("#dateOfAppointment", strDateOfAppointment);
			content = content.toString().replace("#timeOfAppointment", mailRequest.getTimeOfAppointment().getValue());
			content = content.toString().replace("#physicianName", mailRequest.getPhysicianEmailId());
			
			sendMail(subject, content, toEmailId);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MailNotSentException(MessageConstants.MAIL_NOT_SENT);
		}
		return MessageConstants.MAIL_SENT_SUCCESS;
	}
}