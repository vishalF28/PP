package com.pms.mailingservice.constants;

public class MessageConstants {

	public static final String INTERNAL_SERVER_ERORR = "Some error occured. Please contact system administrator.";
	public static final String MAIL_NOT_SENT = "Some error occured while sending mail";
	public static final String MAIL_SENT_SUCCESS = "Mail has been sent successfully";

}
