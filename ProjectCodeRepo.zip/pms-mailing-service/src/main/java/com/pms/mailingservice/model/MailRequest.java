package com.pms.mailingservice.model;

import java.util.Date;

import com.pms.mailingservice.enums.TimingSlots;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The Class MailRequest.
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MailRequest {

	String emailId;
	
	String defaultPassword;

	private Long appointmentId;
	
	private Date dateOfAppointment;
	
	private TimingSlots timeOfAppointment;
	
	private String physicianName;
	
	private String patientName;
	
	private String physicianEmailId; 
	
	private String patientEmailId;
}