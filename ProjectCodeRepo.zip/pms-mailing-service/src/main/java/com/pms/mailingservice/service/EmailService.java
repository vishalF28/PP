package com.pms.mailingservice.service;

import javax.mail.MessagingException;

import com.pms.mailingservice.model.MailRequest;


/**
 * The Interface EmailService.
 */
public interface EmailService {

	/**
	 * ForgotPasswordSendMail mail.
	 *
	 * @param mailRequest the mail request
	 * @return the mail response
	 */
	public String forgotPasswordSendMail(MailRequest mailRequest);

	public void sendMail(String subject, String body, String toEmail) throws MessagingException;

	public String patientWelcomeSendMail(MailRequest mailRequest);

	public String providerWelcomeSendMail(MailRequest mailRequest);

	public String sendAccountActivationMail(MailRequest mailRequest);

	public String sendAccountDeactivationMail(MailRequest mailRequest);

	public String appointmentConfirmationMail(MailRequest mailRequest);

	public String appointmentRescheduleMail(MailRequest mailRequest);

	public String appointmentDeletionMail(MailRequest mailRequest);

}