package com.pms.mailingservice.controller;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pms.mailingservice.model.MailRequest;
import com.pms.mailingservice.service.EmailService;


/**
 * The Class MailingController.
 */
@RestController
@RequestMapping("/sendmail")
public class MailingController {

	EmailService emailService;

	/**
	 * Instantiates a new mailing controller.
	 *
	 * @param emailService the email service
	 */
	@Autowired
	public MailingController(EmailService emailService) {
		super();
		this.emailService = emailService;
	}

	/**
	 * Forgot password mail.
	 *
	 * @param objMailRequest the obj mail request
	 * @return the mail response
	 * @throws MessagingException the messaging exception
	 */
	@RequestMapping("/forgotpassword")
	public ResponseEntity<String> forgotPasswordMail(@RequestBody MailRequest mailRequest)
			throws MessagingException 
	{
		String emailResponse = emailService.forgotPasswordSendMail(mailRequest);
		return new ResponseEntity<String>(emailResponse, HttpStatus.OK);
	}
	
	/**
	 * Patient welcome mail.
	 *
	 * @param objMailRequest the obj mail request
	 * @return the mail response
	 * @throws MessagingException the messaging exception
	 */
	@RequestMapping("/patient-signup")
	public ResponseEntity<String> patientWelcomeMail(@RequestBody MailRequest mailRequest)
			throws MessagingException {
		String emailResponse = emailService.patientWelcomeSendMail(mailRequest);
		return new ResponseEntity<String>(emailResponse, HttpStatus.OK);
	}

	/**
	 * Provider welcome mail.
	 *
	 * @param objMailRequest the obj mail request
	 * @return the mail response
	 * @throws MessagingException the messaging exception
	 */
	@RequestMapping("/provider-registration")
	public ResponseEntity<String> providerWelcomeMail(@RequestBody MailRequest mailRequest)
			throws MessagingException {
		String emailResponse = emailService.providerWelcomeSendMail(mailRequest);
		return new ResponseEntity<String>(emailResponse, HttpStatus.OK);
	}
	
	@RequestMapping("/account-activation-mail")
	public ResponseEntity<String> sendAccountActivationMail(@RequestBody MailRequest mailRequest)
			throws MessagingException {
		String emailResponse = emailService.sendAccountActivationMail(mailRequest);
		return new ResponseEntity<String>(emailResponse, HttpStatus.OK);
	}
	
	@RequestMapping("/account-deactivation-mail")
	public ResponseEntity<String> sendAccountDeactivationMail(@RequestBody MailRequest mailRequest)
			throws MessagingException {
		String emailResponse = emailService.sendAccountDeactivationMail(mailRequest);
		return new ResponseEntity<String>(emailResponse, HttpStatus.OK);
	}
	
	@RequestMapping("/appointment-confirmation")
	public ResponseEntity<String> appointmentConfirmationMail(@RequestBody MailRequest mailRequest)
			throws MessagingException {
		String emailResponse = emailService.appointmentConfirmationMail(mailRequest);
		return new ResponseEntity<String>(emailResponse, HttpStatus.OK);
	}
	
	@RequestMapping("/appointment-reschedule")
	public ResponseEntity<String> appointmentRescheduleMail(@RequestBody MailRequest mailRequest)
			throws MessagingException {
		String emailResponse = emailService.appointmentRescheduleMail(mailRequest);
		return new ResponseEntity<String>(emailResponse, HttpStatus.OK);
	}
	
	@RequestMapping("/appointment-delete")
	public ResponseEntity<String> appointmentDeletionMail(@RequestBody MailRequest mailRequest)
			throws MessagingException {
		String emailResponse = emailService.appointmentDeletionMail(mailRequest);
		return new ResponseEntity<String>(emailResponse, HttpStatus.OK);
	}
}
