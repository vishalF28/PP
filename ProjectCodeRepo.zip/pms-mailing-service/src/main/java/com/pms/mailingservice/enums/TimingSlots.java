package com.pms.mailingservice.enums;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;

@Getter
public enum TimingSlots {
	
	TIMINGSLOT1("9:00 AM To 9:30 AM"),
	TIMINGSLOT2("9:30 AM To 10:00 AM"),
	TIMINGSLOT3("10:00 AM To 10:30 AM"),
	TIMINGSLOT4("10:30 AM To 11:00 AM"),
	TIMINGSLOT5("11:00 AM To 11:30 AM"),
	TIMINGSLOT6("11:30 AM To 12:00 PM"),
	TIMINGSLOT7("12:00 PM To 12:30 PM"),
	TIMINGSLOT8("12:30 PM To 1:00 PM"),
	TIMINGSLOT9("3:00 PM To 3:30 PM"),
	TIMINGSLOT10("3:30 PM To 4:00 PM"),
	TIMINGSLOT11("4:00 PM To 4:30 PM"),
	TIMINGSLOT12("4:30 PM To 5:00 PM"),
	TIMINGSLOT13("5:00 PM To 5:30 PM"),
	TIMINGSLOT14("5:30 PM To 6:00 PM"),
	TIMINGSLOT15("6:00 PM To 6:30 PM"),
	TIMINGSLOT16("6:30 PM To 7:00 PM"),
	TIMINGSLOT17("7:00 PM To 7:30 PM"),
	TIMINGSLOT18("7:30 PM To 8:00 PM");
	
	private String timings;
	
	TimingSlots(String timings) {
		this.timings = timings;
	}

	public String getValue() {
		return timings;
	}
	
	public static List<TimingSlots> findTimingSlotsForBreak() {
		List<TimingSlots> timingSlots = new ArrayList<TimingSlots>();
		for(TimingSlots timingSlot : values()) 
		{
			timingSlots.add(timingSlot);
			if(getById("12:30 PM To 1:00 PM").equals(timingSlot))
			{
				break;
			}
		}
		return timingSlots;
	}
	
	public static TimingSlots getById(String id) {
	    for(TimingSlots timingSlot : values()) 
	    {
	        if(timingSlot.timings.equals(id)) 
	        	return timingSlot;
	    }
	    return null;
	}

	public static List<TimingSlots> findTimingSlotsForRegularTime(String maxTimeSlot) {
		List<TimingSlots> timingSlots = new ArrayList<TimingSlots>();
		for(TimingSlots timingSlot : values()) 
		{
			timingSlots.add(timingSlot);
			if(getById(maxTimeSlot).equals(timingSlot))
			{
				break;
			}
		}
		return timingSlots;
	}
	
	public static List<TimingSlots> findTimingSlotsForEOD() {
		List<TimingSlots> timingSlots = new ArrayList<TimingSlots>();
		for(TimingSlots timingSlot : values()) 
		{
			timingSlots.add(timingSlot);
			if(getById("7:30 PM To 8:00 PM").equals(timingSlot))
			{
				break;
			}
		}
		return timingSlots;
	}
	
}
