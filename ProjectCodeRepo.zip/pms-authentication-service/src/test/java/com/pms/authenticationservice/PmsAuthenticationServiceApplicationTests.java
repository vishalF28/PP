package com.pms.authenticationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmsAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
