/**
 * 
 */
package com.pms.authenticationservice.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;

import com.pms.authenticationservice.entity.User;
import com.pms.authenticationservice.enums.Roles;
import com.pms.authenticationservice.repository.UserRepository;

/**
 * @author SatpalC
 *
 */
class UserDaoImplUnitTest {

	@Mock
	private UserRepository userRepository;

	@InjectMocks
	private UserDaoImpl userDaoImpl;

	private User user;
	@Autowired
	private Roles role;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		user = new User();
		user.setUserId(1001L);
		user.setEmailId("satpal.chhabra@citiustech.com");
		user.setFirstName("Satpal Singh");
		user.setLastName("Chhabra");
		user.setIsActive(true);
		user.setTitle("Mr.");
		user.setRole(role.ADMINISTRATOR);
		user.setPassword("Admin@123");
	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.dao.UserDaoImpl#checkValidUserName(java.lang.String)}.
	 */
	@Test
	@DisplayName("check CheckValidUserName return object values are same as passes value")
	void testCheckValidUserName() {

		// Given Value
		String emailId = "satpal.chhabra@citiustech.com";
		// mock the behavior of checkValidUserName()
		when(userRepository.findByEmailId(anyString())).thenReturn(user);
		// execute
		User returnUser = userDaoImpl.checkValidUserName(emailId);
		// assertion
		assertEquals(emailId, returnUser.getEmailId());

	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.dao.UserDaoImpl#checkValidUserName(java.lang.String)}.
	 */
	@Test
	@DisplayName("check CheckValidUserName return object is not null")
	void test_CheckValidUserName_return_obj_notNull() {
		// Given Value
		String emailId = "satpal.chhabra@citiustech.com";
		// mock the behavior of checkValidUserName()
		when(userRepository.findByEmailId(anyString())).thenReturn(user);
		// execute
		User returnUser = userDaoImpl.checkValidUserName(emailId);
		// assertion
		assertNotNull(returnUser);

	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.dao.UserDaoImpl#saveUser(com.pms.authenticationservice.entity.User)}.
	 */
	@Test
	@DisplayName("test saveUser is saved successfully return the same user")
	void testSaveUser_return_same_user() {
		user.setUserId(null);
		when(userRepository.save(anyObject())).thenReturn(user);
		User returnuser = userDaoImpl.saveUser(user);
		assertEquals(user.getEmailId(), returnuser.getEmailId());

	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.dao.UserDaoImpl#saveUser(com.pms.authenticationservice.entity.User)}.
	 */
	@Test
	void testSaveUser_return_user_notNull() {

		when(userRepository.save(anyObject())).thenReturn(user);
		User returnuser = userDaoImpl.saveUser(user);
		assertNotNull(returnuser);

	}

}
