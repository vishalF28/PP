/**
 * 
 */
package com.pms.authenticationservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyObject;
import com.pms.authenticationservice.constants.MessageConstants;
import com.pms.authenticationservice.dao.UserDao;
import com.pms.authenticationservice.entity.User;
import com.pms.authenticationservice.enums.Roles;
import com.pms.authenticationservice.feignclient.HospitalStaffFeignClient;
import com.pms.authenticationservice.feignclient.KeycloakFeignClient;
import com.pms.authenticationservice.feignclient.PatientFeignClient;
import com.pms.authenticationservice.model.ChangePasswordRequest;

/**
 * @author SatpalC
 *
 */
class AuthenticationServiceImplUnitTest {

	@Mock
	private KeycloakFeignClient keycloakFeignClient;
	@Mock
	private PatientFeignClient patientFeignClient;
	@Mock
	private HospitalStaffFeignClient hospitalStaffFeignClient;
	@Mock
	private WebClient webClient;
	@Mock
	private UserDao userDao;
	@InjectMocks
	private AuthenticationServiceImpl authenticationServiceImpl;
    private User user;
	@Autowired
	private Roles role;
	@Autowired
	private MessageConstants messageConstants;
	
	ChangePasswordRequest changePasswordRequest;

	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		user = new User();
		user.setUserId(1001L);
		user.setEmailId("satpal.chhabra@citiustech.com");
		user.setFirstName("Satpal Singh");
		user.setLastName("Chhabra");
		user.setIsActive(true);
		user.setTitle("Mr.");
		user.setRole(role.ADMINISTRATOR);
		user.setPassword("Admin@123");

	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.service.AuthenticationServiceImpl#loginUser(com.pms.authenticationservice.model.LoginRequest)}.
	 */
	@Test
	void testLoginUser() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.service.AuthenticationServiceImpl#changePassword(com.pms.authenticationservice.model.ChangePasswordRequest)}.
	 */
	@Test
	void testChangePassword() {
		// Given Object
		changePasswordRequest = new ChangePasswordRequest();
		changePasswordRequest.setEmailId("satpal.chhabra@citiustech.com");
		changePasswordRequest.setNewPassword("Admin@1234");

		// mock the behavior of checkValidUserName()
		when(userDao.checkValidUserName(anyString())).thenReturn(user);
		when(keycloakFeignClient.doChangePassword(anyObject())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
		when(userDao.saveUser(anyObject())).thenReturn(user);
		// execute
		String message = authenticationServiceImpl.changePassword(changePasswordRequest);
		// assertion
		assertEquals(messageConstants.CHANGE_PASSWORD_SUCCESS, message);
	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.service.AuthenticationServiceImpl#forgotPassword(java.lang.String)}.
	 */
	@Test
	void testForgotPassword() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.service.AuthenticationServiceImpl#patientSignup(com.pms.authenticationservice.model.PatientSignupRequest)}.
	 */
	@Test
	void testPatientSignup() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.service.AuthenticationServiceImpl#providerRegistration(com.pms.authenticationservice.model.ProviderRegistrationRequest)}.
	 */
	@Test
	void testProviderRegistration() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.service.AuthenticationServiceImpl#updateUserStatus(java.lang.String, boolean)}.
	 */
	@Test
	void testUpdateUserStatus() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for
	 * {@link com.pms.authenticationservice.service.AuthenticationServiceImpl#updateUserProfile(com.pms.authenticationservice.model.UserProfile)}.
	 */
	@Test
	void testUpdateUserProfile() {
		fail("Not yet implemented"); // TODO
	}

}
