package com.pms.authenticationservice.service;

import com.pms.authenticationservice.model.ChangePasswordRequest;
import com.pms.authenticationservice.model.LoginRequest;
import com.pms.authenticationservice.model.LoginResponse;
import com.pms.authenticationservice.model.PatientSignupRequest;
import com.pms.authenticationservice.model.ProviderRegistrationRequest;
import com.pms.authenticationservice.model.UserProfile;

public interface AuthenticationService {

	public LoginResponse loginUser(LoginRequest loginRequest);

	public String changePassword(ChangePasswordRequest changePasswordRequest);

	public String forgotPassword(String emailId);

	public String patientSignup(PatientSignupRequest patientSignuprequest);

	public String providerRegistration(ProviderRegistrationRequest providerRegistrationRequest);

	public String updateUserStatus(String emailId, boolean status);

	public String updateUserProfile(UserProfile userProfile);

}
