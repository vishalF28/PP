
package com.pms.authenticationservice.model;

import java.util.Date;

import com.pms.authenticationservice.enums.Roles;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PatientSignupRequest {

	private Long userId;
	
	private String title;
	
	private String userName;
	
	private String firstName;
    
    private String lastName;
	
	private String emailId;
	
	private Date birthDate;
	
	private String contact;
	
	private String password;
	
	private Roles role;
	
	private Boolean isActive;
	
	private String gender;
}
