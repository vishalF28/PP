package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.pms.authenticationservice.model.ChangePasswordRequest;
import com.pms.authenticationservice.model.KeyCloakLoginResponse;
import com.pms.authenticationservice.model.LoginRequest;
import com.pms.authenticationservice.model.PatientSignupRequest;
import com.pms.authenticationservice.model.ProviderRegistrationRequest;


/**
 * The Interface KeyCloakClient.
 */
@FeignClient(name = "keycloak-service", url = "http://localhost:9093",fallback = KeycloakFeignClientFallBack.class)
public interface KeycloakFeignClient {

	@PostMapping("/keycloak/login")
	public KeyCloakLoginResponse doAuthentication(@RequestBody LoginRequest object);

	@PostMapping("/keycloak/changepassword")
	public ResponseEntity<String> doChangePassword(ChangePasswordRequest changePasswordRequest);

	@PostMapping("/keycloak/createuser")
	public ResponseEntity<String> userSignup(PatientSignupRequest patientSignupRequest);
	
	@PostMapping("/keycloak/createuser")
	public ResponseEntity<String> userSignup(ProviderRegistrationRequest providerRegistrationRequest);
}
