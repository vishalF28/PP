package com.pms.authenticationservice.constants;

public class MessageConstants {

	public static final String USER_INACTIVE = "Your account has been locked. Please contact the hospital administrator or call helpdesk on 123456 for more information.";

	public static final String USER_NOT_FOUND = "User not found. Please register yourself on portal.";

	public static final String WRONG_LOGIN_ATTEMPT = "Wrong credentials. Login attempts remaining: ";

	public static final Integer MAX_LOGIN_ATTEMPT_COUNT = 3;

	public static final String SAME_NEW_PASSWORD = "Entered new password is same as old password.";

	public static final String INTERNAL_SERVER_ERORR = "Some error occured. Please contact system administrator.";

	public static final String RESET_PASSWORD_SUCCESS = "One Time Password is sent to your registred Email Id. Please Login.";

	public static final String USERNAME_ALREADY_FOUND = "Email ID exists. Please register using a different Email ID or login";

	public static final String CHANGE_PASSWORD_SUCCESS = "Password changed successfully. Please Login";

	public static final String PATIENT_CREATED_SUCCESS = "Patient registered successfully. Please Login";

	public static final String PROVIDER_CREATED_SUCCESS = "User registered successfully.";

	public static final String STATUS_UPDATED_SUCCESS = "User status updated successfully";

	public static final String UPDATE_USER_SUCCESS = "User data updated successfully.";

	public static final String USER_UPDATE_FAILURE = "Failed to update the user data.";

	public static final String MAIL_SENT_SUCCESS = "Mail sent successfully.";
}
