/**
 * 
 */
package com.pms.authenticationservice.model;

import java.sql.Date;

import com.pms.authenticationservice.enums.Roles;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The Class ProviderRegistrationRequest.
 *
 * @author SatpalC
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProviderRegistrationRequest {

	private Long userId;
	
	private String title;
	
	private String userName;
	
	private String firstName;
	
	private String lastName;
	
	private String emailId;
	
	private Date birthDate;
	
	private String contact;
	
	private Boolean isActive;

	private Roles role;

	private String password;
	
	private String speciality;
	
	private String gender;
}
