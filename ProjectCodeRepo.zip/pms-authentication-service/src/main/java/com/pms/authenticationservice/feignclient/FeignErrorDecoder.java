package com.pms.authenticationservice.feignclient;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import feign.Response;
import feign.codec.ErrorDecoder;

@Component
public class FeignErrorDecoder implements ErrorDecoder {

	private static Logger logger = LogManager.getLogger(FeignErrorDecoder.class);

	@Override
	public Exception decode(String methodKey, Response response) {
	
		switch (response.status()) {
		case 400:
			logger.error("Status code " + response.status() + ", methodKey = " + methodKey);
		case 404: {
			logger.error("Error occured. Status code " + response.status() + ", methodKey = " + methodKey);
			return new ResponseStatusException(HttpStatus.valueOf(response.status()),"Mehod Not Found");
		}
		case 401: {
			logger.error("Error occured. Status code " + response.status() + ", methodKey = " + methodKey);
			return new ResponseStatusException(HttpStatus.valueOf(response.status()),"Invalid Credentials");
		}
		default:
			return new Exception("Something went wrong. Please contact system adminatrator");
		}
	}

}