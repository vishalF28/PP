package com.pms.authenticationservice.dao;

import com.pms.authenticationservice.entity.User;
import com.pms.authenticationservice.model.UserProfile;

public interface UserDao {

	public User checkValidUserName(String emailId);

	public User saveUser(User user);

	public User findUserByEmail(String emailId);

	public User userSignup(User user);

	public void deleteUserById(User user);

	public void updateUserStatus(String emailId, boolean status);

	public User updateUserProfile(UserProfile userProfile);

}
