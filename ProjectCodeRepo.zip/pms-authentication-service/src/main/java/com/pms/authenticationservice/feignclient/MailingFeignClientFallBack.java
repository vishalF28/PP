package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

@Component public class MailingFeignClientFallBack implements FallbackFactory<MailingFeignClient>{

	@Override public MailingFeignClient create(Throwable cause) { return null; }


}
