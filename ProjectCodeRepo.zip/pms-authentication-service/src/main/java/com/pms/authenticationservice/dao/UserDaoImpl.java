package com.pms.authenticationservice.dao;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pms.authenticationservice.entity.User;
import com.pms.authenticationservice.model.UserProfile;
import com.pms.authenticationservice.repository.UserRepository;

@Repository
public class UserDaoImpl implements UserDao{

	private UserRepository userRepository;
	
	
	@Autowired
	public UserDaoImpl(	UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public User checkValidUserName(String emailId) {
		return userRepository.findByEmailId(emailId);
	}

	@Override
	public User saveUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public User findUserByEmail(String emailId) {
		return userRepository.findByEmailId(emailId);
	}

	@Override
	public User userSignup(User user) {
		return userRepository.save(user);
	}

	@Override
	public void deleteUserById(User user) {
		userRepository.delete(user);
	}

	@Override
	public void updateUserStatus(String emailId, boolean status) {
		User userEntity = userRepository.findByEmailId(emailId);
		Optional.of(userEntity).ifPresent(user -> {
			user.setIsActive(status);
			userRepository.save(user);
		});
	}

	@Override
	public User updateUserProfile(UserProfile userProfile) {
		System.out.println(userProfile);
		User user = userRepository.findByEmailId(userProfile.getEmailId());
		BeanUtils.copyProperties(userProfile, user);
		System.out.println(user);
		user = userRepository.save(user);
		System.out.println(user);
		return user;
	}
}
