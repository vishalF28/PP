package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

@Component public class PatientFeignClientFallBack implements FallbackFactory<PatientFeignClient>{

	@Override public PatientFeignClient create(Throwable cause) { return null; }


}
