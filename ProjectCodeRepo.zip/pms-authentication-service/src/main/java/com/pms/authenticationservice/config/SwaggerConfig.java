/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.authenticationservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
/**
 * 
 * @author SatpalC
 *
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {
 
	@Bean
	public Docket api() {
		Docket docket = new Docket(DocumentationType.SWAGGER_2)
				                         .select()
				                         .apis(RequestHandlerSelectors.basePackage("com.pms.authenticationservice.controller"))				                         
				                         .build()
				                         .apiInfo(apiInfo());
				                         
		return docket;				                         
	}
	
	private ApiInfo apiInfo() {
		return new ApiInfoBuilder()
				.title("Authentication Microservice")
				.version("1.0.0")
	            .description(" Authentication Service for PMS")
	            .build();
	}
	
}
