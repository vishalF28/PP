package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

@Component public class KeycloakFeignClientFallBack implements FallbackFactory<KeycloakFeignClient>{

	@Override public KeycloakFeignClient create(Throwable cause) { return null; }


}
