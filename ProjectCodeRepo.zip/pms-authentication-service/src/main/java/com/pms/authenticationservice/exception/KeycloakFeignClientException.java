package com.pms.authenticationservice.exception;


public class KeycloakFeignClientException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public KeycloakFeignClientException() {
		super();
	}

	public KeycloakFeignClientException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public KeycloakFeignClientException(String message, Throwable cause) {
		super(message, cause);
	}

	public KeycloakFeignClientException(String message) {
		super(message);
	}

	public KeycloakFeignClientException(Throwable cause) {
		super(cause);
	}

	
}
