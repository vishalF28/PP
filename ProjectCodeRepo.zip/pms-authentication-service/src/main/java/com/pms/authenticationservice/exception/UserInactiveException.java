package com.pms.authenticationservice.exception;

public class UserInactiveException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UserInactiveException() {
		super();
	}

	public UserInactiveException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public UserInactiveException(String message, Throwable cause) {
		super(message, cause);
	}

	public UserInactiveException(String message) {
		super(message);
	}

	public UserInactiveException(Throwable cause) {
		super(cause);

	}
	
	

}
