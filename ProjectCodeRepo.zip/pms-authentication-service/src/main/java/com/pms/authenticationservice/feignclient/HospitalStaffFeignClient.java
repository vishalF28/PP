package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pms.authenticationservice.model.GenericSuccessResponse;
import com.pms.authenticationservice.model.ProviderRegistrationRequest;


@FeignClient(name = "hospital-staff-service", url = "http://localhost:9095",fallback = HospitalStaffFeignClientFallBack.class)
public interface HospitalStaffFeignClient {

	@RequestMapping("admin/create-hospitalstaff-profile")
	public ResponseEntity<GenericSuccessResponse> createHospitalStaffProfile(ProviderRegistrationRequest providerRegistrationRequest);
}
