package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FallbackFactory;

public class NotificationFeignClientFallBack implements FallbackFactory<NotificationFeignClient>{

	@Override
	public NotificationFeignClient create(Throwable cause) {
		return null;
	}

}
