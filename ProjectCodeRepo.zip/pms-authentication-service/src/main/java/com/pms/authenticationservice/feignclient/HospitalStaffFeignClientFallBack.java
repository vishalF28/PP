package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FallbackFactory;
import org.springframework.stereotype.Component;

@Component public class HospitalStaffFeignClientFallBack implements FallbackFactory<HospitalStaffFeignClient>{

	@Override public HospitalStaffFeignClient create(Throwable cause) { return null; }


}
