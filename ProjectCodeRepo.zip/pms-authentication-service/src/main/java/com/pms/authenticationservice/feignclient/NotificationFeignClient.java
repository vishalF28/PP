package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "notes-service", url = "http://localhost:9097",fallback = NotificationFeignClientFallBack.class)
public interface NotificationFeignClient {
	
	@GetMapping("notify")
	public void getNotification();

}
