package com.pms.authenticationservice.exception;

public class SavePasswordException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public SavePasswordException() {
		super();
	}

	public SavePasswordException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public SavePasswordException(String message, Throwable cause) {
		super(message, cause);
	}

	public SavePasswordException(String message) {
		super(message);
	}

	public SavePasswordException(Throwable cause) {
		super(cause);
	}
	
	

}
