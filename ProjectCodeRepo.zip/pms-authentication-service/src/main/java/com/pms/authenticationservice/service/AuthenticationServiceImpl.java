package com.pms.authenticationservice.service;

import java.util.Optional;
import java.util.Random;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import com.pms.authenticationservice.config.AESEncrypt;
import com.pms.authenticationservice.constants.MessageConstants;
import com.pms.authenticationservice.dao.UserDao;
import com.pms.authenticationservice.entity.User;import com.pms.authenticationservice.enums.Gender;
import com.pms.authenticationservice.enums.Roles;
import com.pms.authenticationservice.exception.KeycloakFeignClientException;
import com.pms.authenticationservice.exception.SavePasswordException;
import com.pms.authenticationservice.exception.UserInactiveException;
import com.pms.authenticationservice.exception.UserNotFoundException;
import com.pms.authenticationservice.exception.UsernameAlreadyExistingException;
import com.pms.authenticationservice.feignclient.HospitalStaffFeignClient;
import com.pms.authenticationservice.feignclient.KeycloakFeignClient;
import com.pms.authenticationservice.feignclient.NotificationFeignClient;
import com.pms.authenticationservice.feignclient.PatientFeignClient;
import com.pms.authenticationservice.model.ChangePasswordRequest;
import com.pms.authenticationservice.model.KeyCloakLoginResponse;
import com.pms.authenticationservice.model.LoginRequest;
import com.pms.authenticationservice.model.LoginResponse;
import com.pms.authenticationservice.model.MailRequest;
import com.pms.authenticationservice.model.PatientSignupRequest;
import com.pms.authenticationservice.model.ProviderRegistrationRequest;
import com.pms.authenticationservice.model.UserProfile;

import reactor.core.publisher.Mono;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

	private KeycloakFeignClient keycloakFeignClient;

	private PatientFeignClient patientFeignClient;

	private HospitalStaffFeignClient hospitalStaffFeignClient;

	private WebClient webClient;

	private UserDao userDao;
	
	private NotificationFeignClient notificationFeignClient;
	
	private AESEncrypt aesEncrypt;

	@Autowired
	public AuthenticationServiceImpl(KeycloakFeignClient keycloakFeignClient, PatientFeignClient patientFeignClient,
			HospitalStaffFeignClient hospitalStaffFeignClient, UserDao userDao, WebClient webClient,
			NotificationFeignClient notificationFeignClient, AESEncrypt aesEncrypt) {
		this.keycloakFeignClient = keycloakFeignClient;
		this.patientFeignClient = patientFeignClient;
		this.hospitalStaffFeignClient = hospitalStaffFeignClient;
		this.userDao = userDao;
		this.webClient = webClient;
		this.notificationFeignClient = notificationFeignClient;
		this.aesEncrypt = aesEncrypt;
	}

	@Override
	public LoginResponse loginUser(LoginRequest loginRequest) {
		KeyCloakLoginResponse keycloakLoginResponse = null;
		LoginResponse loginResponse = null;
		User user = null;
		try {
			loginResponse = new LoginResponse();
			user = userDao.checkValidUserName(loginRequest.getEmailId());
			if (null == user) {
				throw new UserNotFoundException(MessageConstants.USER_NOT_FOUND);
			} else if (null != user && !user.getIsActive()) {
				throw new UserInactiveException(MessageConstants.USER_INACTIVE);
			} else {
				keycloakLoginResponse = keycloakFeignClient.doAuthentication(loginRequest);
				mapLoginResponse(loginResponse, keycloakLoginResponse, user);
				user.setNoOfLoginTrials(0);
				notificationFeignClient.getNotification();
				
			}
		} catch (ResponseStatusException e) {
			if (e.getStatus().equals(HttpStatus.UNAUTHORIZED)) {
				user.setNoOfLoginTrials(user.getNoOfLoginTrials() + 1);
				if (MessageConstants.MAX_LOGIN_ATTEMPT_COUNT == user.getNoOfLoginTrials()) {
					user.setIsActive(Boolean.FALSE);
					throw new UserInactiveException(MessageConstants.USER_INACTIVE);
				}
				throw new KeycloakFeignClientException(MessageConstants.WRONG_LOGIN_ATTEMPT
						+ (MessageConstants.MAX_LOGIN_ATTEMPT_COUNT - (user.getNoOfLoginTrials())), e);
			}
		} finally {
			if (null != user)
				userDao.saveUser(user);
		}
		return loginResponse;
	}

	private void mapLoginResponse(LoginResponse loginResponse, KeyCloakLoginResponse keycloakLoginResponse, User user) {
		loginResponse.setRole(user.getRole().name());
		loginResponse.setFirstName(user.getFirstName());
		loginResponse.setLastName(user.getLastName());
		loginResponse.setEmailId(user.getEmailId());
		loginResponse.setTitle(user.getTitle());
		loginResponse.setIsFirstTimeLogin(user.isFirstTimeLogin());
		loginResponse.setAccessToken(keycloakLoginResponse.getAccessToken());
		loginResponse.setExpiresIn(keycloakLoginResponse.getExpiresIn());
	}

	@Override
	public String changePassword(ChangePasswordRequest changePasswordRequest) {
		User user = userDao.checkValidUserName(changePasswordRequest.getEmailId());

		if (aesEncrypt.decrypt(user.getPassword()).equals(changePasswordRequest.getNewPassword())) {
			throw new SavePasswordException(MessageConstants.SAME_NEW_PASSWORD);
		}
		try {
			keycloakFeignClient.doChangePassword(changePasswordRequest);
			user.setFirstTimeLogin(false);
			user.setPassword(changePasswordRequest.getNewPassword());
		} catch (ResponseStatusException e) {
			throw new KeycloakFeignClientException(e.getReason(), e);
		} finally {
			user.setPassword(aesEncrypt.encrypt(user.getPassword()));
			userDao.saveUser(user);
		}
		return MessageConstants.CHANGE_PASSWORD_SUCCESS;
	}

	@Override
	public String forgotPassword(String emailId) {
		User user = userDao.checkValidUserName(emailId);
		ChangePasswordRequest changePasswordRequest = null;
		if (null != user) {
			MailRequest forgotPasswordMailRequest = null;
			try {
				forgotPasswordMailRequest = new MailRequest();
				forgotPasswordMailRequest.setEmailId(emailId);
				String defaultPassword = generatePassword(8);
				user.setPassword(defaultPassword);
				forgotPasswordMailRequest.setDefaultPassword(defaultPassword);

				forgotPasswordMail(forgotPasswordMailRequest);

				changePasswordRequest = new ChangePasswordRequest();
				changePasswordRequest.setEmailId(emailId);
				changePasswordRequest.setNewPassword(defaultPassword);
				keycloakFeignClient.doChangePassword(changePasswordRequest);
				user.setFirstTimeLogin(Boolean.TRUE);
			} catch (Exception e) {
				throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
			} finally {
				user.setPassword(aesEncrypt.encrypt(user.getPassword()));
				userDao.saveUser(user);
			}
		} else {
			throw new UserNotFoundException(MessageConstants.USER_NOT_FOUND);
		}
		return MessageConstants.RESET_PASSWORD_SUCCESS;
	}

	private static String generatePassword(int length) {
		String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
		String specialCharacters = "!@#$";
		String numbers = "1234567890";
		String combinedChars = capitalCaseLetters + lowerCaseLetters + specialCharacters + numbers;
		Random random = new Random();
		char[] password = new char[length];
		password[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length()));
		password[1] = capitalCaseLetters.charAt(random.nextInt(capitalCaseLetters.length()));
		password[2] = specialCharacters.charAt(random.nextInt(specialCharacters.length()));
		password[3] = numbers.charAt(random.nextInt(numbers.length()));
		for (int i = 4; i < length; i++) {
			password[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
		}
		return new String(password);
	}

	/**
	 * Patient signup.
	 *
	 * @param patientSignupRequest the patient signup request
	 * @return string response
	 */
	@Override
	public String patientSignup(PatientSignupRequest patientSignupRequest) {

		User user = null;
		user = userDao.findUserByEmail(patientSignupRequest.getEmailId());
		if (null != user) {
			throw new UsernameAlreadyExistingException(MessageConstants.USERNAME_ALREADY_FOUND);
		}
		user = new User();
		
		patientSignupRequest.setRole(Roles.PATIENT);
		patientSignupRequest.setUserName(patientSignupRequest.getEmailId());

		BeanUtils.copyProperties(patientSignupRequest, user);
		user.setIsActive(true);
		user.setFirstTimeLogin(false);
		user.setGender(Gender.valueOf(patientSignupRequest.getGender()));
		user.setRole(Roles.PATIENT);
		user.setSpeciality("General");
		try {
			user.setPassword(aesEncrypt.encrypt(user.getPassword()));
			user = userDao.userSignup(user);
		} catch (Exception e) {
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}

		patientSignupRequest.setUserName(patientSignupRequest.getEmailId());
		try {
			ResponseEntity<String> keycloakResponse = keycloakFeignClient.userSignup(patientSignupRequest);
			PatientSignupRequest patientProfileRequest = new PatientSignupRequest();
			if (HttpStatus.CREATED == keycloakResponse.getStatusCode()) {
				User savedUser = userDao.findUserByEmail(patientSignupRequest.getEmailId());

				Optional.ofNullable(savedUser).ifPresent(userProfile -> {
					BeanUtils.copyProperties(userProfile, patientProfileRequest);
					patientProfileRequest.setGender(userProfile.getGender().name());
					patientProfileRequest.setUserName(patientProfileRequest.getEmailId());
					patientProfileRequest.setUserId(savedUser.getUserId());
					System.out.println(patientProfileRequest);
					patientFeignClient.createPatientProfile(patientProfileRequest);

				});
				System.out.println(patientProfileRequest);
				MailRequest signupMailRequest = new MailRequest();
				signupMailRequest.setEmailId(patientSignupRequest.getEmailId());
				patientWelcomeMail(signupMailRequest);
			}
		} catch (Exception e) {
			e.printStackTrace();
			userDao.deleteUserById(user);
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}
		return MessageConstants.PATIENT_CREATED_SUCCESS;
	}

	@Override
	public String providerRegistration(ProviderRegistrationRequest providerRegistrationRequest) {
		String defaultPassword = generatePassword(8);

		User user;
		user = userDao.findUserByEmail(providerRegistrationRequest.getEmailId());
		if (null != user) {
			throw new UsernameAlreadyExistingException(MessageConstants.USERNAME_ALREADY_FOUND);
		}
		user = new User();

		providerRegistrationRequest.setUserName(providerRegistrationRequest.getEmailId());
		providerRegistrationRequest.setPassword(defaultPassword);
		BeanUtils.copyProperties(providerRegistrationRequest, user);
		user.setIsActive(true);
		user.setFirstTimeLogin(true);
		user.setRole(providerRegistrationRequest.getRole());
		user.setGender(Gender.valueOf(providerRegistrationRequest.getGender()));
		try {
			user.setPassword(aesEncrypt.encrypt(user.getPassword()));
			user = userDao.userSignup(user);
		} catch (Exception e) {
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}
		try {
			ResponseEntity<String> keycloakResponse = keycloakFeignClient.userSignup(providerRegistrationRequest);
			if (HttpStatus.CREATED == keycloakResponse.getStatusCode()) {
				User savedUser = userDao.findUserByEmail(providerRegistrationRequest.getEmailId());
				Optional.ofNullable(savedUser).ifPresent(userProfile -> {
					BeanUtils.copyProperties(userProfile, providerRegistrationRequest);
					providerRegistrationRequest.setGender(userProfile.getGender().name());
					providerRegistrationRequest.setUserName(providerRegistrationRequest.getEmailId());
					providerRegistrationRequest.setUserId(savedUser.getUserId());
					hospitalStaffFeignClient.createHospitalStaffProfile(providerRegistrationRequest);
				});

				MailRequest providerRegistrationMailRequest = new MailRequest();
				providerRegistrationMailRequest.setEmailId(providerRegistrationRequest.getEmailId());
				providerRegistrationMailRequest.setDefaultPassword(defaultPassword);
				providerRegistrationMail(providerRegistrationMailRequest);
			}
		} catch (Exception e) {
			userDao.deleteUserById(user);
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERORR);
		}
		return MessageConstants.PROVIDER_CREATED_SUCCESS;
	}

	@Override
	public String updateUserStatus(String emailId, boolean status) {
		userDao.updateUserStatus(emailId, status);
		return MessageConstants.STATUS_UPDATED_SUCCESS;
	}

	@Override
	public String updateUserProfile(UserProfile userProfile) {
		try {
			userDao.updateUserProfile(userProfile);
		} catch (Exception e) {
			throw new RuntimeException(MessageConstants.USER_UPDATE_FAILURE);
		}
		return MessageConstants.UPDATE_USER_SUCCESS;
	}

	private String forgotPasswordMail(MailRequest forgotPasswordMailRequest) {
		webClient.post().uri("/sendmail/forgotpassword").body(Mono.just(forgotPasswordMailRequest), MailRequest.class)
				.exchange().doOnError(error -> error.printStackTrace()).subscribe();

		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String patientWelcomeMail(MailRequest signupMailRequest) {
		webClient.post().uri("/sendmail/patient-signup").body(Mono.just(signupMailRequest), MailRequest.class)
				.exchange().doOnError(error -> error.printStackTrace()).subscribe();

		return MessageConstants.MAIL_SENT_SUCCESS;
	}

	private String providerRegistrationMail(MailRequest providerRegistrationMailRequest) {
		webClient.post().uri("/sendmail/provider-registration")
				.body(Mono.just(providerRegistrationMailRequest), MailRequest.class).exchange()
				.doOnError(error -> error.printStackTrace()).subscribe();

		return MessageConstants.MAIL_SENT_SUCCESS;
	}
}
