package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pms.authenticationservice.model.GenericSuccessResponse;
import com.pms.authenticationservice.model.PatientSignupRequest;


@FeignClient(name = "patient-service", url = "http://localhost:9094",fallback = PatientFeignClientFallBack.class)
public interface PatientFeignClient {

	@RequestMapping("patient/create-patient-profile")
	public ResponseEntity<GenericSuccessResponse> createPatientProfile(PatientSignupRequest patientSignupRequest);
}
