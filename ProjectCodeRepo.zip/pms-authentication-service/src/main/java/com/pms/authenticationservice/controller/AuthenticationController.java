package com.pms.authenticationservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.authenticationservice.model.ChangePasswordRequest;
import com.pms.authenticationservice.model.GenericSuccessResponse;
import com.pms.authenticationservice.model.LoginRequest;
import com.pms.authenticationservice.model.LoginResponse;
import com.pms.authenticationservice.model.PatientSignupRequest;
import com.pms.authenticationservice.model.ProviderRegistrationRequest;
import com.pms.authenticationservice.model.UserProfile;
import com.pms.authenticationservice.service.AuthenticationService;

@RestController
@RequestMapping("/authentication")
public class AuthenticationController {

	AuthenticationService authenticationService;
	
	public AuthenticationController() {
	}
	
	@Autowired
	public AuthenticationController(AuthenticationService authenticationService) {
		this.authenticationService = authenticationService; 
	}
	
	
	@PostMapping("/login") 
	public ResponseEntity<LoginResponse> loginUser(@RequestBody LoginRequest loginRequest) {
		LoginResponse loginResponse = authenticationService.loginUser(loginRequest);
		return new ResponseEntity<LoginResponse>(loginResponse, HttpStatus.OK);
	}
	
	@PutMapping("/change-password")
	public ResponseEntity<GenericSuccessResponse> changePassword(@RequestBody ChangePasswordRequest changePasswordRequest) {
		String message = authenticationService.changePassword(changePasswordRequest);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@PutMapping("/forgot-password/{emailId}")
	public ResponseEntity<GenericSuccessResponse> forgotPassword(@PathVariable String emailId) {
		String message = authenticationService.forgotPassword(emailId);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@PostMapping("patient-signup")
	public ResponseEntity<GenericSuccessResponse> patientSignup(@RequestBody PatientSignupRequest patientSignupRequest) {
		String message = authenticationService.patientSignup(patientSignupRequest);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@PostMapping("/provider-signup")
	public ResponseEntity<GenericSuccessResponse> providerRegistration(@RequestBody ProviderRegistrationRequest providerRegistrationRequest) {
		System.out.println(providerRegistrationRequest);
		String message = authenticationService.providerRegistration(providerRegistrationRequest);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@PutMapping("/update-user-status")
	public ResponseEntity<GenericSuccessResponse> updateUserStatus(@RequestParam String emailId, @RequestParam boolean status) {
		String message = authenticationService.updateUserStatus(emailId, status);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@PostMapping("/update-user-profile")
	public ResponseEntity<GenericSuccessResponse> updateUserProfile(@RequestBody UserProfile userProfile) {
		String message = authenticationService.updateUserProfile(userProfile);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
}
