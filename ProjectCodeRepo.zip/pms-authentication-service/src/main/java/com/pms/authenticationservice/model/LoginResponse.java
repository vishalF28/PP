package com.pms.authenticationservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponse {
	
	private String emailId;
	
	private String title;
	
	private String firstName;
	
	private String lastName;
	
	private String role;
	
	private String accessToken;
	
	private Integer expiresIn;
	
	private Boolean isFirstTimeLogin;
}
