package com.pms.authenticationservice.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pms.authenticationservice.model.MailRequest;


@FeignClient(name = "mailing-service", url = "http://localhost:9092",fallback = MailingFeignClientFallBack.class)
public interface MailingFeignClient {

	@RequestMapping("/sendmail/forgotpassword")
	public ResponseEntity<String> forgotPasswordMail(@RequestBody MailRequest mailRequest);
	
	@RequestMapping("/sendmail/patient-signup")
	public ResponseEntity<String> patientWelcomeMail(@RequestBody MailRequest mailRequest);

	@RequestMapping("/sendmail/provider-registration")
	public ResponseEntity<String> providerRegistrationMail(MailRequest mailRequest);
}
