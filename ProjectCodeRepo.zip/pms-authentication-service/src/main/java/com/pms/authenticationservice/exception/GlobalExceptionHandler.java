/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.authenticationservice.exception;

import java.util.Calendar;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.pms.authenticationservice.constants.MessageConstants;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(KeycloakFeignClientException.class)
	public ResponseEntity<ErrorResponse> handleInvalidCredentialsException(KeycloakFeignClientException e) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setDetail(e.getMessage());
		errorResponse.setMessage(e.getLocalizedMessage());
		errorResponse.setTimestamp(Calendar.getInstance().getTime());
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleUserNotFoundException(UserNotFoundException e) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setDetail(e.getMessage());
		errorResponse.setMessage(e.getLocalizedMessage());
		errorResponse.setTimestamp(Calendar.getInstance().getTime());
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(UserInactiveException.class)
	public ResponseEntity<ErrorResponse> handleUserInactiveException(UserInactiveException e) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setDetail(e.getMessage());
		errorResponse.setMessage(e.getLocalizedMessage());
		errorResponse.setTimestamp(Calendar.getInstance().getTime());
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.OK);
	}
	
	@ExceptionHandler(SavePasswordException.class)
	public ResponseEntity<ErrorResponse> handleSavePasswordException(SavePasswordException e) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setDetail(e.getMessage());
		errorResponse.setMessage(e.getLocalizedMessage());
		errorResponse.setTimestamp(Calendar.getInstance().getTime());
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(UsernameAlreadyExistingException.class)
	public ResponseEntity<ErrorResponse> handleUsernameAlreadyExistingException(UsernameAlreadyExistingException e) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setDetail(e.getMessage());
		errorResponse.setMessage(e.getMessage());
		errorResponse.setTimestamp(Calendar.getInstance().getTime());
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handleInternalServerError(Exception e) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setDetail(e.getMessage());
		errorResponse.setMessage(MessageConstants.INTERNAL_SERVER_ERORR);
		errorResponse.setTimestamp(Calendar.getInstance().getTime());
		return new ResponseEntity<ErrorResponse>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
