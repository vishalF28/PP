package com.pms.patientservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pms.patientservice.entity.PatientAllergyMapping;

public interface PatientAllergyRepository extends JpaRepository<PatientAllergyMapping, Long>{

}
