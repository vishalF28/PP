package com.pms.patientservice.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.pms.patientservice.enums.Gender;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Data
@Getter
@Setter
@DynamicUpdate
@Entity
@ToString
@Table(name = "pms_patient", schema = "pms_patient")
public class Patient extends Auditable<String> implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "patient_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_patient_generator")
	@SequenceGenerator(name="pms_patient_generator", sequenceName = "pms_patient.pms_patient_seq", allocationSize=1)
	private Long patientId;
 
	@Column(name = "user_id")
	private Long userId;
	
	@Column(name = "is_active")
	private Boolean isActive;
	
	private String title;

	@Column(name = "birth_date")
	private Date birthDate;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	private String contact;

	@Enumerated(EnumType.STRING)
	private Gender gender;

	@Column(name ="race")
	private String race;
	
	@Column(name = "home_address")
	private String homeAddress;
	
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "relative_id")
	private EmergencyContact emergencyContact;
	
	@Column(name="languages_known")
	private String languagesKnown;
	
	@Column(name="ethnicity")
	private String ethnicity;
	
	@Fetch(value = FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "patient_id")
    private Set<PatientAllergyMapping> patientAllergy;

	

	@Column(name = "allergy_flag")
	private String alleryFlag;
}
