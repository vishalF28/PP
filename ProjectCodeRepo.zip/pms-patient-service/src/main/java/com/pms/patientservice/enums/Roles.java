package com.pms.patientservice.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum Roles.
 */
public enum Roles {

	/** The Admin. */
	ADMINISTRATOR("ADMINISTRATOR"),
	/** The Physician. */
	PHYSICIAN("PHYSICIAN"),
	/** The Nurse. */
	NURSE("NURSE"),
	/** The Patient. */
	PATIENT("PATIENT");

	/** The value. */
	private String value;

	/**
	 * Instantiates a new roles.
	 *
	 * @param value the value
	 */
	Roles(String value) {
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
}
