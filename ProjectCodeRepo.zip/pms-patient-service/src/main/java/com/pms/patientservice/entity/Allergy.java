package com.pms.patientservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "pms_allergy", schema = "pms_master")
public class Allergy extends Auditable<String> {

	@Id
	@Column(name = "allergy_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_allergy_generator")
	@SequenceGenerator(name="pms_allergy_generator", sequenceName = "pms_master.pms_allergy_seq", allocationSize=1)
	private Long allergyId;

	@Column(name = "allergy_type")
	private String allergyType;

	@Column(name = "allergy_name")
	private String allergyName;

	@Column(name = "allergy_description")
	private String allergyDescription;

	@Column(name = "allergy_clinical_information")
	private String allergyClinicalInformation;

	@Column(name = "is_newly_added")
	private Boolean isNewlyAdded;
}
