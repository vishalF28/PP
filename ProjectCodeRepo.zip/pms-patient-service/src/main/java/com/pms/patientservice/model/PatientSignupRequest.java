package com.pms.patientservice.model;

import java.sql.Date;



import lombok.Data;

@Data
public class PatientSignupRequest {

	private Long userId;

	private String title;

	private String username;

	private String firstName;

	private String lastName;

	private String emailId;

	private Date birthDate;

	private String contact;
	
	private Boolean isActive;
	
	private String gender;

}
