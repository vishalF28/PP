/**
 * 
 */
package com.pms.patientservice.service;

import java.util.List;
import java.util.Set;

import com.pms.patientservice.entity.Patient;
import com.pms.patientservice.entity.PatientAllergyMapping;
import com.pms.patientservice.model.PatientSignupRequest;


// TODO: Auto-generated Javadoc
/**
 * The Interface PatientService.
 *
 * @author SatpalC
 */
public interface PatientService {

	/**
	 * @param patientprofile
	 * @return
	 */
	public String savePatientProfile(PatientSignupRequest patientprofile);

	public Patient getPatientProfile(String emailId);

	public List<Patient> getAllPatients();

	public String updateUserStatus(String emailId, boolean status);

	public Long getPatientCount();

	public Long getNewPatientCount();

	public Patient updatePatientProfile(Patient patient);

	public String deletePatientAllergy(Long patientAllergyMappingId);

	public PatientAllergyMapping savePatientAllergy(PatientAllergyMapping patientAllergyMapping);

	public List<Patient> getAllPatientsByIds(Set<Long> patientIdSet);
	
}
