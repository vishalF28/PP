package com.pms.patientservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pms.patientservice.entity.Allergy;

// TODO: Auto-generated Javadoc
/**
 * The Interface AllergyRepository.
 */
@Repository
public interface AllergyRepository extends JpaRepository<Allergy, Long> {

	/**
	 * Find all.
	 *
	 * @return the list
	 */
	public List<Allergy> findAll();
	
	/**
	 * Find by alergy type.
	 *
	 * @param alergyType the alergy type
	 * @return the optional
	 */
	public Optional<Allergy> findByAllergyType(String allergyType);
	
	/**
	 * Find by allergy id.
	 *
	 * @param allergyId the allergy id
	 * @return the optional
	 */
	public Allergy findByAllergyId(Long allergyId);

	/**
	 * @param string
	 * @return
	 */
	public Object findByAllergyName(String string);

	/**
	 * @param string
	 * @return
	 */
	public Allergy findByAllergyDescription(String string);

	
}
