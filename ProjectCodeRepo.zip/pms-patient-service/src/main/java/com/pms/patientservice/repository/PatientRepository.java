package com.pms.patientservice.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pms.patientservice.entity.Patient;

/**
 * The Interface PatientRepository.
 */
@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {
	
	public Patient findByEmailId(String emailId);

	public long count();
	
	@Query("SELECT COUNT(*) FROM Patient WHERE DATE_TRUNC('day', createdDate)=DATE_TRUNC('day', now())")
	public long countNewAddedPatient();

	public List<Patient> findByUserIdIn(Set<Long> patientIdSet);
	
}
