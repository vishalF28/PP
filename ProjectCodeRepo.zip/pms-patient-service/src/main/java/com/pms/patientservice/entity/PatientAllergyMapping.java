
package com.pms.patientservice.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter(value = AccessLevel.PUBLIC)
@Setter(value = AccessLevel.PUBLIC)
@NoArgsConstructor
@DynamicUpdate
@ToString
@AllArgsConstructor
@Table(name = "patient_allergy", schema = "pms_patient")
public class PatientAllergyMapping extends Auditable<String> implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "patient_allergy_generator")
	@SequenceGenerator(name="patient_allergy_generator", sequenceName = "pms_patient.patient_allergy_seq", allocationSize=1)
	@Column(name="patient_allergy_mapping_id")
	private Long patientAllergyMappingId;

	@Column(name = "patient_id")
	private Long patientId;

	@ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinColumn(name = "allergy_id")
	private Allergy allergy;

	@Column(name = "is_allergy_fatal")
	private String isAllergyFatal;

	@Column(name = "is_allergy_deleted")
	private Boolean isAllergyDeleted;

}
