package com.pms.patientservice.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.patientservice.entity.Patient;
import com.pms.patientservice.entity.PatientAllergyMapping;
import com.pms.patientservice.model.GenericSuccessResponse;
import com.pms.patientservice.model.PatientSignupRequest;
import com.pms.patientservice.service.PatientService;

import io.swagger.annotations.Api;

/**
 * The Class PatientServiceController.
 * 
 * @author SatpalC
 *
 */
@Api
@RestController
@RequestMapping("patient")
public class PatientController {

	PatientService patientService;

	public PatientController() {
	}
	
	@Autowired
	public PatientController(PatientService patientService) {
		this.patientService = patientService;
	}

	@PostMapping("/create-patient-profile")
	public ResponseEntity<GenericSuccessResponse> createPatientProfile(@RequestBody PatientSignupRequest patientSignupRequest) {
		System.out.println(patientSignupRequest);
		String message = patientService.savePatientProfile(patientSignupRequest);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@GetMapping("/get-patient-profile/{emailId}")
	public ResponseEntity<Patient> getPatientProfile(@PathVariable String emailId) {

		return new ResponseEntity<Patient>(patientService.getPatientProfile(emailId), HttpStatus.OK);
	}
	
	@GetMapping("/get-patients")
	public ResponseEntity<List<Patient>> getAllPatients() {

		return new ResponseEntity<List<Patient>>(patientService.getAllPatients(), HttpStatus.OK);
	}

	@PutMapping("/update-patient-status")
	public ResponseEntity<GenericSuccessResponse> updatePatientStatus(@RequestParam String emailId, @RequestParam boolean status) {
		String message = patientService.updateUserStatus(emailId, status);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@GetMapping("/get-patient-count")
    public ResponseEntity<Long> getPatientCount() {
        return new ResponseEntity<Long>(patientService.getPatientCount(), HttpStatus.OK);
    }
	
	@GetMapping("/get-new-patient-count")
	public ResponseEntity<Long> getNewPatientCount() {
		return new ResponseEntity<Long>(patientService.getNewPatientCount(), HttpStatus.OK);
	}
	
	@PutMapping("/save-patient-profile")
	public ResponseEntity<Patient> updatePatientProfile(@RequestBody Patient patient) {
		return new ResponseEntity<Patient>(patientService.updatePatientProfile(patient), HttpStatus.OK);
	}
	
	@DeleteMapping("/delete-patient-allergy/{patientAllergyMappingId}")
	public ResponseEntity<GenericSuccessResponse> deletePatientAllergy(@PathVariable Long patientAllergyMappingId) {
		String message = patientService.deletePatientAllergy(patientAllergyMappingId);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@PostMapping("/add-patient-allergy")
	public ResponseEntity<PatientAllergyMapping> savePatientAllergy(@RequestBody PatientAllergyMapping patientAllergyMapping)
	{
		return new ResponseEntity<PatientAllergyMapping>(patientService.savePatientAllergy(patientAllergyMapping), HttpStatus.OK);
	}
	
	@GetMapping("/get-patients-profiles-by-id")
	public ResponseEntity<List<Patient>> getPatientProfileForPhysicianDashboard(@RequestParam Set<Long> patientIdSet)
	{
		List<Patient> patients = patientService.getAllPatientsByIds(patientIdSet);
		return new ResponseEntity<List<Patient>>(patients, HttpStatus.OK);
	}
}
