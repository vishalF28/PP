/**
 *  Copyright (c) 2021 Citius Tech
 *  All Rights Reserved.
 *  No portions of this source code or the resulting compiled program
 *  may be used without written permission of CitiusTech
 *  or beyond the terms and conditions stipulated in the agreement/contract
 *  under which the software has been supplied.
 */
package com.pms.patientservice.config;

import java.util.Objects;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;


/**
 * The Class LoggingAspect.
 */
@Aspect
@Component
public class LoggingConfig {

	private static Logger logger = LogManager.getLogger(LoggingConfig.class);
	
	/**
	 * Application package pointcut.
	 */
	@Pointcut("execution(* com.pms.keycloakservice.*..*(..)))")
    public void applicationPackagePointcut() {
        throw new UnsupportedOperationException();
    }

	
	/**
	 * Profile all methods.
	 *
	 * @param proceedingJoinPoint the obj proceeding join point
	 * @return the object
	 * @throws Throwable the throwable
	 */
	@Around("execution(* com.pms.keycloakservice.service..*(..)))")
	public Object profileAllMethods(ProceedingJoinPoint proceedingJoinPoint) throws Throwable
	{
		MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
		
		//Get intercepted method details
        String className = methodSignature.getDeclaringType().getCanonicalName();
        String methodName = methodSignature.getName();
          
        final StopWatch stopWatch = new StopWatch();
          
        //Measure method execution time
        stopWatch.start();
        Object result = proceedingJoinPoint.proceed();
        stopWatch.stop();
  
        //Log method execution time
        logger.info("Execution time of " + className + "." + methodName + " "
                            + ":: " + stopWatch.getTotalTimeMillis() + " ms");
  
        return result;
	}
	
	/**
	 * Log after throwing.
	 *
	 * @param joinPoint the join point
	 * @param e the e
	 */
	@AfterThrowing(pointcut = "applicationPackagePointcut()", throwing = "e")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable e) 
	{
        logger.error("Exception in {}.{}() with cause = {}", joinPoint.getSignature().getDeclaringTypeName(),
                joinPoint.getSignature().getName(), e.getCause() != null ? e.getMessage() : "NULL");
    }
	
	/**
	 * Befor method.
	 *
	 * @param joinPoint the join point
	 */
	@Before(value = "execution(* com.pms.keycloakservice.*..*(..)))")
	public void beforMethod(JoinPoint joinPoint)
	{
		MethodSignature method = (MethodSignature)joinPoint.getSignature();
		logger.info("Before calling method: " + method.getName() + " from class: "+ method.getDeclaringType().getCanonicalName());
        String[] parameters = method.getParameterNames();
        if(null != parameters)
        {
	        for (int t = 0; t< parameters.length; t++) 
	        {
	            if( Objects.nonNull(parameters[t])) {
	                Object[] obj = joinPoint.getArgs();
	                logger.info("Before argument: "+obj[t]);
	            }
	        }
        }
	}
	
	/**
	 * After method.
	 *
	 * @param joinPoint the join point
	 */
	@After(value = "execution(* com.pms.keycloakservice.*..*(..)))")
	public void afterMethod(JoinPoint joinPoint)
	{
		MethodSignature method = (MethodSignature)joinPoint.getSignature();
		logger.info("After calling method: " + method.getName() + " from class: "+ method.getDeclaringType().getCanonicalName());
        String[] parameters = method.getParameterNames();
        if(null != parameters)
        {
	        for (int t = 0; t< parameters.length; t++) 
	        {
	            if( Objects.nonNull(parameters[t])) {
	                Object[] obj = joinPoint.getArgs();
	                logger.info("After argument: "+obj[t]);
	            }
	        }
        }
	}
}
