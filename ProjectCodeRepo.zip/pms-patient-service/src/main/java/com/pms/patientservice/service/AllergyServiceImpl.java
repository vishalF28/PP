package com.pms.patientservice.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.patientservice.constants.MessageConstants;
import com.pms.patientservice.entity.Allergy;
import com.pms.patientservice.repository.AllergyRepository;

// TODO: Auto-generated Javadoc
/**
 * The Class AllergyServiceImpl.
 */
@Service
public class AllergyServiceImpl implements AllergyService {

	/** The allergy repository. */
	@Autowired
	AllergyRepository allergyRepository;

	/**
	 * Gets the all allergies.
	 *
	 * @return the all allergies
	 */
	@Override
	public List<Allergy> getAllAllergies() {
		// TODO Auto-generated method stub
		return allergyRepository.findAll();
	}

	/**
	 * Gets the allergy by id.
	 *
	 * @param allergyId the allergy id
	 * @return the allergy by id
	 */
	@Override
	public Optional<Allergy> getAllergyById(Long allergyId) {
		// TODO Auto-generated method stub
		return allergyRepository.findById(allergyId);
	}

	/**
	 * Gets the allergy by type.
	 *
	 * @param allergyType the allergy type
	 * @return the allergy by type
	 */
	@Override
	public Optional<Allergy> getAllergyByType(String allergyType) {
		// TODO Auto-generated method stub
		return allergyRepository.findByAllergyType(allergyType);
	}

	/**
	 * Save allergy.
	 *
	 * @param allergy the allergy
	 * @return the allergy
	 */
	@Override
	public Allergy saveAllergy(Allergy allergy) {
		
		return allergyRepository.save(allergy);
		
	}

	/**
	 * Delete allergy.
	 *
	 * @param allergy the allergy
	 */
	@Override
	public String deleteAllergy(Allergy allergy) {
		allergyRepository.delete(allergy);
		return MessageConstants.ALLERGY_DELETED_SUCCESS;
	}

	/**
	 * Update allergy.
	 *
	 * @param allergy the allergy
	 * @return the allergy
	 */
	@Override
	public Allergy updateAllergy(Allergy allergy) {
		return	allergyRepository.save(allergy);
		
	}

	@Override
	public List<Allergy> getNewlyAddedAllergies() {
		// TODO Auto-generated method stub
				return allergyRepository.findAll().stream().filter(allergy -> allergy.getIsNewlyAdded()).collect(Collectors.toList());
	}
}
