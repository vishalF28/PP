/**
 * 
 */
package com.pms.patientservice.model;

import java.sql.Date;

import com.pms.patientservice.enums.Roles;

import lombok.Data;


/**
 * The Class PatientProfileRequest.
 *
 * @author SatpalC
 */
@Data
public class PatientProfileRequest {
	private Long userId;

	private String title;

	private String username;

	private String firstName;

	private String lastName;

	private String emailId;

	private Date birthDate;

	private String contact;

	private String password;

	private Roles role;


}
