package com.pms.patientservice.constants;

public class MessageConstants {

	public static final String PATIENT_PROFILE_SAVE_SUCCESS = "Patients profile details saved successfully";
	
	public static final String INTERNAL_SERVER_ERROR = "Some error occured. Please contact system administrator.";

	public static final String ALLERGY_DELETED_SUCCESS = "Allergy deleted successfully.";

	public static final String DIAGNOSIS_DELETED_SUCCESS = "Diagnosis deleted successfully.";

	public static final String DRUG_DELETED_SUCCESS = "Drug deleted successfully.";

	public static final String PROCEDURE_DELETED_SUCCESS = "Procedure deleted successfully.";

	public static final String STATUS_UPDATED_SUCCESS = "User status updated successfully.";

	public static final String ALLERGY_DELETED_FAILURE = "Unable to delete allergy.";

}
