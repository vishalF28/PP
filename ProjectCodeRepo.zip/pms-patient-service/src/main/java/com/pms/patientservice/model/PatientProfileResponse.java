package com.pms.patientservice.model;

/**
 * The Class PatientProfileResponse.
 */
public class PatientProfileResponse {

	private int statuscode;

	private String message;


	public int getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "PatientSignupResponse [statuscode=" + statuscode + ", message=" + message +"]";
	}



}
