package com.pms.patientservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class PmsPatientServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PmsPatientServiceApplication.class, args);
	}

}
