/**
 * 
 */
package com.pms.patientservice.service;

import java.util.List;
import java.util.Optional;

import com.pms.patientservice.entity.Allergy;

// TODO: Auto-generated Javadoc
/**
 * The Interface AllergyService.
 *
 * @author SatpalC
 */
public interface AllergyService {

	/**
	 * Gets the all allergies.
	 *
	 * @return the all allergies
	 */
	List<Allergy> getAllAllergies();
    
    /**
     * Gets the allergy by id.
     *
     * @param allergyId the allergy id
     * @return the allergy by id
     */
    Optional<Allergy> getAllergyById(Long allergyId);
	
	/**
	 * Gets the allergy by type.
	 *
	 * @param allergyType the allergy type
	 * @return the allergy by type
	 */
	Optional<Allergy> getAllergyByType(String allergyType);
	
	/**
	 * Save allergy.
	 *
	 * @param allergy the allergy
	 * @return the allergy
	 */
	Allergy saveAllergy(Allergy allergy);
	
	/**
	 * Delete allergy.
	 *
	 * @param allergy the allergy
	 */
	String deleteAllergy(Allergy allergy);
	
	/**
	 * Update allergy.
	 *
	 * @param allergy the allergy
	 * @return the allergy
	 */
	Allergy updateAllergy(Allergy allergy);

	List<Allergy> getNewlyAddedAllergies();

	
	
}
