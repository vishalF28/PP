package com.pms.patientservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pms.patientservice.entity.Allergy;
import com.pms.patientservice.model.GenericSuccessResponse;
import com.pms.patientservice.service.AllergyService;

/**
 * The Class AllergyServiceController.
 */
@RestController
@RequestMapping("/allergy")
public class AllergyController {

	/** The allergy service. */
	@Autowired
	AllergyService allergyService;

	/**
	 * Gets the all allergy.
	 *
	 * @return the all allergy
	 */
	@GetMapping("getall")
	public ResponseEntity<List<Allergy>> getAllAllergy() {
		return new ResponseEntity<List<Allergy>>(allergyService.getAllAllergies(), HttpStatus.OK);
	}

	/**
	 * Gets the allergy by id.
	 *
	 * @param allergyId the allergy id
	 * @return the allergy by id
	 */
	@GetMapping("getbyid")
	public ResponseEntity<Allergy> getAllergyById(@RequestParam Long allergyId) {
		return new ResponseEntity<Allergy>(allergyService.getAllergyById(allergyId).get(), HttpStatus.OK);
	}

	/**
	 * Gets the allergy by type.
	 *
	 * @param allergyType the allergy type
	 * @return the allergy by type
	 */
	@GetMapping("getbytype")
	public ResponseEntity<Allergy> getAllergyByType(@RequestParam String allergyType) {
		return new ResponseEntity<Allergy>(allergyService.getAllergyByType(allergyType).get(), HttpStatus.OK);
	}

	/**
	 * Save allergy.
	 *
	 * @param allergy the allergy
	 * @return the allergy
	 */
	@PostMapping("/save")
	public ResponseEntity<Allergy> saveAllergy(@RequestBody Allergy allergy) {

		return new ResponseEntity<Allergy>(allergyService.saveAllergy(allergy), HttpStatus.OK);
	}

	/**
	 * Delete allergy.
	 *
	 * @param allergy the allergy
	 */
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<GenericSuccessResponse> deleteAllergy(@RequestBody Allergy allergy) {

		String message = allergyService.deleteAllergy(allergy);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
		
	}

	/**
	 * Update allergy.
	 *
	 * @param allergy the allergy
	 */
	@PutMapping("/update/{id}")
	public ResponseEntity<Allergy> updateAllergy(@RequestBody Allergy allergy) {

		return new ResponseEntity<Allergy>(allergyService.updateAllergy(allergy), HttpStatus.OK);
	}
	
	@GetMapping("get-newly-added-allergies")
	public ResponseEntity<List<Allergy>> getNewlyAddedAllergies() {
		return new ResponseEntity<List<Allergy>>(allergyService.getNewlyAddedAllergies(), HttpStatus.OK);
	}

}
