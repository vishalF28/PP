package com.pms.patientservice.enums;

// TODO: Auto-generated Javadoc
/**
 * The Enum AddressType.
 */
public enum AddressType {

/** The Temperory. */
Temperory("TEMPERORY"), 
 /** The Permanent. */
 Permanent("PERMANENT");
	
	/** The value. */
	private String value;

	/**
	 * Instantiates a new address type.
	 *
	 * @param value the value
	 */
	AddressType(String value) { this.value = value; }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public String getValue() { return value; }
}

