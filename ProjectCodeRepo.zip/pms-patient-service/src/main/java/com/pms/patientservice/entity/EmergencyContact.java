package com.pms.patientservice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter(value = AccessLevel.PUBLIC)
@Setter(value = AccessLevel.PUBLIC)
@AllArgsConstructor
@ToString
@NoArgsConstructor
@Entity
@Table(name = "pms_relatives", schema = "pms_patient")
public class EmergencyContact extends Auditable<String> implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "relative_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_relatives_generator")
	@SequenceGenerator(name="pms_relatives_generator", sequenceName = "pms_patient.pms_relatives_seq", allocationSize=1)
	private Long relativeId;
	
	@Column(name="title")
	private String title;
	
	@Column(name = "first_name")
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "home_address")
	private String homeAddress;
	
	private String contact;
	
	private String relationship;
	
	@Column(name = "portal_access")
	private String portalAccess; 
	
}
