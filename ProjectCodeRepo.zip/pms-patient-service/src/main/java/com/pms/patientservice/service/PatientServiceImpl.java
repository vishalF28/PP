package com.pms.patientservice.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.patientservice.constants.MessageConstants;
import com.pms.patientservice.entity.Patient;
import com.pms.patientservice.entity.PatientAllergyMapping;
import com.pms.patientservice.enums.Gender;
import com.pms.patientservice.model.PatientSignupRequest;
import com.pms.patientservice.repository.PatientAllergyRepository;
import com.pms.patientservice.repository.PatientRepository;


@Service
public class PatientServiceImpl implements PatientService {


	PatientRepository patientRepository ;

	PatientAllergyRepository patientAllergyRepository;

	public PatientServiceImpl() {

	}

	@Autowired
	public PatientServiceImpl(PatientRepository patientRepository, PatientAllergyRepository patientAllergyRepository) {
		this.patientRepository = patientRepository;
		this.patientAllergyRepository = patientAllergyRepository;
	}


	@Override
	public String savePatientProfile(PatientSignupRequest patientprofile) {
		System.out.println(patientprofile);
		Patient patient = new Patient();
		try
		{
		BeanUtils.copyProperties(patientprofile, patient);
		patient.setGender(Gender.valueOf(patientprofile.getGender()));
		
			patientRepository.save(patient);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);
		}
		return MessageConstants.PATIENT_PROFILE_SAVE_SUCCESS;
	}

	@Override
	public Patient getPatientProfile(String emailId) {
		Patient patient = patientRepository.findByEmailId(emailId);
		Set<PatientAllergyMapping> patientAllergyMappings = patient.getPatientAllergy().stream()
				.filter(patientAllergy -> !patientAllergy.getIsAllergyDeleted()).collect(Collectors.toSet());
		patient.setPatientAllergy(patientAllergyMappings);
		return patient;
	}

	@Override
	public List<Patient> getAllPatients() {
		return patientRepository.findAll();
	}

	@Override
	public String updateUserStatus(String emailId, boolean status) {
		Patient patient = patientRepository.findByEmailId(emailId);
		Optional.of(patient).ifPresent(user -> {
			user.setIsActive(status);
			patientRepository.save(user);
		});
		return MessageConstants.STATUS_UPDATED_SUCCESS;
	}

	@Override
	public Long getPatientCount() {
		return patientRepository.count();
	}

	@Override
	public Long getNewPatientCount() {
		return patientRepository.countNewAddedPatient();
	}

	@Override
	public Patient updatePatientProfile(Patient patient) {
		System.out.println("Patient" + patient);
		Patient oldPatientData = patientRepository.findByEmailId(patient.getEmailId());
		BeanUtils.copyProperties(patient, oldPatientData);
		try 
		{
			oldPatientData = patientRepository.save(oldPatientData);
			Set<PatientAllergyMapping> patientAllergyMappings = oldPatientData.getPatientAllergy().stream()
					.filter(patientAllergy -> !patientAllergy.getIsAllergyDeleted()).collect(Collectors.toSet());
			oldPatientData.setPatientAllergy(patientAllergyMappings);
			System.out.println(oldPatientData);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(MessageConstants.INTERNAL_SERVER_ERROR);
		}
		return oldPatientData;
	}

	@Override
	public String deletePatientAllergy(Long patientAllergyMappingId)  {
		try {
			Optional<PatientAllergyMapping> patientAllergyMapping = patientAllergyRepository.findById(patientAllergyMappingId);
			patientAllergyMapping.ifPresent((allergyMapping)-> {
				allergyMapping.setIsAllergyDeleted(Boolean.TRUE);
				patientAllergyRepository.save(allergyMapping);
			});
		}
		catch (Exception e) {
			throw new RuntimeException(MessageConstants.ALLERGY_DELETED_FAILURE);
		}
		return MessageConstants.ALLERGY_DELETED_SUCCESS;
	}

	@Override
	public PatientAllergyMapping savePatientAllergy(PatientAllergyMapping patientAllergyMapping) {
		if(patientAllergyMapping.getAllergy().getIsNewlyAdded())
		{
			patientAllergyMapping.getAllergy().setAllergyId(null);
		}
		return patientAllergyRepository.save(patientAllergyMapping);
	}

	@Override
	public List<Patient> getAllPatientsByIds(Set<Long> patientIdSet) {
		
		return patientRepository.findByUserIdIn(patientIdSet);
	}
}
