package com.pms.patientservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.BeanUtils;

import com.pms.patientservice.constants.MessageConstants;
import com.pms.patientservice.entity.Allergy;
import com.pms.patientservice.entity.Patient;
import com.pms.patientservice.entity.PatientAllergyMapping;
import com.pms.patientservice.model.PatientSignupRequest;
import com.pms.patientservice.repository.PatientAllergyRepository;
import com.pms.patientservice.repository.PatientRepository;

public class PatientServiceImplUnitTests {

	@InjectMocks
	private PatientServiceImpl patientServiceImpl;
	@Mock
	private PatientRepository patientRepository;
	@Mock
	private PatientAllergyRepository patientAllergyRepository;
	private Patient patient;
	private PatientAllergyMapping paMapping;
	Allergy allergy;
	
	@BeforeEach
	void SetUp() {
		MockitoAnnotations.initMocks(this);
		patient=new Patient();
		patient.setFirstName("aakash");
		patient.setLastName("arora");
		patient.setEmailId("abc@gmail.com");
		patient.setContact("1234567890");
		patient.setAlleryFlag("true");
		patient.setEthnicity("indian");
		patient.setIsActive(true);
		patient.setTitle("Er");
		patient.setPatientId(1L);
		patient.setUserId(1L);
		
		//allergy.setAllergyName("new Allergy");
		
		 paMapping=new PatientAllergyMapping();
		paMapping.setPatientAllergyMappingId(1L);
		paMapping.setPatientId(1L);
		paMapping.setIsAllergyDeleted(Boolean.FALSE);
		
		//paMapping.setAllergy(allergy);
		
	}
	
	@Test 
	@DisplayName("Testing Save Patient Profile Unit Test")
	void testSavePatientProfile() {
		PatientSignupRequest request=new PatientSignupRequest();
		request.setContact("1234567890");
		request.setEmailId("abc@gmail.com");
		request.setFirstName("aakash");
		request.setLastName("arora");
		request.setIsActive(true);
		request.setTitle("Er");
		request.setUserId(1L);
		BeanUtils.copyProperties(request, patient);
		when(patientRepository.save(patient)).thenReturn(patient);
		String message=patientServiceImpl.savePatientProfile(request);
		assertEquals(MessageConstants.PATIENT_PROFILE_SAVE_SUCCESS, message);
		
		
	}
	
	@Test 
	@DisplayName("Testing Save Patient Profile Unit Test with Exception")
	void testSavePatientProfileWithException() {
		Exception e;
		PatientSignupRequest request=new PatientSignupRequest();
		request.setContact("1234567890");
		request.setEmailId("abc@gmail.com");
		request.setFirstName("aakash");
		request.setLastName("arora");
		request.setIsActive(true);
		request.setTitle("Er");
		request.setUserId(1L);
		BeanUtils.copyProperties(request, patient);
		//when(patientRepository.save(patient)).thenThrow();
		//String message=patientServiceImpl.savePatientProfile(request);
		//assertEquals(MessageConstants.PATIENT_PROFILE_SAVE_SUCCESS, message);
		
		
	}
	
	@Test
	@DisplayName("Testing Update User Status") 
	void testUpdateUserStatus() {
		String emailId="aakash.arora121@gmail.com";
		boolean status=true;
		when(patientRepository.findByEmailId(emailId)).thenReturn(patient);
		when(patientRepository.save(patient)).thenReturn(patient);
		String message=patientServiceImpl.updateUserStatus(emailId, status);
		assertEquals(MessageConstants.STATUS_UPDATED_SUCCESS,message);
	}
	
	
	@Test
	@DisplayName("Testing Update Patient Profile")
	void testUpdatePatientProfile() {
		Patient newPatient=new Patient();
		newPatient.setEmailId("aakash.arora@citiustech.com");
		when(patientRepository.findByEmailId(patient.getEmailId())).thenReturn(patient);
		when(patientRepository.save(patient)).thenReturn(patient);
		BeanUtils.copyProperties(patient, newPatient);

		//Patient updatedPatient=patientServiceImpl.updatePatientProfile(newPatient);
		
		assertEquals(patient, newPatient);
	}


	@Test
	@DisplayName("Testing Save Patient Allergy")
	void testSavePatientAllergy() {
		Allergy allergy=new Allergy();
		allergy.setIsNewlyAdded(true);
		PatientAllergyMapping paMapping= new PatientAllergyMapping();
		paMapping.setPatientId(1L);
		paMapping.setIsAllergyFatal("false");
		paMapping.setIsAllergyDeleted(false);
		
		paMapping.setAllergy(allergy);
		when(patientAllergyRepository.save(anyObject())).thenReturn(paMapping);
		PatientAllergyMapping mapping=patientServiceImpl.savePatientAllergy(paMapping);
		assertEquals(mapping.getPatientId(), paMapping.getPatientId());
		
		
		
	}
	
	
	@Test
	@DisplayName("Testing Delete Patient Allergy")
	void testDeletePatientAllergy() {
		
		Long id=1L;
		
		Optional<PatientAllergyMapping> patientAllergyMapping = patientAllergyRepository.findById(id);
		patientAllergyMapping.ifPresent((allergyMapping)-> {
			allergyMapping.setIsAllergyDeleted(Boolean.TRUE);
			patientAllergyRepository.save(allergyMapping);
		});
		
		
		when(patientAllergyRepository.findById(id)).thenReturn(Optional.of(paMapping));
//		when(Optional.of(paMapping).ifPresent((allergyMapping)->
//			allergyMapping.setIsAllergyDeleted(Boolean.TRUE)))
		
		String message=patientServiceImpl.deletePatientAllergy(id);
		assertEquals(message, MessageConstants.ALLERGY_DELETED_SUCCESS);
		
	}
	 
	
	
	
	
	@DisplayName("Testing Get Patient Profile")
	void testGetPatientProfile() {
		Set<PatientAllergyMapping> patientAMapping=new HashSet<>();
		patientAMapping.add(paMapping);
		
		patient.setPatientAllergy(patientAMapping);
		when(patientRepository.findByEmailId(patient.getEmailId())).thenReturn(patient);
		when(patient.getPatientAllergy().stream().filter(patientAllergy-> !patientAllergy.getIsAllergyDeleted()).collect(Collectors.toSet())).thenReturn(patientAMapping);
		Patient patient2=patientServiceImpl.getPatientProfile(patient.getEmailId());
		System.out.println("p1 "+patient);
		System.out.println("p2: "+patient2);
		
		assertEquals(patient, patient2);
	}
	
	
	
	@Test
	@DisplayName("Testing Get all Patients")
	void testGetAllPatients() {
		
		List<Patient> patientList=new ArrayList<Patient>();
		patientList.add(patient);
		when(patientRepository.findAll()).thenReturn(patientList);
		List<Patient> pList=patientServiceImpl.getAllPatients();
		
		assertEquals(pList,patientList);
	}
	
	
	
	@Test
	@DisplayName("Testing Get patient count")
	void testGetPatientCount() {
		when(patientRepository.save(anyObject())).thenReturn(patient);
		when(patientRepository.findByEmailId(patient.getEmailId())).thenReturn(patient);
		patientRepository.save(patient);
		when(patientRepository.count()).thenReturn(1L);
		Long count=patientServiceImpl.getNewPatientCount();
		
	}
	
	
	
	
	
	
	
	
	
	
}
