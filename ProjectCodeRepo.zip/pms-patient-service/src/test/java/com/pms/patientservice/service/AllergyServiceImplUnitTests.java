package com.pms.patientservice.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.anyObject;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.pms.patientservice.constants.MessageConstants;
import com.pms.patientservice.entity.Allergy;
import com.pms.patientservice.repository.AllergyRepository;

public class AllergyServiceImplUnitTests {

	
	@Mock
	public AllergyRepository allergyRepository;

	@InjectMocks
	public AllergyServiceImpl allergyServiceImpl;
	Allergy allergy;
	List<Allergy> allAllergyList;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		 allergy=new Allergy();
		allergy.setAllergyId(1L);
		allergy.setAllergyName("Dust");
		allergy.setAllergyDescription("Dust and mud");
		allergy.setAllergyClinicalInformation("clinicalINfo");
		allergy.setAllergyType("Solid");
		allergy.setIsNewlyAdded(true);
		allAllergyList=new ArrayList<>();
		allAllergyList.add(allergy);
		
		
	}
	
	
	@Test
	@DisplayName("Testing Save Allergy")
	void testSaveAllergy() {
		when(allergyRepository.save(anyObject())).thenReturn(allergy);
		Allergy allergy1=allergyServiceImpl.saveAllergy(allergy);
		assertEquals(allergy, allergy1);
		
		
		
	}

	
	@Test
	@DisplayName("Testing Update Allergy")
	void testUpdateAllergy() {
		Allergy updatedAllergy=new Allergy();
		updatedAllergy.setAllergyName("Non dust");
		
		when(allergyRepository.save(anyObject())).thenReturn(updatedAllergy);
		Allergy updateAllergy=allergyServiceImpl.updateAllergy(updatedAllergy);
		assertEquals(updateAllergy, updatedAllergy);
		//assertNotEquals(updatedAllergy, allergy);
	}
	
	
	@Test
	@DisplayName("Testing Delete Allergy")
	void testDeleteAllergy() {
		Allergy deletedAllergy= new Allergy();
		deletedAllergy.setAllergyId(2L);
		String message=allergyServiceImpl.deleteAllergy(anyObject());
		assertEquals(MessageConstants.ALLERGY_DELETED_SUCCESS, message);
		
	}
	
	
	@Test
	@DisplayName("Testing Get All Allergy")
	void testGetAllAllergy() {
		
		when(allergyRepository.save(anyObject())).thenReturn(allergy);
		when(allergyServiceImpl.getAllAllergies()).thenReturn(allAllergyList);
		allergyRepository.save(allergy);
		
		
		List<Allergy>  allAllergy=allergyServiceImpl.getAllAllergies();

		assertEquals(1, allAllergy.size());
		
	}
	
	@Test
	@DisplayName("Testing Get All Allergy By Id")
	void testGetAllAllergyById() {
		when(allergyRepository.save(anyObject())).thenReturn(allergy);

		when(allergyRepository.findByAllergyId(anyObject())).thenReturn(allergy);

		allergyRepository.save(allergy);
		
		Optional<Allergy> allergyList=allergyServiceImpl.getAllergyById(allergy.getAllergyId());
		
	}
 
	
	@Test
	@DisplayName("Testing get allergy by type")
	void testGetAllergyByType() {
		when(allergyRepository.save(anyObject())).thenReturn(allergy);
		when(allergyRepository.findByAllergyType(anyObject())).thenReturn(Optional.of(allergy));
		allergyRepository.save(allergy);
		Optional<Allergy> allergyList=allergyServiceImpl.getAllergyByType(allergy.getAllergyType());
		assertEquals(false, allergyList.empty());
		
	}
	
	
	@Test
	@DisplayName("Testing get newly added allergy")
	void testGetNewlyAddedAllergy() {
		when(allergyRepository.save(anyObject())).thenReturn(allergy);
		when(allergyRepository.findAll().stream().filter(allergy->allergy.getIsNewlyAdded()).collect(Collectors.toList())).thenReturn(allAllergyList);
		allergyRepository.save(allergy);
		List<Allergy> allergyList2=allergyServiceImpl.getNewlyAddedAllergies();
		
		assertEquals(allergyList2, allAllergyList);
	}
	
	
}
