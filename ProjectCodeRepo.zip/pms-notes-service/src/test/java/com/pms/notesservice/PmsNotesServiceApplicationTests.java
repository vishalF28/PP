package com.pms.notesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmsNotesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
