package com.pms.notesservice.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.notesservice.constants.MessageConstants;
import com.pms.notesservice.entity.MessageNote;
import com.pms.notesservice.entity.ReceiverNote;
import com.pms.notesservice.entity.SenderNote;
import com.pms.notesservice.repository.MessageNotesRepository;
import com.pms.notesservice.repository.ReceiverNotesRepository;
import com.pms.notesservice.repository.SenderNotesRepository;

@Service
public class NotesServiceImpl implements NotesService{

	private SenderNotesRepository senderNotesRepository;
	private ReceiverNotesRepository receiverNotesRepository;
	private MessageNotesRepository messageNotesRepository;
	
	public NotesServiceImpl() {
	}
	
	@Autowired
	public NotesServiceImpl(SenderNotesRepository senderNotesRepository, MessageNotesRepository messageNotesRepository,
			ReceiverNotesRepository receiverNotesRepository) {
		this.senderNotesRepository = senderNotesRepository;
		this.messageNotesRepository = messageNotesRepository;
		this.receiverNotesRepository = receiverNotesRepository;
	}
	
	@Override
	public List<ReceiverNote> getReceiverNotesByEmailId(String emailId) {
		return receiverNotesRepository.findAllByReceiverEmailId(emailId);
	}

	@Override
	public SenderNote addNewNotes(SenderNote senderNote) {
		MessageNote messageNote = new MessageNote();
		messageNote.setSenderEmailId(senderNote.getSenderEmailId());
		messageNote.setReceiverEmailId(senderNote.getReceiverEmailId());
		messageNote.setSenderName(senderNote.getSenderName());
		messageNote.setReceiverName(senderNote.getReceiverName());
		messageNote.setSenderDesignation(senderNote.getSenderDesignation());
		messageNote.setReceiverDesignation(senderNote.getReceiverDesignation());
		
		messageNote.setChatBoxName(senderNote.getSenderName() + " " + senderNote.getReceiverName());
		messageNote = messageNotesRepository.save(messageNote);
		
		senderNote.setChatId(messageNote.getChatId());
		senderNote.setIsViewed(true);
		senderNote.setIsDeleted(false);
		senderNote = senderNotesRepository.save(senderNote);
		
		ReceiverNote receiverNote = new ReceiverNote();
		BeanUtils.copyProperties(senderNote, receiverNote);
		receiverNote.setIsViewed(false);
		receiverNote.setIsDeleted(false);
		receiverNote = receiverNotesRepository.save(receiverNote);
		
		return senderNote;
	}

	@Override
	public List<SenderNote> getMyNotesByEmailId(String emailId) {
		System.out.println(emailId);
		return senderNotesRepository.findAllBySenderEmailId(emailId);
	}

	@Override
	public List<ReceiverNote> getReceiverNotesBasedOnChatId(Long chatId) {
		List<ReceiverNote> receiverNoteList = receiverNotesRepository.findAllByChatId(chatId);
		for(ReceiverNote note : receiverNoteList) {
			note.setIsViewed(true);
			receiverNotesRepository.save(note);
		}
		return receiverNoteList;
	}

	@Override
	public ReceiverNote saveReceiverReplyMessage(ReceiverNote receiverNote) {
		receiverNote.setNoteId(null);
		receiverNote.setIsViewed(true);
		receiverNote.setIsDeleted(false);
		receiverNote = receiverNotesRepository.save(receiverNote);
		SenderNote senderNote = new SenderNote();
		BeanUtils.copyProperties(receiverNote, senderNote);
		senderNote.setIsViewed(false);
		senderNote.setIsDeleted(false);
		senderNotesRepository.save(senderNote);
		
		return receiverNote;
	}

	@Override
	public List<SenderNote> getMyNotesBasedOnChatId(Long chatId) {
		List<SenderNote> senderNoteList = senderNotesRepository.findAllByChatId(chatId);
		for(SenderNote note : senderNoteList) {
			note.setIsViewed(true);
			senderNotesRepository.save(note);
		}
		return senderNoteList;
	}

	@Override
	public SenderNote saveMyReplyMessage(SenderNote senderNote) {
		senderNote.setNoteId(null);
		senderNote.setIsViewed(true);
		senderNote.setIsDeleted(false);
		senderNote = senderNotesRepository.save(senderNote);
		
		ReceiverNote receiverNote = new ReceiverNote();
		BeanUtils.copyProperties(senderNote, receiverNote);
		receiverNote.setIsViewed(false);
		receiverNote.setIsDeleted(false);
		receiverNotesRepository.save(receiverNote);
		
		return senderNote;
	}

	@Transactional
	@Override
	public String deleteSenderNotes(Long chatId) {
		senderNotesRepository.deleteByChatId(chatId);
		List<ReceiverNote> receiverNotes = receiverNotesRepository.findAllByChatId(chatId);
		for(ReceiverNote note: receiverNotes)
		{
			note.setIsDeleted(true);
			receiverNotesRepository.save(note);
		}
		return MessageConstants.NOTES_DELETED_SUCCESS;
	}

	@Transactional
	@Override
	public String deleteReceiverNotes(Long chatId) {
		receiverNotesRepository.deleteByChatId(chatId);
		List<SenderNote> senderNotes = senderNotesRepository.findAllByChatId(chatId);
		for(SenderNote note: senderNotes)
		{
			note.setIsDeleted(true);
			senderNotesRepository.save(note);
		}
		return MessageConstants.NOTES_DELETED_SUCCESS;
	}

}
