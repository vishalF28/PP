package com.pms.notesservice.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pms.notesservice.entity.ReceiverNote;

@Repository
public interface ReceiverNotesRepository extends JpaRepository<ReceiverNote, Long>{

	@Query(value = "SELECT * FROM pms_hospital.pms_receiver_notes WHERE (chat_id, note_id) IN (SELECT chat_id, MAX(note_id) FROM pms_hospital.pms_receiver_notes GROUP BY chat_id) AND receiver_email_id = ?", nativeQuery = true)
	List<ReceiverNote> findAllByReceiverEmailId(String receiverEmailId);

	List<ReceiverNote> findAllByChatId(Long chatId);

	@Query(value="SELECT DISTINCT(receiver_email_id) FROM pms_hospital.pms_receiver_notes", nativeQuery = true)
	Set<String> findDistinctReceiverEmailId();

	void deleteByChatId(Long chatId);

}
