package com.pms.notesservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pms.notesservice.entity.ReceiverNote;
import com.pms.notesservice.entity.SenderNote;
import com.pms.notesservice.model.GenericSuccessResponse;
import com.pms.notesservice.service.NotesService;

@RestController
@RequestMapping("notes")
public class NotesController {

	private NotesService notesService;
	
	public NotesController() {
	}
	
	@Autowired
	public NotesController(NotesService notesService) {
		this.notesService = notesService;
	}
	
	
	@PostMapping("/add-new-note")
	public ResponseEntity<SenderNote> addNewNote(@RequestBody SenderNote note) {
		return new ResponseEntity<SenderNote>(notesService.addNewNotes(note), HttpStatus.OK);
	}
	
	@GetMapping("/get-receiver-notes/{emailId}")
	public ResponseEntity<List<ReceiverNote>> getReceiverNotesByEmailId(@PathVariable String emailId) {
		List<ReceiverNote> notesByEmailId = notesService.getReceiverNotesByEmailId(emailId);
		return new ResponseEntity<List<ReceiverNote>>(notesByEmailId, HttpStatus.OK);
	}
	
	@GetMapping("/get-my-notes/{emailId}")
	public ResponseEntity<List<SenderNote>> getMyNotesByEmailId(@PathVariable String emailId) {
		List<SenderNote> notesByEmailId = notesService.getMyNotesByEmailId(emailId);
		return new ResponseEntity<List<SenderNote>>(notesByEmailId, HttpStatus.OK);
	}
	
	@GetMapping("/get-receiver-notes-based-on-chat-id/{chatId}")
	public ResponseEntity<List<ReceiverNote>> getReceiverNotesBasedOnChatId(@PathVariable Long chatId) {
		List<ReceiverNote> receiverNotesByChatId = notesService.getReceiverNotesBasedOnChatId(chatId);
		return new ResponseEntity<List<ReceiverNote>>(receiverNotesByChatId, HttpStatus.OK);
	}
	
	@PostMapping("/save-receiver-reply-note")
	public ResponseEntity<ReceiverNote> saveReceiverReplyMessage(@RequestBody ReceiverNote receiverNote) {
		return new ResponseEntity<ReceiverNote>(notesService.saveReceiverReplyMessage(receiverNote), HttpStatus.OK);
	}
	
	@GetMapping("/get-my-notes-based-on-chat-id/{chatId}")
	public ResponseEntity<List<SenderNote>> getMyNotesBasedOnChatId(@PathVariable Long chatId) {
		List<SenderNote> senderNotesByChatId = notesService.getMyNotesBasedOnChatId(chatId);
		return new ResponseEntity<List<SenderNote>>(senderNotesByChatId, HttpStatus.OK);
	}
	
	@PostMapping("/save-my-reply-note")
	public ResponseEntity<SenderNote> saveMyReplyMessage(@RequestBody SenderNote senderNote) {
		return new ResponseEntity<SenderNote>(notesService.saveMyReplyMessage(senderNote), HttpStatus.OK);
	}
	
	@PostMapping("/delete-sender-notes")
	public ResponseEntity<GenericSuccessResponse> deleteSenderNotes(@RequestBody Long chatId) {
		String message = notesService.deleteSenderNotes(chatId);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
	
	@PostMapping("/delete-receiver-notes")
	public ResponseEntity<GenericSuccessResponse> deleteReceiverNotes(@RequestBody Long chatId) {
		String message = notesService.deleteReceiverNotes(chatId);
		GenericSuccessResponse response = new GenericSuccessResponse();
		response.setMessage(message);
		return new ResponseEntity<GenericSuccessResponse>(response, HttpStatus.OK);
	}
}
