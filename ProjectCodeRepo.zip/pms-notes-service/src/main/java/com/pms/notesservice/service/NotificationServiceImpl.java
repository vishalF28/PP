package com.pms.notesservice.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.notesservice.entity.ReceiverNote;
import com.pms.notesservice.entity.SenderNote;
import com.pms.notesservice.model.Notifications;
import com.pms.notesservice.repository.ReceiverNotesRepository;
import com.pms.notesservice.repository.SenderNotesRepository;

@Service
public class NotificationServiceImpl implements NotificationService{

	private SenderNotesRepository senderNotesRepository;
	
	private ReceiverNotesRepository receiverNotesRepository;
	
	public NotificationServiceImpl() {
	}
	
	@Autowired
	public NotificationServiceImpl(SenderNotesRepository senderNotesRepository, ReceiverNotesRepository receiverNotesRepository) {
		this.senderNotesRepository = senderNotesRepository;
		this.receiverNotesRepository = receiverNotesRepository;
	}
	
	@Override
	public List<Notifications> getNotificationCount() {
		Set<String> senderEmailId = senderNotesRepository.findDistinctSenderEmailId();
		Set<String> receiverEmailId = receiverNotesRepository.findDistinctReceiverEmailId();
		Set<String> users = new HashSet<>();
		users.addAll(receiverEmailId);
		users.addAll(senderEmailId);
		System.out.println(users);
		List<Notifications> notifications = new ArrayList<>();
		Notifications notification = null;
		for(String user : users) {
			notification = new Notifications();
			List<SenderNote> senderNotes = senderNotesRepository.findAllBySenderEmailId(user);
			Long senderCount = (long) senderNotes.stream().filter(note -> !note.getIsViewed()).collect(Collectors.toList()).size();
			List<ReceiverNote> receiverNotes = receiverNotesRepository.findAllByReceiverEmailId(user);
			Long receiverCount = (long) receiverNotes.stream().filter(note -> !note.getIsViewed()).collect(Collectors.toList()).size();
			notification.setEmailId(user);
			notification.setSenderCount(senderCount);
			notification.setReceiverCount(receiverCount);
			notifications.add(notification);
			System.out.println(notification);
		}
		return notifications;
	}

}
