package com.pms.notesservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pms.notesservice.model.Notifications;
import com.pms.notesservice.service.NotificationService;

@RestController
public class NotificationController {
	
    private SimpMessagingTemplate template;
	
    private NotificationService notificationService;
    
    NotificationController() {
    }
    
    @Autowired
    NotificationController(SimpMessagingTemplate template, NotificationService notificationService)
    {
    	this.template = template;
    	this.notificationService = notificationService;
    	
    }

    @SuppressWarnings("unused")
	private Notifications notifications = new Notifications();

    @GetMapping("/notify")
    public void getNotification() {
    	List<Notifications> notifications = notificationService.getNotificationCount();
    	
        // Push notifications to front-end
        template.convertAndSend("/topic/notification", notifications);
    }


}
