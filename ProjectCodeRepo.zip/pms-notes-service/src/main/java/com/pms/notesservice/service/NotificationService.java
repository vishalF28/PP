package com.pms.notesservice.service;

import java.util.List;

import com.pms.notesservice.model.Notifications;

public interface NotificationService {

	public List<Notifications> getNotificationCount();

}
