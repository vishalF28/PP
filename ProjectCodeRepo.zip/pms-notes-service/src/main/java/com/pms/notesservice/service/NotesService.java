package com.pms.notesservice.service;

import java.util.List;

import com.pms.notesservice.entity.ReceiverNote;
import com.pms.notesservice.entity.SenderNote;

public interface NotesService {

	public List<ReceiverNote> getReceiverNotesByEmailId(String emailId);

	public SenderNote addNewNotes(SenderNote note);

	public List<SenderNote> getMyNotesByEmailId(String emailId);

	public List<ReceiverNote> getReceiverNotesBasedOnChatId(Long chatId);

	public ReceiverNote saveReceiverReplyMessage(ReceiverNote receiverNote);

	public List<SenderNote> getMyNotesBasedOnChatId(Long chatId);

	public SenderNote saveMyReplyMessage(SenderNote senderNote);

	public String deleteSenderNotes(Long chatId);

	public String deleteReceiverNotes(Long chatId);

	
}
