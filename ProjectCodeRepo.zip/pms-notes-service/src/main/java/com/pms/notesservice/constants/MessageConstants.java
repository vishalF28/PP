package com.pms.notesservice.constants;

public class MessageConstants {

	public static final String NOTES_DELETED_SUCCESS = "Note deleted successfully.";

}
