package com.pms.notesservice.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table(name="pms_sender_notes", schema = "pms_hospital")
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class SenderNote {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_sender_notes_generator")
	@SequenceGenerator(name="pms_sender_notes_generator", sequenceName = "pms_hospital.pms_sender_notes_seq", allocationSize=1)
	@Column(name="note_id")
	private Long noteId;
	
	@Column(name = "chat_id")
	private Long chatId;
	
	@Column(name="sender_name")
	private String senderName;
	
	@Column(name="sender_designation")
	private String senderDesignation;
	
	@Column(name="message")
	private String message;
	
	@Column(name="is_urgent")
	private Boolean isUrgent;
	
	@Column(name="receiver_name")
	private String receiverName;
	
	@Column(name="receiver_designation")
	private String receiverDesignation;
	
	@Column(name="receiver_email_id")
	private String receiverEmailId;
	
	@Column(name="sender_email_id")
	private String senderEmailId;
	
	@Column(name="message_received_date")
	private Date messageReceivedDate = new Date();

	@Column(name="is_viewed")
	private Boolean isViewed;
	
	@Column(name="is_deleted")
	private Boolean isDeleted;
 }
