package com.pms.notesservice.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pms.notesservice.entity.SenderNote;

@Repository
public interface SenderNotesRepository extends JpaRepository<SenderNote, Long>{

	List<SenderNote> findAllByReceiverEmailId(String receiverEmailId);
	
	@Query(value="SELECT * FROM pms_hospital.pms_sender_notes WHERE (chat_id, note_id) IN (SELECT chat_id, MAX(note_id) FROM pms_hospital.pms_sender_notes GROUP BY chat_id) AND sender_email_id = ?", nativeQuery = true)
	List<SenderNote> findAllBySenderEmailId(String senderEmailId);

	List<SenderNote> findAllByChatId(Long chatId);

	@Query(value="SELECT DISTINCT(sender_email_id) FROM pms_hospital.pms_sender_notes", nativeQuery = true)
	Set<String> findDistinctSenderEmailId();

	void deleteByChatId(Long chatId);

}
