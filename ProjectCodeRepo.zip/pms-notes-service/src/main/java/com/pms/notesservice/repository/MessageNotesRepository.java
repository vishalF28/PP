package com.pms.notesservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pms.notesservice.entity.MessageNote;

@Repository
public interface MessageNotesRepository extends JpaRepository<MessageNote, Long>{

}
