package com.pms.notesservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="pms_message_notes", schema = "pms_hospital")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MessageNote {

	@Id
	@Column(name = "chat_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pms_message_notes_generator")
	@SequenceGenerator(name="pms_message_notes_generator", sequenceName = "pms_hospital.pms_message_notes_seq", allocationSize=1)
	private Long chatId;
	
	@Column(name = "chat_box_name")
	private String chatBoxName;
	
	@Column(name = "sender_email_id")
	private String senderEmailId;
	
	@Column(name = "receiver_email_id")
	private String receiverEmailId;
	
	@Column(name="receiver_designation")
	private String receiverDesignation;
	
	@Column(name="receiver_name")
	private String receiverName;
	
	@Column(name="sender_designation")
	private String senderDesignation;
	
	@Column(name="sender_name")
	private String senderName;
}
